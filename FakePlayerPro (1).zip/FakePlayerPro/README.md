# FakePlayerPro

Plugin fake player / bot untuk server Minecraft (Paper, Purpur, Pufferfish; 1.16 hingga versi terbaru).

## Syarat
- Server **Paper** atau fork-nya (Spigot biasa tidak bisa memodifikasi server list)
- Plugin **Citizens 2** (https://citizensnpcs.co) versi yang cocok dengan versi server
- Java sesuai versi server

## Cara build (tanpa PC)
1. Buat repo baru di GitHub, upload semua isi folder ini
2. Buka tab **Actions** → **Build** → Run workflow
3. Unduh artifact `FakePlayerPro` (berisi .jar), taruh di folder `plugins/` bersama Citizens

Build lokal: `mvn package` (JDK 17).
Jika build gagal karena versi Citizens, ganti `citizens-main` di `pom.xml` ke versi terbaru
(cek https://maven.citizensnpcs.co).

## Fitur
- Jumlah online di server list bertambah sesuai bot; nama bot muncul saat hover
- Bot tampil seperti pemain asli: skin sesuai nama, armor acak, tab list, pesan join/leave/mati
- Aktivitas natural: menoleh ke pemain, lompat, sneak, ayun tangan, jalan-jalan, chat acak, balas saat namanya disebut
- Menyerang pemain terdekat (mode agresif) dan membalas yang memukulnya
- Perintah (butuh permission): mining (ores/kayu/batu/ore tertentu), bangun base (house/tower/wall/fort), jaga base, ikut pemain, kumpulkan item
- Gudang bot (hasil mining), skin, equip item, home, teleport
- GUI lengkap: menu utama, daftar bot, kontrol bot, mining, build, jaga, spawn, pengaturan, gudang
- Bot disimpan di `bots.yml` dan kembali setelah restart

## Permission
`fakeplayer.use`, `.gui`, `.spawn`, `.remove`, `.control`, `.admin` (default op), `fakeplayer.bypass` (kebal dari serangan bot)

## Perintah
Lihat `/bot help`. Alias: `/fp`, `/bot`.

## Skin lewat URL
1. Buat API key gratis di https://account.mineskin.org lalu isi `skin.mineskin-api-key` di `config.yml`
2. `/bot skin <nama|all> url <link-gambar-skin.png>` (atau tempel link di menu GUI → Ganti Skin)
Skin biasa: `/bot skin <nama> <nama-akun-minecraft>`.

## Placeholder (PlaceholderAPI)
- `%fakeplayer_online%` pemain asli + bot
- `%fakeplayer_real%` pemain asli saja
- `%fakeplayer_bots%` jumlah bot
- `%fakeplayer_alive%` bot yang hidup
- `%fakeplayer_max%` slot maksimum
Pakai `%fakeplayer_online%` di config plugin tab/scoreboard menggantikan placeholder jumlah online bawaannya.

## Alur bot: create → spawn
- `/bot create <nama>` membuat bot (offline, tersimpan)
- `/bot spawn <nama>` memunculkannya di posisimu (tab-complete menampilkan bot yang sudah dibuat)
- `/bot despawn <nama>` mengoffline-kan, `/bot delete <nama>` menghapus permanen
- GUI: Daftar Bot → klik kanan bot untuk spawn/despawn
- Server list & placeholder hanya menghitung bot yang online

## Rasuki bot
`/bot possess <nama>` (permission `fakeplayer.possess`): kamu disembunyikan dari pemain lain, bot meniru gerakan,
pandangan, item, armor, pukulan, dan chat-mu. Keluar: `/bot release`.

## Chat manual / otomatis (permission `fakeplayer.chat`)
`/bot say <nama|all> <pesan>` (manual), `/bot chat <nama|all> <auto|manual>` (otomatis on/off), tombol di GUI.

## Mandiri & jelajah
`/bot explore <nama|all>` keliling dunia, membangun portal Nether dan berpindah dimensi.
`/bot auto <nama|all>` berganti aktivitas sendiri (jelajah, mining, bangun rumah, kumpulkan item, jalan-jalan).
`/bot build <nama> portal` membangun portal manual.

## Inventory & hotbar bot (permission `fakeplayer.inventory`)
- `/bot inv <nama>` membuka GUI: inventory 3 baris, hotbar, pilih slot aktif, armor, tangan kiri
- `/bot hotbar <nama|all> <1-9>` slot aktif, `/bot give <nama|all>` beri item di tanganmu
- `/bot clearinv`, `/bot resetinv` (kembali ke perlengkapan default)
- Isi inventory tersimpan di `bots.yml` dan dipakai lagi setiap bot di-spawn

## Rank LuckPerms (permission `fakeplayer.rank`)
- `/bot rank <nama|all> <grup|none>`: prefix/suffix grup LuckPerms dipakai di nametag, tab list (scoreboard team), dan chat bot (`%prefix%` di `chat.format`)
- Placeholder: `%fakeplayer_rank_<bot>%`, `%fakeplayer_prefix_<bot>%`, `%fakeplayer_suffix_<bot>%`
- Ini rank tampilan: bot bukan pemain asli, jadi LuckPerms tidak memberi permission ke bot

## PvP pro (kit, crystal, mace)
- `/bot kit <nama|all> <sword|axe|crystal|mace|clear>` memasang kit (netherite + enchant, gapple, totem, dll)
- `/bot pvp <nama|all> <auto|sword|crystal|mace|off>` memilih gaya bertarung
- `/bot attack <nama|all> on` agar bot menyerang pemain terdekat, atau `/bot duel <bot> <pemain|bot lain>`
- Sword/axe: strafe + crit jump. Crystal: crystal muncul dan meledak dekat lawan (blok tidak rusak, ubah di `pvp.crystal-break-blocks`).
- Mace: melompat tinggi lalu smash dari atas dengan bonus damage sesuai tinggi jatuh (kit mace butuh server 1.21+).
- Bot makan gapple saat nyawa rendah, totem di tangan kiri bekerja otomatis.
- Pengaturan di `config.yml` bagian `pvp:`

## Tab list, online per world, TP ke bot
- Bot tampil di tab list (`bots.show-in-tablist: true`). Ubah live: `/bot tablist <on|off>` (bot di-respawn di tempatnya).
  Jika plugin tab (mis. TAB) memakai layout sendiri, atur di config plugin itu agar NPC tidak disembunyikan.
- `/online` (atau `/bot online`): jumlah pemain + bot per world. Placeholder: `%fakeplayer_online_<world>%`,
  `%fakeplayer_real_<world>%`, `%fakeplayer_bots_<world>%`. Nama world bisa diganti di `online.display-names`.
- Bot bisa jadi target `/tp <bot>`, `/tp <pemain> <bot>`, `/tphere <bot>`, `/tpa <bot>`, `/tpahere <bot>`, `/tpcancel`
  (nama bot juga muncul di tab-complete). `/tp` & `/tphere` butuh `fakeplayer.tp` / `fakeplayer.tphere` (op),
  `/tpa` & `/tpahere` butuh `fakeplayer.tpa` (semua pemain).
- Terima TPA per bot: `/bot tpamode <bot|all> <auto|manual|off>` atau tombol di GUI.
  Auto = bot menerima sendiri setelah beberapa detik (kadang membalas chat). Manual = admin dengan
  `fakeplayer.tpa.manage` (atau admin yang merasuki bot) mendapat tombol [Terima]/[Tolak] di chat, atau
  `/bot tpaccept <bot> [pemain]`, `/bot tpdeny <bot> [pemain]`, `/bot tpalist`.
- `/tpa` antar pemain asli butuh plugin seperti EssentialsX; plugin ini hanya menangani target bot.
