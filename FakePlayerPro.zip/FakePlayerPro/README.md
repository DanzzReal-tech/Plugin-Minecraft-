# FakePlayerPro

Plugin fake player / bot untuk server Minecraft (Paper, Purpur, Pufferfish; 1.16 hingga versi terbaru).

## Syarat
- Server **Paper** atau fork-nya (Spigot biasa tidak bisa memodifikasi server list)
- Plugin **Citizens 2** (https://citizensnpcs.co) versi yang cocok dengan versi server
- Java sesuai versi server

## Cara build (tanpa PC)
1. Buat repo baru di GitHub, upload semua isi folder ini
2. Buka tab **Actions** → **Build** → Run workflow
3. Unduh artifact `FakePlayerPro` (berisi .jar), taruh di folder `plugins/` bersama Citizens

Build lokal: `mvn package` (JDK 17).
Jika build gagal karena versi Citizens, ganti `citizens-main` di `pom.xml` ke versi terbaru
(cek https://maven.citizensnpcs.co).

## Fitur
- Jumlah online di server list bertambah sesuai bot; nama bot muncul saat hover
- Bot tampil seperti pemain asli: skin sesuai nama, armor acak, tab list, pesan join/leave/mati
- Aktivitas natural: menoleh ke pemain, lompat, sneak, ayun tangan, jalan-jalan, chat acak, balas saat namanya disebut
- Menyerang pemain terdekat (mode agresif) dan membalas yang memukulnya
- Perintah (butuh permission): mining (ores/kayu/batu/ore tertentu), bangun base (house/tower/wall/fort), jaga base, ikut pemain, kumpulkan item
- Gudang bot (hasil mining), skin, equip item, home, teleport
- GUI lengkap: menu utama, daftar bot, kontrol bot, mining, build, jaga, spawn, pengaturan, gudang
- Bot disimpan di `bots.yml` dan kembali setelah restart

## Permission
`fakeplayer.use`, `.gui`, `.spawn`, `.remove`, `.control`, `.admin` (default op), `fakeplayer.bypass` (kebal dari serangan bot)

## Perintah
Lihat `/bot help`. Alias: `/fp`, `/bot`.

## Skin lewat URL
1. Buat API key gratis di https://account.mineskin.org lalu isi `skin.mineskin-api-key` di `config.yml`
2. `/bot skin <nama|all> url <link-gambar-skin.png>` (atau tempel link di menu GUI → Ganti Skin)
Skin biasa: `/bot skin <nama> <nama-akun-minecraft>`.
