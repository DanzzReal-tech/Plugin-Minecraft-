package me.fakeplayer.command;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.*;
import me.fakeplayer.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

import java.util.*;

public class BotCommand implements CommandExecutor, TabCompleter {
    private final FakePlayerPlugin plugin;

    private static final List<String> SUBS = Arrays.asList("menu", "create", "spawn", "despawn", "random", "remove", "delete", "removeall", "list", "info", "explore", "auto", "possess", "release", "inv", "hotbar", "give", "clearinv", "resetinv", "rank", "kit", "pvp", "duel",
            "idle", "wander", "follow", "collect", "guard", "mine", "build", "attack", "chat", "tp", "tphere", "skin",
            "equip", "say", "sethome", "storage", "stop", "reload", "help");

    public BotCommand(FakePlayerPlugin plugin) { this.plugin = plugin; }

    private BotManager m() { return plugin.bots(); }

    private boolean perm(CommandSender s, String p) {
        if (s.hasPermission(p)) return true;
        Msg.send(s, "&cKamu tidak punya izin &f" + p);
        return false;
    }

    private List<Bot> targets(CommandSender s, String t) {
        List<Bot> l = new ArrayList<>();
        if (t.equalsIgnoreCase("all") || t.equals("*")) l.addAll(m().all());
        else {
            Bot b = m().get(t);
            if (b != null) l.add(b);
        }
        if (l.isEmpty()) Msg.send(s, "&cBot tidak ditemukan: &f" + t);
        return l;
    }

    private void help(CommandSender s) {
        String[] h = {
                "&b/bot &7- buka menu GUI",
                "&b/bot create <nama> &7- buat bot baru (offline)",
                "&b/bot spawn <nama|all> &7- munculkan bot yang sudah dibuat",
                "&b/bot despawn <nama|all> &7- offline-kan bot (data tetap)",
                "&b/bot random <jumlah> &7- buat + spawn bot acak",
                "&b/bot delete <nama|all> &7- hapus bot permanen",
                "&b/bot explore|auto <nama|all> &7- jelajah dunia / mandiri penuh",
                "&b/bot possess <nama> &7| &b/bot release &7- rasuki bot / keluar",
                "&b/bot inv <nama> &7- GUI inventory & hotbar bot",
                "&b/bot hotbar <nama|all> <1-9> &7| &b/bot give <nama|all> &7(item di tanganmu)",
                "&b/bot clearinv|resetinv <nama|all> &7| &b/bot rank <nama|all> <grup|none>",
                "&b/bot kit <nama|all> <sword|axe|crystal|mace|clear> &7- kit PvP pro",
                "&b/bot pvp <nama|all> <auto|sword|crystal|mace|off> &7- gaya bertarung",
                "&b/bot duel <bot> <pemain|bot lain> &7- paksa bot melawan target",
                "&b/bot say <nama|all> <pesan> &7| &b/bot chat <nama|all> <auto|manual>",
                "&b/bot list &7| &b/bot info <nama>",
                "&b/bot idle|wander|collect <nama|all>",
                "&b/bot follow <nama|all> [pemain]",
                "&b/bot guard <nama|all> [radius] &7- jaga posisimu",
                "&b/bot mine <nama|all> [ores|wood|stone|dirt|all|ore:diamond|MATERIAL]",
                "&b/bot build <nama> <house|tower|wall|fort> &7- bangun di posisimu",
                "&b/bot attack <nama|all> <on|off> &7| &b/bot chat <nama|all> <on|off>",
                "&b/bot tp <nama> &7(kamu ke bot) | &b/bot tphere <nama|all>",
                "&b/bot skin <nama> <skin> | equip <nama> | say <nama> <pesan>",
                "&b/bot sethome <nama> | storage <nama> | reload"
        };
        for (String x : h) s.sendMessage(Msg.c(x));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!m().isReady()) { Msg.send(s, "&cPlugin belum siap, coba lagi sebentar."); return true; }
        if (a.length == 0) {
            if (s instanceof Player && s.hasPermission("fakeplayer.gui")) plugin.menus().openMain((Player) s);
            else help(s);
            return true;
        }
        String sub = a[0].toLowerCase();
        Player pl = s instanceof Player ? (Player) s : null;
        switch (sub) {
            case "help": help(s); break;
            case "menu": case "gui":
                if (pl == null) Msg.send(s, "&cHanya untuk pemain."); else plugin.menus().openMain(pl);
                break;
            case "reload":
                if (!perm(s, "fakeplayer.admin")) break;
                plugin.reloadConfig(); m().applyProtection(); m().reapplyRanks();
                Msg.send(s, "&aConfig di-reload.");
                break;
            case "list": {
                if (!perm(s, "fakeplayer.use")) break;
                Msg.send(s, "&7Bot (&f" + m().all().size() + "&7):");
                for (Bot b : m().all()) s.sendMessage(Msg.c(" &8- " + (!b.online ? "&7" : b.isAlive() ? "&a" : "&c") + b.name + " &7[" + (b.online ? b.mode.label : "offline") + "]"));
                break;
            }
            case "info": {
                if (!perm(s, "fakeplayer.use") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot info <nama>"); break; }
                for (Bot b : targets(s, a[1])) {
                    Location l = b.lastLoc;
                    Msg.send(s, "&f" + b.name + " &7mode=&f" + b.mode.label + " &7agresif=&f" + b.aggressive + " &7hidup=&f" + b.isAlive()
                            + " &7ditambang=&f" + b.mined + " &7dibangun=&f" + b.built + " &7gudang=&f" + b.storedTotal()
                            + (l == null || l.getWorld() == null ? "" : " &7di &f" + l.getWorld().getName() + " " + l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ()));
                }
                break;
            }
            case "create": {
                if (!perm(s, "fakeplayer.spawn")) break;
                if (a.length < 2) { Msg.send(s, "&7/bot create <nama>"); break; }
                String name = a[1];
                if (!BotManager.validName(name)) { Msg.send(s, "&cNama harus 3-16 karakter (huruf, angka, _)."); break; }
                if (m().get(name) != null || Bukkit.getPlayerExact(name) != null) { Msg.send(s, "&cNama sudah dipakai."); break; }
                if (m().all().size() >= plugin.getConfig().getInt("bots.max-bots", 100)) { Msg.send(s, "&cBatas bot tercapai."); break; }
                m().createBot(name, pl);
                Msg.send(s, "&aBot &f" + name + "&a dibuat (offline). Munculkan dengan &f/bot spawn " + name);
                break;
            }
            case "spawn": {
                if (!perm(s, "fakeplayer.spawn")) break;
                if (pl == null) { Msg.send(s, "&cHanya untuk pemain."); break; }
                if (a.length < 2) { Msg.send(s, "&7/bot spawn <nama|all> &8(buat dulu: /bot create <nama>)"); break; }
                if (a[1].equalsIgnoreCase("all")) { Msg.send(s, "&a" + m().spawnAll(pl.getLocation(), pl) + " bot di-spawn."); break; }
                Bot b = m().get(a[1]);
                if (b == null) {
                    if (plugin.getConfig().getBoolean("bots.require-create", true)) { Msg.send(s, "&cBot belum dibuat. Pakai &f/bot create " + a[1]); break; }
                    if (!BotManager.validName(a[1]) || Bukkit.getPlayerExact(a[1]) != null) { Msg.send(s, "&cNama tidak valid / dipakai."); break; }
                    b = m().createBot(a[1], pl);
                }
                if (b.online) { Msg.send(s, "&cBot sudah online."); break; }
                m().spawnBot(b, pl.getLocation(), pl, false);
                Msg.send(s, "&aBot &f" + b.name + "&a di-spawn.");
                break;
            }
            case "despawn": {
                if (!perm(s, "fakeplayer.spawn")) break;
                if (a.length < 2) { Msg.send(s, "&7/bot despawn <nama|all>"); break; }
                for (Bot b : targets(s, a[1])) { m().despawnBot(b, false); Msg.send(s, "&7Bot &f" + b.name + "&7 di-offline-kan."); }
                break;
            }
            case "random": {
                if (!perm(s, "fakeplayer.spawn")) break;
                if (pl == null) { Msg.send(s, "&cHanya untuk pemain."); break; }
                int n = 1;
                try { if (a.length > 1) n = Math.max(1, Integer.parseInt(a[1])); } catch (NumberFormatException e) { Msg.send(s, "&cJumlah tidak valid."); break; }
                List<Bot> l = m().spawnRandom(pl.getLocation(), n, pl);
                Msg.send(s, "&a" + l.size() + " bot di-spawn. Total: &f" + m().all().size());
                break;
            }
            case "remove": case "delete": case "removeall": {
                if (!perm(s, "fakeplayer.remove")) break;
                if (sub.equals("removeall") || (a.length > 1 && a[1].equalsIgnoreCase("all"))) {
                    m().removeAll();
                    Msg.send(s, "&cSemua bot dihapus.");
                } else if (a.length > 1) {
                    for (Bot b : targets(s, a[1])) { m().remove(b, false); Msg.send(s, "&cBot &f" + b.name + "&c dihapus."); }
                } else Msg.send(s, "&7/bot delete <nama|all>");
                break;
            }
            case "idle": case "stop": case "wander": case "collect": case "follow": case "explore": case "auto": {
                if (!perm(s, "fakeplayer.control") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot " + sub + " <nama|all>"); break; }
                BotMode mode = sub.equals("explore") ? BotMode.EXPLORE : sub.equals("auto") ? BotMode.AUTO : sub.equals("wander") ? BotMode.WANDER : sub.equals("collect") ? BotMode.COLLECT : sub.equals("follow") ? BotMode.FOLLOW : BotMode.IDLE;
                Player who = pl;
                if (mode == BotMode.FOLLOW && a.length > 2) {
                    who = Bukkit.getPlayerExact(a[2]);
                    if (who == null) { Msg.send(s, "&cPemain tidak ditemukan."); break; }
                }
                if (mode == BotMode.FOLLOW && who == null) { Msg.send(s, "&cSebutkan nama pemain."); break; }
                for (Bot b : targets(s, a[1])) {
                    m().setMode(b, mode, pl);
                    if (mode == BotMode.FOLLOW) b.followTarget = who.getUniqueId();
                    Msg.send(s, "&f" + b.name + " &7→ &a" + mode.label);
                }
                break;
            }
            case "guard": {
                if (!perm(s, "fakeplayer.control") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot guard <nama|all> [radius]"); break; }
                if (pl == null) { Msg.send(s, "&cHanya untuk pemain."); break; }
                int r = 10;
                try { if (a.length > 2) r = Integer.parseInt(a[2]); } catch (NumberFormatException e) { Msg.send(s, "&cRadius tidak valid."); break; }
                for (Bot b : targets(s, a[1])) { m().setGuard(b, pl.getLocation(), r, pl); Msg.send(s, "&f" + b.name + " &7menjaga posisimu (radius " + b.radius + ")"); }
                break;
            }
            case "mine": {
                if (!perm(s, "fakeplayer.control") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot mine <nama|all> [preset]"); break; }
                String preset = a.length > 2 ? a[2] : "ores";
                if (MinePresets.resolve(preset) == null) { Msg.send(s, "&cPreset/material tidak valid: &f" + preset); break; }
                for (Bot b : targets(s, a[1])) { m().setMine(b, preset, pl); Msg.send(s, "&f" + b.name + " &7mining &a" + preset); }
                break;
            }
            case "build": {
                if (!perm(s, "fakeplayer.control")) break;
                if (a.length < 3) { Msg.send(s, "&7/bot build <nama> <house|tower|wall|fort>"); break; }
                String type = a[2].toLowerCase();
                if (!Structures.TYPES.contains(type)) { Msg.send(s, "&cTipe: &f" + Structures.TYPES); break; }
                Bot b = m().get(a[1]);
                if (b == null) { Msg.send(s, "&cBot tidak ditemukan."); break; }
                Location origin = pl != null ? pl.getLocation() : b.lastLoc;
                if (origin == null) { Msg.send(s, "&cLokasi tidak diketahui."); break; }
                m().startBuild(b, type, origin, pl);
                Msg.send(s, "&f" + b.name + " &7mulai membangun &a" + type);
                break;
            }
            case "attack": case "chat": {
                if (!perm(s, sub.equals("chat") ? "fakeplayer.chat" : "fakeplayer.control") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot " + sub + " <nama|all> <" + (sub.equals("chat") ? "auto|manual" : "on|off") + ">"); break; }
                boolean v = a[2].equalsIgnoreCase("on") || a[2].equalsIgnoreCase("true") || a[2].equalsIgnoreCase("auto");
                for (Bot b : targets(s, a[1])) {
                    if (sub.equals("attack")) { b.aggressive = v; m().gear(b); } else b.chat = v;
                    Msg.send(s, "&f" + b.name + " &7" + sub + ": " + (v ? "&aON" : "&cOFF"));
                }
                break;
            }
            case "tp": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                Bot b = m().get(a[1]);
                if (b == null || !b.isAlive()) { Msg.send(s, "&cBot tidak ditemukan / mati."); break; }
                pl.teleport(b.player().getLocation());
                break;
            }
            case "tphere": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                for (Bot b : targets(s, a[1])) if (b.isAlive()) b.npc.teleport(pl.getLocation(), TeleportCause.PLUGIN);
                break;
            }
            case "skin": {
                if (!perm(s, "fakeplayer.control") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot skin <nama|all> <nama-akun>  atau  /bot skin <nama|all> url <link-png>"); break; }
                String url = a[2].equalsIgnoreCase("url") && a.length > 3 ? a[3] : (a[2].startsWith("http") ? a[2] : null);
                for (Bot b : targets(s, a[1])) {
                    if (url != null) {
                        Msg.send(s, "&7Mengunduh skin untuk &f" + b.name + "&7...");
                        m().setSkinUrl(b, url, msg -> Msg.send(s, msg));
                    } else { m().setSkin(b, a[2]); Msg.send(s, "&aSkin &f" + b.name + "&a → &f" + a[2]); }
                }
                break;
            }
            case "equip": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                for (Bot b : targets(s, a[1])) m().equipItem(b, pl.getInventory().getItemInMainHand());
                Msg.send(s, "&aItem dipasang.");
                break;
            }
            case "say": {
                if (!perm(s, "fakeplayer.chat") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot say <nama|all> <pesan>"); break; }
                String text = String.join(" ", Arrays.copyOfRange(a, 2, a.length));
                for (Bot b : targets(s, a[1])) if (b.online) m().say(b, text);
                break;
            }
            case "inv": {
                if (!perm(s, "fakeplayer.inventory")) break;
                if (pl == null || a.length < 2) { Msg.send(s, pl == null ? "&cHanya untuk pemain." : "&7/bot inv <nama>"); break; }
                Bot b = m().get(a[1]);
                if (b == null) { Msg.send(s, "&cBot tidak ditemukan."); break; }
                plugin.menus().openInv(pl, b);
                break;
            }
            case "hotbar": {
                if (!perm(s, "fakeplayer.inventory") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot hotbar <nama|all> <1-9>"); break; }
                int n;
                try { n = Integer.parseInt(a[2]); } catch (NumberFormatException e) { Msg.send(s, "&cAngka 1-9."); break; }
                if (n < 1 || n > 9) { Msg.send(s, "&cAngka 1-9."); break; }
                for (Bot b : targets(s, a[1])) { m().setHotbarSlot(b, n - 1); Msg.send(s, "&f" + b.name + " &7slot aktif: &a" + n); }
                break;
            }
            case "give": {
                if (!perm(s, "fakeplayer.inventory") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); else if (a.length < 2) Msg.send(s, "&7/bot give <nama|all> &8(item di tanganmu)"); break; }
                org.bukkit.inventory.ItemStack it = pl.getInventory().getItemInMainHand();
                if (it == null || it.getType() == org.bukkit.Material.AIR) { Msg.send(s, "&cPegang item dulu."); break; }
                for (Bot b : targets(s, a[1])) Msg.send(s, m().giveItem(b, it) ? "&aItem diberikan ke &f" + b.name : "&cInventory &f" + b.name + "&c penuh.");
                break;
            }
            case "clearinv": case "resetinv": {
                if (!perm(s, "fakeplayer.inventory") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot " + sub + " <nama|all>"); break; }
                for (Bot b : targets(s, a[1])) {
                    if (sub.equals("clearinv")) m().clearInv(b); else m().resetInv(b);
                    Msg.send(s, "&7Inventory &f" + b.name + "&7 " + (sub.equals("clearinv") ? "dikosongkan." : "dikembalikan ke default."));
                }
                break;
            }
            case "kit": {
                if (!perm(s, "fakeplayer.inventory") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot kit <nama|all> <" + String.join("|", Kits.NAMES) + ">"); break; }
                String kit = a[2].toLowerCase();
                if (!Kits.NAMES.contains(kit)) { Msg.send(s, "&cKit: &f" + Kits.NAMES); break; }
                for (Bot b : targets(s, a[1])) {
                    Msg.send(s, Kits.apply(m(), b, kit) ? "&aKit &f" + kit + "&a dipasang ke &f" + b.name : "&cKit &f" + kit + "&c tidak tersedia di versi server ini.");
                }
                break;
            }
            case "pvp": {
                if (!perm(s, "fakeplayer.control") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot pvp <nama|all> <auto|sword|crystal|mace|off>"); break; }
                String st = a[2].toLowerCase();
                if (!Arrays.asList("auto", "sword", "crystal", "mace", "off").contains(st)) { Msg.send(s, "&cGaya: auto, sword, crystal, mace, off"); break; }
                for (Bot b : targets(s, a[1])) { b.pvpStyle = st; Msg.send(s, "&f" + b.name + " &7gaya PvP: &a" + st); }
                m().save();
                break;
            }
            case "duel": {
                if (!perm(s, "fakeplayer.control") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot duel <bot> <pemain|bot lain>"); break; }
                Bot b = m().get(a[1]);
                if (b == null || !b.isAlive()) { Msg.send(s, "&cBot tidak ditemukan / offline."); break; }
                org.bukkit.entity.Entity te = Bukkit.getPlayerExact(a[2]);
                Bot ob = null;
                if (te == null) { ob = m().get(a[2]); if (ob != null && ob.isAlive()) te = ob.player(); }
                if (te == null || te.getUniqueId().equals(b.player().getUniqueId())) { Msg.send(s, "&cTarget tidak ditemukan."); break; }
                long until = System.currentTimeMillis() + 180000L;
                b.revenge = te.getUniqueId(); b.revengeUntil = until; b.duel = true;
                if (ob != null) { ob.revenge = b.player().getUniqueId(); ob.revengeUntil = until; ob.duel = true; }
                Msg.send(s, "&f" + b.name + " &7melawan &f" + a[2] + "&7 selama 3 menit.");
                break;
            }
            case "rank": {
                if (!perm(s, "fakeplayer.rank") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot rank <nama|all> <grup|none>"); break; }
                if (plugin.luck() == null) { Msg.send(s, "&cLuckPerms tidak terpasang."); break; }
                String g = null;
                if (!a[2].equalsIgnoreCase("none")) {
                    g = plugin.luck().find(a[2]);
                    if (g == null) { Msg.send(s, "&cGrup tidak ada. Grup: &f" + plugin.luck().groups()); break; }
                }
                for (Bot b : targets(s, a[1])) { m().setRank(b, g); Msg.send(s, "&f" + b.name + " &7rank: &a" + (g == null ? "-" : g)); }
                break;
            }
            case "possess": {
                if (!perm(s, "fakeplayer.possess")) break;
                if (pl == null) { Msg.send(s, "&cHanya untuk pemain."); break; }
                if (a.length < 2) { Msg.send(s, "&7/bot possess <nama>"); break; }
                Bot b = m().get(a[1]);
                if (b == null) { Msg.send(s, "&cBot tidak ditemukan."); break; }
                plugin.possession().start(pl, b);
                break;
            }
            case "release": {
                if (!perm(s, "fakeplayer.possess")) break;
                if (pl == null) { Msg.send(s, "&cHanya untuk pemain."); break; }
                if (!plugin.possession().isPossessing(pl)) Msg.send(s, "&cKamu tidak sedang merasuki bot.");
                else plugin.possession().stop(pl);
                break;
            }
            case "sethome": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                for (Bot b : targets(s, a[1])) { b.home = pl.getLocation().clone(); Msg.send(s, "&aHome &f" + b.name + "&a di-set."); }
                m().save();
                break;
            }
            case "storage": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                Bot b = m().get(a[1]);
                if (b == null) { Msg.send(s, "&cBot tidak ditemukan."); break; }
                plugin.menus().openStorage(pl, b);
                break;
            }
            default: help(s);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : SUBS) if (x.startsWith(a[0].toLowerCase())) out.add(x);
            return out;
        }
        String sub = a[0].toLowerCase();
        if (a.length == 2 && (sub.equals("spawn") || sub.equals("despawn"))) {
            boolean online = sub.equals("despawn");
            for (Bot b : m().all()) if (b.online == online && b.name.toLowerCase().startsWith(a[1].toLowerCase())) out.add(b.name);
            if ("all".startsWith(a[1].toLowerCase())) out.add("all");
            return out;
        }
        if (a.length == 2 && !Arrays.asList("create", "random", "list", "removeall", "reload", "help", "menu", "release").contains(sub)) {
            for (Bot b : m().all()) if (b.name.toLowerCase().startsWith(a[1].toLowerCase())) out.add(b.name);
            if ("all".startsWith(a[1].toLowerCase())) out.add("all");
            return out;
        }
        if (a.length == 3) {
            List<String> opts = new ArrayList<>();
            if (sub.equals("mine")) {
                opts.addAll(MinePresets.KEYS);
                for (String o : MinePresets.ORE_NAMES) opts.add("ore:" + o);
            } else if (sub.equals("build")) opts.addAll(Structures.TYPES);
            else if (sub.equals("attack")) opts.addAll(Arrays.asList("on", "off"));
            else if (sub.equals("chat")) opts.addAll(Arrays.asList("auto", "manual"));
            else if (sub.equals("kit")) opts.addAll(Kits.NAMES);
            else if (sub.equals("pvp")) opts.addAll(Arrays.asList("auto", "sword", "crystal", "mace", "off"));
            else if (sub.equals("duel")) { for (Player p : Bukkit.getOnlinePlayers()) opts.add(p.getName()); for (Bot b : m().all()) opts.add(b.name); }
            else if (sub.equals("hotbar")) opts.addAll(Arrays.asList("1", "2", "3", "4", "5", "6", "7", "8", "9"));
            else if (sub.equals("rank")) { opts.add("none"); if (plugin.luck() != null) opts.addAll(plugin.luck().groups()); }
            else if (sub.equals("follow")) for (Player p : Bukkit.getOnlinePlayers()) opts.add(p.getName());
            for (String o : opts) if (o.toLowerCase().startsWith(a[2].toLowerCase())) out.add(o);
        }
        return out;
    }
}
