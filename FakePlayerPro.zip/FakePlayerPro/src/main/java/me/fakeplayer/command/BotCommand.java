package me.fakeplayer.command;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.*;
import me.fakeplayer.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

import java.util.*;

public class BotCommand implements CommandExecutor, TabCompleter {
    private final FakePlayerPlugin plugin;

    private static final List<String> SUBS = Arrays.asList("menu", "spawn", "random", "remove", "removeall", "list", "info",
            "idle", "wander", "follow", "collect", "guard", "mine", "build", "attack", "chat", "tp", "tphere", "skin",
            "equip", "say", "sethome", "storage", "stop", "reload", "help");

    public BotCommand(FakePlayerPlugin plugin) { this.plugin = plugin; }

    private BotManager m() { return plugin.bots(); }

    private boolean perm(CommandSender s, String p) {
        if (s.hasPermission(p)) return true;
        Msg.send(s, "&cKamu tidak punya izin &f" + p);
        return false;
    }

    private List<Bot> targets(CommandSender s, String t) {
        List<Bot> l = new ArrayList<>();
        if (t.equalsIgnoreCase("all") || t.equals("*")) l.addAll(m().all());
        else {
            Bot b = m().get(t);
            if (b != null) l.add(b);
        }
        if (l.isEmpty()) Msg.send(s, "&cBot tidak ditemukan: &f" + t);
        return l;
    }

    private void help(CommandSender s) {
        String[] h = {
                "&b/bot &7- buka menu GUI",
                "&b/bot spawn <nama> &7- spawn bot di posisimu",
                "&b/bot random <jumlah> &7- spawn bot acak",
                "&b/bot remove <nama|all> &7- hapus bot",
                "&b/bot list &7| &b/bot info <nama>",
                "&b/bot idle|wander|collect <nama|all>",
                "&b/bot follow <nama|all> [pemain]",
                "&b/bot guard <nama|all> [radius] &7- jaga posisimu",
                "&b/bot mine <nama|all> [ores|wood|stone|dirt|all|ore:diamond|MATERIAL]",
                "&b/bot build <nama> <house|tower|wall|fort> &7- bangun di posisimu",
                "&b/bot attack <nama|all> <on|off> &7| &b/bot chat <nama|all> <on|off>",
                "&b/bot tp <nama> &7(kamu ke bot) | &b/bot tphere <nama|all>",
                "&b/bot skin <nama> <skin> | equip <nama> | say <nama> <pesan>",
                "&b/bot sethome <nama> | storage <nama> | reload"
        };
        for (String x : h) s.sendMessage(Msg.c(x));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!m().isReady()) { Msg.send(s, "&cPlugin belum siap, coba lagi sebentar."); return true; }
        if (a.length == 0) {
            if (s instanceof Player && s.hasPermission("fakeplayer.gui")) plugin.menus().openMain((Player) s);
            else help(s);
            return true;
        }
        String sub = a[0].toLowerCase();
        Player pl = s instanceof Player ? (Player) s : null;
        switch (sub) {
            case "help": help(s); break;
            case "menu": case "gui":
                if (pl == null) Msg.send(s, "&cHanya untuk pemain."); else plugin.menus().openMain(pl);
                break;
            case "reload":
                if (!perm(s, "fakeplayer.admin")) break;
                plugin.reloadConfig(); m().applyProtection();
                Msg.send(s, "&aConfig di-reload.");
                break;
            case "list": {
                if (!perm(s, "fakeplayer.use")) break;
                Msg.send(s, "&7Bot (&f" + m().all().size() + "&7):");
                for (Bot b : m().all()) s.sendMessage(Msg.c(" &8- " + (b.isAlive() ? "&a" : "&c") + b.name + " &7[" + b.mode.label + "]"));
                break;
            }
            case "info": {
                if (!perm(s, "fakeplayer.use") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot info <nama>"); break; }
                for (Bot b : targets(s, a[1])) {
                    Location l = b.lastLoc;
                    Msg.send(s, "&f" + b.name + " &7mode=&f" + b.mode.label + " &7agresif=&f" + b.aggressive + " &7hidup=&f" + b.isAlive()
                            + " &7ditambang=&f" + b.mined + " &7dibangun=&f" + b.built + " &7gudang=&f" + b.storedTotal()
                            + (l == null || l.getWorld() == null ? "" : " &7di &f" + l.getWorld().getName() + " " + l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ()));
                }
                break;
            }
            case "spawn": {
                if (!perm(s, "fakeplayer.spawn")) break;
                if (pl == null) { Msg.send(s, "&cHanya untuk pemain."); break; }
                if (m().all().size() >= plugin.getConfig().getInt("bots.max-bots", 100)) { Msg.send(s, "&cBatas bot tercapai."); break; }
                String name = a.length > 1 ? a[1] : m().randomName();
                if (!BotManager.validName(name)) { Msg.send(s, "&cNama harus 3-16 karakter (huruf, angka, _)."); break; }
                if (m().get(name) != null || Bukkit.getPlayerExact(name) != null) { Msg.send(s, "&cNama sudah dipakai."); break; }
                m().spawn(name, pl.getLocation(), pl, false);
                Msg.send(s, "&aBot &f" + name + "&a di-spawn.");
                break;
            }
            case "random": {
                if (!perm(s, "fakeplayer.spawn")) break;
                if (pl == null) { Msg.send(s, "&cHanya untuk pemain."); break; }
                int n = 1;
                try { if (a.length > 1) n = Math.max(1, Integer.parseInt(a[1])); } catch (NumberFormatException e) { Msg.send(s, "&cJumlah tidak valid."); break; }
                List<Bot> l = m().spawnRandom(pl.getLocation(), n, pl);
                Msg.send(s, "&a" + l.size() + " bot di-spawn. Total: &f" + m().all().size());
                break;
            }
            case "remove": case "removeall": {
                if (!perm(s, "fakeplayer.remove")) break;
                if (sub.equals("removeall") || (a.length > 1 && a[1].equalsIgnoreCase("all"))) {
                    m().removeAll();
                    Msg.send(s, "&cSemua bot dihapus.");
                } else if (a.length > 1) {
                    for (Bot b : targets(s, a[1])) { m().remove(b, false); Msg.send(s, "&cBot &f" + b.name + "&c dihapus."); }
                } else Msg.send(s, "&7/bot remove <nama|all>");
                break;
            }
            case "idle": case "stop": case "wander": case "collect": case "follow": {
                if (!perm(s, "fakeplayer.control") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot " + sub + " <nama|all>"); break; }
                BotMode mode = sub.equals("wander") ? BotMode.WANDER : sub.equals("collect") ? BotMode.COLLECT : sub.equals("follow") ? BotMode.FOLLOW : BotMode.IDLE;
                Player who = pl;
                if (mode == BotMode.FOLLOW && a.length > 2) {
                    who = Bukkit.getPlayerExact(a[2]);
                    if (who == null) { Msg.send(s, "&cPemain tidak ditemukan."); break; }
                }
                if (mode == BotMode.FOLLOW && who == null) { Msg.send(s, "&cSebutkan nama pemain."); break; }
                for (Bot b : targets(s, a[1])) {
                    m().setMode(b, mode, pl);
                    if (mode == BotMode.FOLLOW) b.followTarget = who.getUniqueId();
                    Msg.send(s, "&f" + b.name + " &7→ &a" + mode.label);
                }
                break;
            }
            case "guard": {
                if (!perm(s, "fakeplayer.control") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot guard <nama|all> [radius]"); break; }
                if (pl == null) { Msg.send(s, "&cHanya untuk pemain."); break; }
                int r = 10;
                try { if (a.length > 2) r = Integer.parseInt(a[2]); } catch (NumberFormatException e) { Msg.send(s, "&cRadius tidak valid."); break; }
                for (Bot b : targets(s, a[1])) { m().setGuard(b, pl.getLocation(), r, pl); Msg.send(s, "&f" + b.name + " &7menjaga posisimu (radius " + b.radius + ")"); }
                break;
            }
            case "mine": {
                if (!perm(s, "fakeplayer.control") || a.length < 2) { if (a.length < 2) Msg.send(s, "&7/bot mine <nama|all> [preset]"); break; }
                String preset = a.length > 2 ? a[2] : "ores";
                if (MinePresets.resolve(preset) == null) { Msg.send(s, "&cPreset/material tidak valid: &f" + preset); break; }
                for (Bot b : targets(s, a[1])) { m().setMine(b, preset, pl); Msg.send(s, "&f" + b.name + " &7mining &a" + preset); }
                break;
            }
            case "build": {
                if (!perm(s, "fakeplayer.control")) break;
                if (a.length < 3) { Msg.send(s, "&7/bot build <nama> <house|tower|wall|fort>"); break; }
                String type = a[2].toLowerCase();
                if (!Structures.TYPES.contains(type)) { Msg.send(s, "&cTipe: &f" + Structures.TYPES); break; }
                Bot b = m().get(a[1]);
                if (b == null) { Msg.send(s, "&cBot tidak ditemukan."); break; }
                Location origin = pl != null ? pl.getLocation() : b.lastLoc;
                if (origin == null) { Msg.send(s, "&cLokasi tidak diketahui."); break; }
                m().startBuild(b, type, origin, pl);
                Msg.send(s, "&f" + b.name + " &7mulai membangun &a" + type);
                break;
            }
            case "attack": case "chat": {
                if (!perm(s, "fakeplayer.control") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot " + sub + " <nama|all> <on|off>"); break; }
                boolean v = a[2].equalsIgnoreCase("on") || a[2].equalsIgnoreCase("true");
                for (Bot b : targets(s, a[1])) {
                    if (sub.equals("attack")) { b.aggressive = v; m().gear(b); } else b.chat = v;
                    Msg.send(s, "&f" + b.name + " &7" + sub + ": " + (v ? "&aON" : "&cOFF"));
                }
                break;
            }
            case "tp": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                Bot b = m().get(a[1]);
                if (b == null || !b.isAlive()) { Msg.send(s, "&cBot tidak ditemukan / mati."); break; }
                pl.teleport(b.player().getLocation());
                break;
            }
            case "tphere": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                for (Bot b : targets(s, a[1])) if (b.isAlive()) b.npc.teleport(pl.getLocation(), TeleportCause.PLUGIN);
                break;
            }
            case "skin": {
                if (!perm(s, "fakeplayer.control") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot skin <nama|all> <nama-akun>  atau  /bot skin <nama|all> url <link-png>"); break; }
                String url = a[2].equalsIgnoreCase("url") && a.length > 3 ? a[3] : (a[2].startsWith("http") ? a[2] : null);
                for (Bot b : targets(s, a[1])) {
                    if (url != null) {
                        Msg.send(s, "&7Mengunduh skin untuk &f" + b.name + "&7...");
                        m().setSkinUrl(b, url, msg -> Msg.send(s, msg));
                    } else { m().setSkin(b, a[2]); Msg.send(s, "&aSkin &f" + b.name + "&a → &f" + a[2]); }
                }
                break;
            }
            case "equip": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                for (Bot b : targets(s, a[1])) m().equipItem(b, pl.getInventory().getItemInMainHand());
                Msg.send(s, "&aItem dipasang.");
                break;
            }
            case "say": {
                if (!perm(s, "fakeplayer.control") || a.length < 3) { if (a.length < 3) Msg.send(s, "&7/bot say <nama> <pesan>"); break; }
                Bot b = m().get(a[1]);
                if (b == null) { Msg.send(s, "&cBot tidak ditemukan."); break; }
                m().say(b, String.join(" ", Arrays.copyOfRange(a, 2, a.length)));
                break;
            }
            case "sethome": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                for (Bot b : targets(s, a[1])) { b.home = pl.getLocation().clone(); Msg.send(s, "&aHome &f" + b.name + "&a di-set."); }
                m().save();
                break;
            }
            case "storage": {
                if (!perm(s, "fakeplayer.control") || a.length < 2 || pl == null) { if (pl == null) Msg.send(s, "&cHanya untuk pemain."); break; }
                Bot b = m().get(a[1]);
                if (b == null) { Msg.send(s, "&cBot tidak ditemukan."); break; }
                plugin.menus().openStorage(pl, b);
                break;
            }
            default: help(s);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : SUBS) if (x.startsWith(a[0].toLowerCase())) out.add(x);
            return out;
        }
        String sub = a[0].toLowerCase();
        if (a.length == 2 && !Arrays.asList("spawn", "random", "list", "removeall", "reload", "help", "menu").contains(sub)) {
            for (Bot b : m().all()) if (b.name.toLowerCase().startsWith(a[1].toLowerCase())) out.add(b.name);
            if ("all".startsWith(a[1].toLowerCase())) out.add("all");
            return out;
        }
        if (a.length == 3) {
            List<String> opts = new ArrayList<>();
            if (sub.equals("mine")) {
                opts.addAll(MinePresets.KEYS);
                for (String o : MinePresets.ORE_NAMES) opts.add("ore:" + o);
            } else if (sub.equals("build")) opts.addAll(Structures.TYPES);
            else if (sub.equals("attack") || sub.equals("chat")) opts.addAll(Arrays.asList("on", "off"));
            else if (sub.equals("follow")) for (Player p : Bukkit.getOnlinePlayers()) opts.add(p.getName());
            for (String o : opts) if (o.toLowerCase().startsWith(a[2].toLowerCase())) out.add(o);
        }
        return out;
    }
}
