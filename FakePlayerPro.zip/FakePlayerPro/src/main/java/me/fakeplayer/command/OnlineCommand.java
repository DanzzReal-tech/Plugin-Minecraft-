package me.fakeplayer.command;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.util.Msg;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.Map;

/** /online : jumlah pemain + bot per world. */
public class OnlineCommand implements CommandExecutor {
    private final FakePlayerPlugin plugin;

    public OnlineCommand(FakePlayerPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (plugin.bots() == null || !plugin.bots().isReady()) { Msg.send(s, "&cPlugin belum siap."); return true; }
        boolean hideEmpty = plugin.getConfig().getBoolean("online.hide-empty", false);
        int total = 0;
        s.sendMessage(Msg.c("&8&m-----&r &b&lOnline per World &8&m-----"));
        for (Map.Entry<String, int[]> e : plugin.bots().worldCounts().entrySet()) {
            int real = e.getValue()[0], bots = e.getValue()[1];
            if (hideEmpty && real + bots == 0) continue;
            total += real + bots;
            s.sendMessage(Msg.c(" &f" + plugin.bots().worldLabel(e.getKey()) + " &8» &a" + (real + bots) + " &7(&f" + real + " pemain &7+ &b" + bots + " bot&7)"));
        }
        s.sendMessage(Msg.c("&7Total online: &a" + total));
        return true;
    }
}
