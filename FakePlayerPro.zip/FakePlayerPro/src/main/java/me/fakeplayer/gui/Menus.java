package me.fakeplayer.gui;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.*;
import me.fakeplayer.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class Menus {
    private final FakePlayerPlugin plugin;
    private final Map<UUID, Consumer<String>> prompts = new ConcurrentHashMap<>();

    public Menus(FakePlayerPlugin plugin) { this.plugin = plugin; }

    // ---------- util ----------
    static ItemStack it(String mat, String name, String... lore) {
        Material m = Material.matchMaterial(mat);
        if (m == null) m = Material.PAPER;
        ItemStack st = new ItemStack(m);
        ItemMeta meta = st.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Msg.c(name));
            List<String> l = new ArrayList<>();
            for (String s : lore) l.add(Msg.c(s));
            meta.setLore(l);
            st.setItemMeta(meta);
        }
        return st;
    }

    private BotManager mgr() { return plugin.bots(); }
    private FileConfiguration cfg() { return plugin.getConfig(); }

    private boolean can(Player p, String perm) {
        if (p.hasPermission(perm)) return true;
        Msg.send(p, "&cKamu tidak punya izin &f" + perm);
        return false;
    }

    private List<Bot> targets(String t) {
        List<Bot> l = new ArrayList<>();
        if ("*".equals(t)) l.addAll(mgr().all());
        else { Bot b = mgr().get(t); if (b != null) l.add(b); }
        return l;
    }

    private void go(Menu m, Player p) {
        Bukkit.getScheduler().runTask(plugin, () -> p.openInventory(m.getInventory()));
    }

    public void openMain(Player p) {
        if (!mgr().isReady()) { Msg.send(p, "&cPlugin belum siap, coba lagi sebentar."); return; }
        if (can(p, "fakeplayer.gui")) p.openInventory(new Main().getInventory());
    }

    public void openStorage(Player p, Bot b) { p.openInventory(new Storage(b.name).getInventory()); }
    public void openInv(Player p, Bot b) { p.openInventory(new InvMenu(b.name).getInventory()); }

    public void prompt(Player p, String text, Consumer<String> cb) {
        p.closeInventory();
        Msg.send(p, text + " &8(ketik &fbatal&8 untuk membatalkan)");
        prompts.put(p.getUniqueId(), cb);
    }

    public Consumer<String> takePrompt(UUID id) { return prompts.remove(id); }
    public boolean hasPrompt(UUID id) { return prompts.containsKey(id); }

    // ---------- base menu ----------
    public abstract class Menu implements InventoryHolder {
        protected Inventory inv;
        @Override public Inventory getInventory() { return inv; }
        protected void create(int size, String title) { inv = Bukkit.createInventory(this, size, Msg.c(title)); }
        protected void fill() {
            ItemStack g = it("GRAY_STAINED_GLASS_PANE", " ");
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, g);
        }
        protected void back(int slot) { inv.setItem(slot, it("ARROW", "&7« Kembali")); }
        public abstract void click(Player p, int slot, ClickType t);
        public boolean handlesRaw() { return false; }
        public void onRawClick(InventoryClickEvent e) { e.setCancelled(true); }
        public void onRawDrag(InventoryDragEvent e) { e.setCancelled(true); }
        public void onClose(Player p) {}
    }

    // ---------- MAIN ----------
    public class Main extends Menu {
        public Main() {
            create(54, "&8&lFakePlayer &7» Menu Utama");
            fill();
            BotManager m = mgr();
            int alive = 0, mined = 0, built = 0, kills = 0;
            Map<BotMode, Integer> modes = new EnumMap<>(BotMode.class);
            for (Bot b : m.all()) {
                if (b.isAlive()) alive++;
                mined += b.mined; built += b.built; kills += b.kills;
                modes.merge(b.mode, 1, Integer::sum);
            }
            inv.setItem(4, it("NETHER_STAR", "&b&lFakePlayerPro", "&7Total bot: &f" + m.all().size(), "&7Hidup: &a" + alive));
            inv.setItem(10, it("PLAYER_HEAD", "&a&lDaftar Bot", "&7Lihat & kontrol tiap bot"));
            inv.setItem(12, it("EMERALD", "&a&lBuat & Spawn Bot", "&7Buat bot, spawn, atau despawn"));
            inv.setItem(14, it("COMMAND_BLOCK", "&e&lPerintah Semua Bot", "&7Atur seluruh bot sekaligus"));
            inv.setItem(16, it("COMPARATOR", "&6&lPengaturan", "&7Server list, combat, mining, dll"));
            List<String> st = new ArrayList<>();
            st.add("&7Blok ditambang: &f" + mined);
            st.add("&7Blok dibangun: &f" + built);
            st.add("&7Kill: &f" + kills);
            for (Map.Entry<BotMode, Integer> e : modes.entrySet()) st.add("&7" + e.getKey().label + ": &f" + e.getValue());
            inv.setItem(28, it("BOOK", "&b&lStatistik", st.toArray(new String[0])));
            inv.setItem(30, it("TNT", "&c&lHapus Semua Bot", "&7Shift + klik kiri untuk konfirmasi"));
            inv.setItem(32, it("REPEATER", "&d&lReload Config"));
            inv.setItem(34, it("PAPER", "&f&lBantuan", "&7/bot spawn <nama>", "&7/bot random <jumlah>", "&7/bot mine <nama> [ores|wood|stone]",
                    "&7/bot build <nama> <house|tower|wall|fort>", "&7/bot guard <nama> [radius]", "&7/bot help"));
            inv.setItem(49, it("BARRIER", "&cTutup"));
        }

        @Override public void click(Player p, int slot, ClickType t) {
            switch (slot) {
                case 10: go(new BotList(0), p); break;
                case 12: if (can(p, "fakeplayer.spawn")) go(new SpawnMenu(), p); break;
                case 14: if (can(p, "fakeplayer.control")) go(new BotMenu("*"), p); break;
                case 16: if (can(p, "fakeplayer.admin")) go(new Settings(), p); break;
                case 30:
                    if (!can(p, "fakeplayer.remove")) break;
                    if (t == ClickType.SHIFT_LEFT) { mgr().removeAll(); Msg.send(p, "&cSemua bot dihapus."); go(new Main(), p); }
                    else Msg.send(p, "&eTekan &fShift + klik kiri&e untuk konfirmasi.");
                    break;
                case 32:
                    if (can(p, "fakeplayer.admin")) { plugin.reloadConfig(); mgr().applyProtection(); Msg.send(p, "&aConfig di-reload."); }
                    break;
                case 49: p.closeInventory(); break;
                default:
            }
        }
    }

    // ---------- BOT LIST ----------
    public class BotList extends Menu {
        private final int page;
        private final List<Bot> list;

        public BotList(int page) {
            this.list = new ArrayList<>(mgr().all());
            int pages = Math.max(1, (list.size() + 44) / 45);
            this.page = Math.max(0, Math.min(page, pages - 1));
            create(54, "&8&lDaftar Bot &7(" + (this.page + 1) + "/" + pages + ")");
            fill();
            for (int i = 0; i < 45; i++) {
                int idx = this.page * 45 + i;
                if (idx >= list.size()) { inv.setItem(i, null); continue; }
                Bot b = list.get(idx);
                boolean alive = b.isAlive();
                String loc = b.lastLoc == null || b.lastLoc.getWorld() == null ? "-" :
                        b.lastLoc.getWorld().getName() + " " + b.lastLoc.getBlockX() + "," + b.lastLoc.getBlockY() + "," + b.lastLoc.getBlockZ();
                String icon = !b.online ? "LIGHT_GRAY_DYE" : (alive ? b.mode.icon : "SKELETON_SKULL");
                String nm = !b.online ? "&7" + b.name + " &8(offline)" : (alive ? "&a" : "&c") + b.name;
                inv.setItem(i, it(icon, nm,
                        "&7Mode: &f" + b.mode.label, "&7Agresif: " + (b.aggressive ? "&aYa" : "&cTidak"),
                        "&7Lokasi: &f" + loc, "&7Mining: &f" + b.mined + " &7Bangun: &f" + b.built,
                        "", "&eKlik kiri: &7kontrol", b.online ? "&eKlik kanan: &7despawn (offline-kan)" : "&eKlik kanan: &7SPAWN di posisimu",
                        "&eShift+kanan: &7hapus bot permanen"));
            }
            if (this.page > 0) inv.setItem(45, it("ARROW", "&7« Halaman sebelumnya"));
            if (this.page < pages - 1) inv.setItem(53, it("ARROW", "&7Halaman berikutnya »"));
            back(49);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            if (slot == 49) { go(new Main(), p); return; }
            if (slot == 45 && page > 0) { go(new BotList(page - 1), p); return; }
            if (slot == 53) { go(new BotList(page + 1), p); return; }
            if (slot < 0 || slot >= 45) return;
            int idx = page * 45 + slot;
            if (idx >= list.size()) return;
            Bot b = list.get(idx);
            if (t == ClickType.SHIFT_RIGHT) {
                if (can(p, "fakeplayer.remove")) { mgr().remove(b, false); go(new BotList(page), p); }
            } else if (t.isRightClick()) {
                if (!can(p, "fakeplayer.spawn")) return;
                if (b.online) mgr().despawnBot(b, false);
                else mgr().spawnBot(b, p.getLocation(), p, false);
                go(new BotList(page), p);
            } else if (can(p, "fakeplayer.control")) go(new BotMenu(b.name), p);
        }
    }

    // ---------- BOT MENU (satu bot atau "*" semua) ----------
    public class BotMenu extends Menu {
        private final String target;

        public BotMenu(String target) {
            this.target = target;
            boolean all = "*".equals(target);
            List<Bot> ts = targets(target);
            create(54, all ? "&8&lSemua Bot" : "&8&lBot &7» &f" + target);
            fill();
            if (all) {
                inv.setItem(4, it("COMMAND_BLOCK", "&e&lSemua bot", "&7Jumlah: &f" + ts.size()));
            } else if (!ts.isEmpty()) {
                Bot b = ts.get(0);
                Location l = b.lastLoc;
                inv.setItem(4, it(b.isAlive() ? b.mode.icon : "SKELETON_SKULL", "&a&l" + b.name,
                        "&7Mode: &f" + b.mode.label,
                        "&7Lokasi: &f" + (l == null ? "-" : l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ()),
                        "&7Gudang: &f" + b.storedTotal() + " item", "&7Ditambang: &f" + b.mined + "  &7Dibangun: &f" + b.built,
                        "&7Preset mining: &f" + b.minePreset, "&7Radius jaga: &f" + b.radius));
            }
            inv.setItem(10, it("ARMOR_STAND", "&f&lDiam", "&7Berdiri & melihat sekitar"));
            inv.setItem(11, it("LEATHER_BOOTS", "&f&lJalan-jalan", "&7Berkeliaran acak"));
            inv.setItem(12, it("LEAD", "&f&lIkuti Saya", "&7Bot mengikutimu"));
            inv.setItem(13, it("HOPPER", "&f&lKumpulkan Item", "&7Ambil item di tanah sekitar"));
            inv.setItem(14, it("SHIELD", "&f&lJaga di Sini", "&7Jaga posisimu sekarang", "&7Serang mob musuh"));
            inv.setItem(15, it("IRON_PICKAXE", "&6&lMining ›", "&7Pilih target blok"));
            inv.setItem(16, it("BRICKS", "&6&lBangun Base ›", all ? "&cPilih satu bot" : "&7Pilih tipe bangunan"));
            inv.setItem(19, it("DIAMOND_SWORD", "&c&lAgresif", "&7Serang pemain terdekat", "&7Klik untuk ganti"));
            inv.setItem(20, it("WRITABLE_BOOK", "&f&lChat Otomatis", "&7Bot ngobrol sendiri di chat", "&7Klik untuk ganti"));
            inv.setItem(21, it("ENDER_PEARL", "&b&lTeleport Bot ke Saya"));
            if (!all) {
                inv.setItem(22, it("ENDER_EYE", "&b&lTeleport Saya ke Bot"));
                inv.setItem(24, it("RED_BED", "&e&lSet Home Di Sini", "&7Titik respawn & base"));
                inv.setItem(25, it("CHEST", "&6&lGudang Bot", "&7Hasil mining/kumpul item"));
            }
            inv.setItem(23, it("DIAMOND_SWORD", "&b&lPegang Item Tanganku", "&7Bot memegang item di tanganmu"));
            inv.setItem(28, it("SHIELD", "&a&lRadius Jaga ›", "&7Atur radius penjagaan"));
            inv.setItem(29, it("NAME_TAG", "&d&lGanti Skin", "&7Nama akun atau link URL PNG"));
            inv.setItem(30, it("GOLDEN_APPLE", "&c&lPulihkan / Respawn"));
            inv.setItem(34, it("TNT", "&4&lHapus Bot", "&7Shift + klik kiri"));
            inv.setItem(37, it("COMPASS", "&b&lJelajah Dunia", "&7Keliling dunia, bikin portal", "&7dan pindah Overworld/Nether"));
            inv.setItem(38, it("NETHER_STAR", "&d&lMandiri (Auto)", "&7Ganti aktivitas sendiri:", "&7jelajah, mining, bangun, dll"));
            inv.setItem(39, it("OAK_SIGN", "&f&lBicara (manual)", "&7Ketik pesan, bot mengirimnya"));
            if (!all) {
                Bot sb = ts.isEmpty() ? null : ts.get(0);
                inv.setItem(40, it("WITHER_SKELETON_SKULL", "&5&lRasuki Bot", "&7Kendalikan bot langsung", "&7Keluar: /bot release"));
                inv.setItem(41, it(sb != null && sb.online ? "RED_CONCRETE" : "LIME_CONCRETE",
                        sb != null && sb.online ? "&c&lDespawn Bot" : "&a&lSpawn Bot di Sini", "&7Klik untuk ganti"));
                inv.setItem(42, it("CHEST_MINECART", "&6&lInventory & Hotbar", "&7Atur item, armor, dan slot aktif bot"));
            }
            inv.setItem(43, it("GOLDEN_HELMET", "&e&lRank (LuckPerms)", "&7Beri prefix rank ke bot", "&7Ketik nama grup / none"));
            inv.setItem(44, it("NETHERITE_SWORD", "&c&lKit & Gaya PvP ›", "&7Sword, axe, crystal, mace", "&7Bot bertarung seperti pemain pro"));
            back(49);
        }

        private void mode(Player p, BotMode m) {
            if (!can(p, "fakeplayer.control")) return;
            for (Bot b : targets(target)) {
                if (m == BotMode.GUARD) mgr().setGuard(b, p.getLocation(), b.radius, p);
                else mgr().setMode(b, m, p);
            }
            Msg.send(p, "&aMode: &f" + m.label);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            boolean all = "*".equals(target);
            List<Bot> ts = targets(target);
            if (slot == 49) { go(all ? new Main() : new BotList(0), p); return; }
            if (ts.isEmpty()) { p.closeInventory(); return; }
            String need = (slot == 20 || slot == 39) ? "fakeplayer.chat" : slot == 40 ? "fakeplayer.possess" : slot == 41 ? "fakeplayer.spawn" : slot == 42 ? "fakeplayer.inventory" : slot == 43 ? "fakeplayer.rank" : "fakeplayer.control";
            if (!can(p, need)) return;
            switch (slot) {
                case 42:
                    if (!all) go(new InvMenu(target), p);
                    break;
                case 44: go(new KitMenu(target), p); break;
                case 43:
                    if (plugin.luck() == null) { Msg.send(p, "&cLuckPerms tidak terpasang."); break; }
                    plugin.menus().prompt(p, "&eKetik nama grup LuckPerms (atau &fnone&e untuk hapus rank):", s -> {
                        String g = null;
                        if (!s.equalsIgnoreCase("none")) {
                            g = plugin.luck().find(s);
                            if (g == null) { Msg.send(p, "&cGrup tidak ditemukan. Grup: &f" + plugin.luck().groups()); return; }
                        }
                        for (Bot b : targets(target)) mgr().setRank(b, g);
                        Msg.send(p, g == null ? "&7Rank dihapus." : "&aRank diatur: &f" + g);
                    });
                    break;
                case 37: mode(p, BotMode.EXPLORE); go(new BotMenu(target), p); break;
                case 38: mode(p, BotMode.AUTO); go(new BotMenu(target), p); break;
                case 39:
                    plugin.menus().prompt(p, "&eKetik pesan yang akan diucapkan bot:", s -> {
                        for (Bot b : targets(target)) if (b.online) mgr().say(b, s);
                    });
                    break;
                case 40:
                    if (!all) { p.closeInventory(); plugin.possession().start(p, ts.get(0)); }
                    break;
                case 41:
                    if (!all) {
                        Bot sb = ts.get(0);
                        if (sb.online) mgr().despawnBot(sb, false); else mgr().spawnBot(sb, p.getLocation(), p, false);
                        go(new BotMenu(target), p);
                    }
                    break;
                case 10: mode(p, BotMode.IDLE); go(new BotMenu(target), p); break;
                case 11: mode(p, BotMode.WANDER); go(new BotMenu(target), p); break;
                case 12: mode(p, BotMode.FOLLOW); go(new BotMenu(target), p); break;
                case 13: mode(p, BotMode.COLLECT); go(new BotMenu(target), p); break;
                case 14: mode(p, BotMode.GUARD); go(new BotMenu(target), p); break;
                case 15: go(new MineMenu(target), p); break;
                case 16: if (all) Msg.send(p, "&cPilih satu bot untuk membangun."); else go(new BuildMenu(target), p); break;
                case 19: {
                    boolean v = !ts.get(0).aggressive;
                    for (Bot b : ts) { b.aggressive = v; mgr().gear(b); }
                    Msg.send(p, "&7Agresif: " + (v ? "&aON" : "&cOFF"));
                    break;
                }
                case 20: {
                    boolean v = !ts.get(0).chat;
                    for (Bot b : ts) b.chat = v;
                    Msg.send(p, "&7Chat bot: " + (v ? "&aON" : "&cOFF"));
                    break;
                }
                case 21: for (Bot b : ts) if (b.isAlive()) b.npc.teleport(p.getLocation(), TeleportCause.PLUGIN); Msg.send(p, "&aBot diteleport ke kamu."); break;
                case 22: if (!all && ts.get(0).isAlive()) { p.teleport(ts.get(0).player().getLocation()); p.closeInventory(); } break;
                case 23: for (Bot b : ts) mgr().equipItem(b, p.getInventory().getItemInMainHand()); Msg.send(p, "&aItem dipasang ke bot."); break;
                case 24: if (!all) { ts.get(0).home = p.getLocation().clone(); mgr().save(); Msg.send(p, "&aHome di-set di posisimu."); } break;
                case 25: if (!all) go(new Storage(target), p); break;
                case 28: go(new GuardMenu(target), p); break;
                case 29:
                    plugin.menus().prompt(p, "&eKetik nama akun Minecraft, atau tempel link (URL) gambar skin PNG:", s -> {
                        for (Bot b : targets(target)) {
                            if (s.startsWith("http")) mgr().setSkinUrl(b, s, msg -> Msg.send(p, msg));
                            else mgr().setSkin(b, s);
                        }
                        Msg.send(p, "&aSkin diproses: &f" + s);
                    });
                    break;
                case 30: for (Bot b : ts) { if (b.isAlive()) b.player().setHealth(b.player().getMaxHealth()); else b.respawnAt = 1; } Msg.send(p, "&aDipulihkan."); break;
                case 34:
                    if (!can(p, "fakeplayer.remove")) break;
                    if (t == ClickType.SHIFT_LEFT) { for (Bot b : ts) mgr().remove(b, false); go(all ? new Main() : new BotList(0), p); }
                    else Msg.send(p, "&eTekan &fShift + klik kiri&e untuk konfirmasi.");
                    break;
                default:
            }
        }
    }

    // ---------- MINE MENU ----------
    public class MineMenu extends Menu {
        private final String target;
        private final String[][] presets = {
                {"10", "DIAMOND_PICKAXE", "&b&lSemua Ore", "ores"}, {"11", "OAK_LOG", "&6&lKayu / Tebang Pohon", "wood"},
                {"12", "STONE", "&7&lBatu", "stone"}, {"13", "DIRT", "&6&lTanah & Pasir", "dirt"}, {"14", "NETHERITE_PICKAXE", "&e&lSemua Blok", "all"},
                {"19", "COAL", "&8&lCoal", "ore:coal"}, {"20", "IRON_INGOT", "&f&lIron", "ore:iron"}, {"21", "COPPER_INGOT", "&6&lCopper", "ore:copper"},
                {"22", "GOLD_INGOT", "&e&lGold", "ore:gold"}, {"23", "REDSTONE", "&c&lRedstone", "ore:redstone"}, {"24", "LAPIS_LAZULI", "&9&lLapis", "ore:lapis"},
                {"25", "DIAMOND", "&b&lDiamond", "ore:diamond"}, {"26", "EMERALD", "&a&lEmerald", "ore:emerald"}, {"28", "QUARTZ", "&f&lQuartz", "ore:quartz"}
        };

        public MineMenu(String target) {
            this.target = target;
            create(45, "&8&lMining &7» &f" + ("*".equals(target) ? "Semua" : target));
            fill();
            for (String[] p : presets) inv.setItem(Integer.parseInt(p[0]), it(p[1], p[2], "&7Klik untuk mulai mining"));
            back(40);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            if (slot == 40) { go(new BotMenu(target), p); return; }
            for (String[] pr : presets) {
                if (Integer.parseInt(pr[0]) == slot) {
                    if (!can(p, "fakeplayer.control")) return;
                    for (Bot b : targets(target)) mgr().setMine(b, pr[3], p);
                    Msg.send(p, "&aMining dimulai: &f" + pr[3]);
                    p.closeInventory();
                    return;
                }
            }
        }
    }

    // ---------- BUILD MENU ----------
    public class BuildMenu extends Menu {
        private final String botName;

        public BuildMenu(String botName) {
            this.botName = botName;
            Bot b = mgr().get(botName);
            create(36, "&8&lBangun &7» &f" + botName);
            fill();
            inv.setItem(10, it("OAK_DOOR", "&6&lRumah 7x7", "&7Rumah kecil dengan atap & obor"));
            inv.setItem(12, it("STONE_BRICKS", "&6&lMenara", "&7Menara tinggi 5x5"));
            inv.setItem(14, it("COBBLESTONE_WALL", "&6&lTembok", "&7Tembok 15 blok"));
            inv.setItem(16, it("IRON_DOOR", "&6&lBenteng 15x15", "&7Tembok + 4 menara sudut"));
            inv.setItem(20, it("OBSIDIAN", "&5&lPortal Nether", "&7Bingkai obsidian + portal aktif"));
            inv.setItem(22, it("SHIELD", "&e&lJaga setelah selesai: " + (b != null && b.guardAfterBuild ? "&aON" : "&cOFF")));
            inv.setItem(24, it("BARRIER", "&c&lBatalkan Pembangunan"));
            inv.setItem(35, it("PAPER", "&7Berdiri di titik tengah bangunan", "&7lalu klik tipe yang diinginkan"));
            back(31);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            Bot b = mgr().get(botName);
            if (slot == 31) { go(new BotMenu(botName), p); return; }
            if (b == null || !can(p, "fakeplayer.control")) return;
            String type = null;
            if (slot == 10) type = "house"; else if (slot == 12) type = "tower"; else if (slot == 14) type = "wall"; else if (slot == 16) type = "fort"; else if (slot == 20) type = "portal";
            if (type != null) {
                mgr().startBuild(b, type, p.getLocation(), p);
                Msg.send(p, "&a" + b.name + " mulai membangun &f" + type);
                p.closeInventory();
            } else if (slot == 22) {
                b.guardAfterBuild = !b.guardAfterBuild;
                go(new BuildMenu(botName), p);
            } else if (slot == 24) {
                b.queue = new ArrayList<>(); b.buildIndex = 0;
                mgr().setMode(b, BotMode.IDLE, p);
                Msg.send(p, "&cPembangunan dibatalkan.");
            }
        }
    }

    // ---------- GUARD MENU ----------
    public class GuardMenu extends Menu {
        private final String target;

        public GuardMenu(String target) {
            this.target = target;
            List<Bot> ts = targets(target);
            int r = ts.isEmpty() ? 10 : ts.get(0).radius;
            create(36, "&8&lJaga Base &7» &f" + ("*".equals(target) ? "Semua" : target));
            fill();
            inv.setItem(10, it("RED_STAINED_GLASS_PANE", "&c-5"));
            inv.setItem(11, it("RED_STAINED_GLASS_PANE", "&c-1"));
            inv.setItem(13, it("SHIELD", "&a&lRadius: &f" + r));
            inv.setItem(15, it("LIME_STAINED_GLASS_PANE", "&a+1"));
            inv.setItem(16, it("LIME_STAINED_GLASS_PANE", "&a+5"));
            inv.setItem(22, it("IRON_SWORD", "&e&lMulai Jaga di Posisiku", "&7Base = posisimu sekarang"));
            inv.setItem(24, it("ZOMBIE_HEAD", "&c&lSerang pemain asing: " + (cfg().getBoolean("guard.attack-players", false) ? "&aON" : "&cOFF"), "&7Pemain dengan fakeplayer.bypass aman"));
            back(31);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            if (slot == 31) { go(new BotMenu(target), p); return; }
            if (!can(p, "fakeplayer.control")) return;
            int d = slot == 10 ? -5 : slot == 11 ? -1 : slot == 15 ? 1 : slot == 16 ? 5 : 0;
            if (d != 0) {
                for (Bot b : targets(target)) b.radius = Math.max(2, Math.min(64, b.radius + d));
                go(new GuardMenu(target), p);
            } else if (slot == 22) {
                for (Bot b : targets(target)) mgr().setGuard(b, p.getLocation(), b.radius, p);
                Msg.send(p, "&aBot menjaga posisi ini.");
                p.closeInventory();
            } else if (slot == 24 && can(p, "fakeplayer.admin")) {
                cfg().set("guard.attack-players", !cfg().getBoolean("guard.attack-players", false));
                plugin.saveConfig();
                go(new GuardMenu(target), p);
            }
        }
    }

    // ---------- SPAWN / BUAT MENU ----------
    public class SpawnMenu extends Menu {
        private final int[] counts = {1, 3, 5, 10, 20, 50};

        public SpawnMenu() {
            create(36, "&8&lBuat & Spawn Bot");
            fill();
            inv.setItem(10, it("NAME_TAG", "&e&lBuat Bot Baru", "&7Ketik nama di chat", "&7Bot dibuat offline, lalu spawn dari Daftar Bot"));
            inv.setItem(12, it("LIME_CONCRETE", "&a&lSpawn Semua Bot", "&7Munculkan semua bot yang sudah dibuat", "&7di sekitarmu"));
            inv.setItem(14, it("RED_CONCRETE", "&c&lDespawn Semua Bot", "&7Offline-kan semua bot (data tetap)"));
            inv.setItem(16, it("PLAYER_HEAD", "&b&lDaftar Bot", "&7Klik kanan bot untuk spawn / despawn"));
            for (int i = 0; i < counts.length; i++) {
                ItemStack st = it("EMERALD", "&a&lBuat & spawn " + counts[i] + " bot acak", "&7Nama acak, muncul di sekitarmu");
                st.setAmount(Math.min(64, counts[i]));
                inv.setItem(19 + i, st);
            }
            back(31);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            if (slot == 31) { go(new Main(), p); return; }
            if (slot == 16) { go(new BotList(0), p); return; }
            if (!can(p, "fakeplayer.spawn")) return;
            if (slot >= 19 && slot < 19 + counts.length) {
                List<Bot> l = mgr().spawnRandom(p.getLocation(), counts[slot - 19], p);
                Msg.send(p, "&a" + l.size() + " bot dibuat & di-spawn. Total: &f" + mgr().all().size());
            } else if (slot == 12) {
                Msg.send(p, "&a" + mgr().spawnAll(p.getLocation(), p) + " bot di-spawn.");
            } else if (slot == 14) {
                Msg.send(p, "&7" + mgr().despawnAll() + " bot di-offline-kan.");
            } else if (slot == 10) {
                plugin.menus().prompt(p, "&eKetik nama bot baru (3-16 huruf/angka/_):", s -> {
                    if (!BotManager.validName(s)) { Msg.send(p, "&cNama tidak valid."); return; }
                    if (mgr().get(s) != null || Bukkit.getPlayerExact(s) != null) { Msg.send(p, "&cNama sudah dipakai."); return; }
                    if (mgr().all().size() >= cfg().getInt("bots.max-bots", 100)) { Msg.send(p, "&cBatas bot tercapai."); return; }
                    mgr().createBot(s, p);
                    Msg.send(p, "&aBot &f" + s + "&a dibuat (offline). Buka &fDaftar Bot&a lalu klik kanan untuk spawn.");
                });
            }
        }
    }

    // ---------- SETTINGS ----------
    private static final String[][] TOGGLES = {
            {"server-list.enabled", "COMPASS", "Ubah server list"},
            {"server-list.count-bots", "PLAYER_HEAD", "Hitung bot di jumlah online"},
            {"server-list.show-names", "NAME_TAG", "Nama bot muncul saat hover"},
            {"bots.join-leave-messages", "OAK_DOOR", "Pesan join/leave bot"},
            {"bots.death-messages", "SKELETON_SKULL", "Pesan kematian bot"},
            {"bots.respawn", "TOTEM_OF_UNDYING", "Respawn otomatis"},
            {"bots.auto-heal", "GOLDEN_APPLE", "Bot menyembuhkan diri"},
            {"bots.invulnerable", "SHIELD", "Bot kebal"},
            {"bots.random-armor", "IRON_CHESTPLATE", "Armor acak"},
            {"bots.show-in-tablist", "MAP", "Tampil di tab list (bot baru)"},
            {"combat.aggressive-default", "DIAMOND_SWORD", "Bot baru agresif"},
            {"combat.retaliate", "BLAZE_ROD", "Bot membalas serangan"},
            {"combat.ignore-creative", "GRASS_BLOCK", "Abaikan pemain creative"},
            {"guard.attack-hostile", "ZOMBIE_HEAD", "Penjaga serang mob"},
            {"guard.attack-players", "CROSSBOW", "Penjaga serang pemain asing"},
            {"mining.drop-to-storage", "CHEST", "Hasil mining ke gudang bot"},
            {"mining.avoid-liquid", "WATER_BUCKET", "Hindari blok dekat cairan"},
            {"build.require-materials", "CRAFTING_TABLE", "Bangun butuh material gudang"},
            {"chat.enabled", "WRITABLE_BOOK", "Bot bicara di chat"},
            {"bots.persist", "ENDER_CHEST", "Simpan bot setelah restart"}
    };

    public class Settings extends Menu {
        public Settings() {
            create(54, "&8&lPengaturan");
            fill();
            int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33};
            for (int i = 0; i < TOGGLES.length; i++) {
                boolean v = cfg().getBoolean(TOGGLES[i][0], false);
                inv.setItem(slots[i], it(TOGGLES[i][1], (v ? "&a" : "&c") + TOGGLES[i][2], "&7Status: " + (v ? "&aON" : "&cOFF"), "&8" + TOGGLES[i][0], "&eKlik untuk ganti"));
            }
            back(49);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            if (slot == 49) { go(new Main(), p); return; }
            if (!can(p, "fakeplayer.admin")) return;
            int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33};
            for (int i = 0; i < TOGGLES.length; i++) {
                if (slots[i] == slot) {
                    cfg().set(TOGGLES[i][0], !cfg().getBoolean(TOGGLES[i][0], false));
                    plugin.saveConfig();
                    if (TOGGLES[i][0].equals("bots.invulnerable")) mgr().applyProtection();
                    go(new Settings(), p);
                    return;
                }
            }
        }
    }

    // ---------- KIT & PVP ----------
    public class KitMenu extends Menu {
        private final String target;

        public KitMenu(String target) {
            this.target = target;
            create(36, "&8&lKit & PvP &7» &f" + ("*".equals(target) ? "Semua" : target));
            fill();
            inv.setItem(10, it("NETHERITE_SWORD", "&b&lKit Sword", "&7Netherite + sword + gapple + totem", "&7Crit jump & strafe"));
            inv.setItem(11, it("NETHERITE_AXE", "&b&lKit Axe", "&7Axe + shield, hit lambat tapi kuat"));
            inv.setItem(12, it("END_CRYSTAL", "&d&lKit Crystal (CPvP)", "&7End crystal + obsidian + totem", "&7Bot meledakkan crystal di dekat lawan"));
            inv.setItem(13, it("MACE", "&6&lKit Mace", "&7Lompat tinggi lalu smash dari atas", "&7Butuh server 1.21+"));
            inv.setItem(16, it("BARRIER", "&c&lHapus Kit", "&7Kembali ke perlengkapan default"));
            inv.setItem(19, it("COMPARATOR", "&f&lGaya: auto", "&7Pilih gaya dari isi inventory"));
            inv.setItem(20, it("IRON_SWORD", "&f&lGaya: sword/axe"));
            inv.setItem(21, it("END_CRYSTAL", "&f&lGaya: crystal"));
            inv.setItem(22, it("MACE", "&f&lGaya: mace"));
            inv.setItem(23, it("WOODEN_SWORD", "&f&lGaya: off", "&7Pukulan sederhana biasa"));
            inv.setItem(25, it("DIAMOND_SWORD", "&c&lAgresif ON/OFF", "&7Serang pemain terdekat"));
            back(31);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            if (slot == 31) { go(new BotMenu(target), p); return; }
            if (!can(p, "fakeplayer.inventory")) return;
            List<Bot> ts = targets(target);
            if (ts.isEmpty()) return;
            String kit = slot == 10 ? "sword" : slot == 11 ? "axe" : slot == 12 ? "crystal" : slot == 13 ? "mace" : slot == 16 ? "clear" : null;
            String style = slot == 19 ? "auto" : slot == 20 ? "sword" : slot == 21 ? "crystal" : slot == 22 ? "mace" : slot == 23 ? "off" : null;
            if (kit != null) {
                int ok = 0;
                for (Bot b : ts) if (Kits.apply(mgr(), b, kit)) ok++;
                Msg.send(p, ok > 0 ? "&aKit &f" + kit + "&a dipasang ke &f" + ok + "&a bot." : "&cKit &f" + kit + "&c tidak tersedia di versi server ini.");
            } else if (style != null) {
                for (Bot b : ts) b.pvpStyle = style;
                mgr().save();
                Msg.send(p, "&aGaya PvP: &f" + style);
            } else if (slot == 25) {
                boolean v = !ts.get(0).aggressive;
                for (Bot b : ts) b.aggressive = v;
                Msg.send(p, "&7Agresif: " + (v ? "&aON" : "&cOFF"));
            }
        }
    }

    // ---------- INVENTORY & HOTBAR ----------
    public class InvMenu extends Menu {
        private final String botName;
        private boolean dead;

        public InvMenu(String botName) {
            this.botName = botName;
            Bot b = mgr().get(botName);
            create(54, "&8&lInventory &7» &f" + botName);
            fill();
            if (b != null) {
                if (!b.customInv && b.isAlive()) b.inv = null;
                ItemStack[] a = mgr().ensureInv(b);
                for (int i = 0; i < 27; i++) inv.setItem(i, a[9 + i]);
                for (int i = 0; i < 9; i++) inv.setItem(27 + i, a[i]);
                inv.setItem(45, a[39]); inv.setItem(46, a[38]); inv.setItem(47, a[37]); inv.setItem(48, a[36]); inv.setItem(49, a[40]);
                indicators(b);
            }
            inv.setItem(50, it("PAPER", "&f&lPetunjuk", "&7Baris atas: inventory (3 baris)", "&7Baris 4: hotbar bot", "&7Baris 5: pilih slot aktif",
                    "&745 helm, 46 baju, 47 celana, 48 sepatu,", "&749 tangan kiri", "&7Taruh/ambil item seperti biasa"));
            inv.setItem(51, it("HOPPER", "&b&lSalin inventoriku → bot", "&7Klik kiri: salin semua item & hotbarmu", "&cShift + klik kanan: salin inventori bot → kamu", "&c(menimpa inventorimu!)"));
            inv.setItem(52, it("BARRIER", "&c&lKosongkan", "&7Klik kiri: kosongkan inventory bot", "&7Shift + klik kiri: kembali ke perlengkapan default"));
            inv.setItem(53, it("ARROW", "&7« Kembali"));
        }

        private void indicators(Bot b) {
            for (int i = 0; i < 9; i++) {
                boolean on = i == b.heldSlot;
                inv.setItem(36 + i, it(on ? "LIME_STAINED_GLASS_PANE" : "GRAY_STAINED_GLASS_PANE",
                        (on ? "&a&lSlot aktif: " : "&7Pilih slot ") + (i + 1), "&7Klik untuk jadikan slot aktif"));
            }
        }

        private ItemStack c(ItemStack i) { return i == null || i.getType() == Material.AIR ? null : i.clone(); }

        private boolean editable(int slot) { return (slot >= 0 && slot < 36) || (slot >= 45 && slot <= 49); }

        public void sync() {
            if (dead) return;
            Bot b = mgr().get(botName);
            if (b == null) return;
            ItemStack[] a = new ItemStack[41];
            for (int i = 0; i < 27; i++) a[9 + i] = c(inv.getItem(i));
            for (int i = 0; i < 9; i++) a[i] = c(inv.getItem(27 + i));
            a[39] = c(inv.getItem(45)); a[38] = c(inv.getItem(46)); a[37] = c(inv.getItem(47)); a[36] = c(inv.getItem(48)); a[40] = c(inv.getItem(49));
            b.inv = a;
            b.customInv = true;
            mgr().applyInv(b);
            mgr().save();
        }

        @Override public boolean handlesRaw() { return true; }

        @Override public void onRawClick(InventoryClickEvent e) {
            Player p = (Player) e.getWhoClicked();
            if (!p.hasPermission("fakeplayer.inventory")) { e.setCancelled(true); return; }
            ClickType t = e.getClick();
            boolean inTop = e.getClickedInventory() != null && e.getClickedInventory().equals(inv);
            int slot = e.getSlot();
            if (t == ClickType.DOUBLE_CLICK || t == ClickType.SHIFT_LEFT || t == ClickType.SHIFT_RIGHT
                    || t == ClickType.DROP || t == ClickType.CONTROL_DROP || t == ClickType.CREATIVE) {
                e.setCancelled(true);
                if (inTop) action(p, slot, t);
                return;
            }
            if (inTop && !editable(slot)) { e.setCancelled(true); action(p, slot, t); return; }
            Bukkit.getScheduler().runTask(plugin, this::sync);
        }

        @Override public void onRawDrag(InventoryDragEvent e) {
            for (int raw : e.getRawSlots()) {
                if (raw < inv.getSize() && !editable(raw)) { e.setCancelled(true); return; }
            }
            Bukkit.getScheduler().runTask(plugin, this::sync);
        }

        @Override public void onClose(Player p) { sync(); }

        private void action(Player p, int slot, ClickType t) {
            Bot b = mgr().get(botName);
            if (b == null) return;
            if (slot >= 36 && slot <= 44) {
                sync();
                mgr().setHotbarSlot(b, slot - 36);
                indicators(b);
            } else if (slot == 51) {
                if (t == ClickType.SHIFT_RIGHT) {
                    ItemStack[] a = mgr().ensureInv(b);
                    ItemStack[] copy = new ItemStack[41];
                    for (int i = 0; i < 41; i++) copy[i] = c(a[i]);
                    p.getInventory().setContents(copy);
                    Msg.send(p, "&aInventori bot disalin ke inventorimu.");
                } else if (t == ClickType.LEFT) {
                    dead = true;
                    ItemStack[] src = p.getInventory().getContents();
                    ItemStack[] a = new ItemStack[41];
                    for (int i = 0; i < 41 && i < src.length; i++) a[i] = c(src[i]);
                    b.inv = a;
                    b.heldSlot = p.getInventory().getHeldItemSlot();
                    b.customInv = true;
                    mgr().applyInv(b);
                    mgr().save();
                    Msg.send(p, "&aInventoriku disalin ke bot.");
                    go(new InvMenu(botName), p);
                }
            } else if (slot == 52) {
                dead = true;
                if (t == ClickType.SHIFT_LEFT) { mgr().resetInv(b); Msg.send(p, "&7Perlengkapan bot dikembalikan ke default."); }
                else if (t == ClickType.LEFT) { mgr().clearInv(b); Msg.send(p, "&7Inventory bot dikosongkan."); }
                else dead = false;
                if (dead) go(new InvMenu(botName), p);
            } else if (slot == 53) {
                dead = true;
                sync0(b);
                go(new BotMenu(botName), p);
            }
        }

        private void sync0(Bot b) { dead = false; sync(); dead = true; }
    }

    // ---------- STORAGE ----------
    public class Storage extends Menu {
        private final String botName;
        private final List<Material> mats = new ArrayList<>();

        public Storage(String botName) {
            this.botName = botName;
            Bot b = mgr().get(botName);
            create(54, "&8&lGudang &7» &f" + botName);
            fill();
            for (int i = 0; i < 45; i++) inv.setItem(i, null);
            if (b != null) {
                mats.addAll(b.storage.keySet());
                for (int i = 0; i < mats.size() && i < 45; i++) {
                    Material m = mats.get(i);
                    ItemStack st = new ItemStack(m);
                    ItemMeta meta = st.getItemMeta();
                    if (meta != null) {
                        meta.setLore(Arrays.asList(Msg.c("&7Jumlah: &f" + b.storage.get(m)), Msg.c("&eKlik: ambil 1 stack"), Msg.c("&eShift+klik: ambil semua")));
                        st.setItemMeta(meta);
                    }
                    inv.setItem(i, st);
                }
            }
            inv.setItem(45, it("ARROW", "&7« Kembali"));
            inv.setItem(49, it("HOPPER", "&a&lAmbil Semua"));
        }

        private void give(Player p, Bot b, Material m, int amt) {
            int left = 0;
            int remaining = amt;
            while (remaining > 0) {
                int n = Math.min(remaining, m.getMaxStackSize());
                Map<Integer, ItemStack> over = p.getInventory().addItem(new ItemStack(m, n));
                for (ItemStack o : over.values()) left += o.getAmount();
                remaining -= n;
            }
            int have = b.storage.getOrDefault(m, 0);
            int now = have - amt + left;
            if (now <= 0) b.storage.remove(m); else b.storage.put(m, now);
        }

        @Override public void click(Player p, int slot, ClickType t) {
            Bot b = mgr().get(botName);
            if (slot == 45) { go(new BotMenu(botName), p); return; }
            if (b == null || !can(p, "fakeplayer.control")) return;
            if (slot == 49) {
                for (Material m : new ArrayList<>(b.storage.keySet())) give(p, b, m, b.storage.get(m));
                go(new Storage(botName), p);
            } else if (slot >= 0 && slot < 45 && slot < mats.size()) {
                Material m = mats.get(slot);
                int have = b.storage.getOrDefault(m, 0);
                if (have <= 0) return;
                give(p, b, m, t.isShiftClick() ? have : Math.min(have, m.getMaxStackSize()));
                go(new Storage(botName), p);
            }
        }
    }
}
