package me.fakeplayer.bot;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

/** Kit siap pakai untuk bot PvP (sword, axe, crystal, mace). */
public final class Kits {
    private Kits() {}

    public static final List<String> NAMES = Arrays.asList("sword", "axe", "crystal", "mace", "clear");

    public static ItemStack item(String mat, int amount, String... ench) {
        Material m = Material.matchMaterial(mat);
        if (m == null) return null;
        ItemStack it = new ItemStack(m, amount);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            for (String e : ench) {
                String[] kv = e.split(":");
                Enchantment en = Enchantment.getByKey(NamespacedKey.minecraft(kv[0]));
                if (en != null) meta.addEnchant(en, Integer.parseInt(kv[1]), true);
            }
            it.setItemMeta(meta);
        }
        return it;
    }

    private static void armor(Bot b) {
        // layout sama dengan PlayerInventory#getContents(): 36 sepatu, 37 celana, 38 baju, 39 helm, 40 tangan kiri
        b.inv[39] = item("NETHERITE_HELMET", 1, "protection:4", "unbreaking:3", "mending:1");
        b.inv[38] = item("NETHERITE_CHESTPLATE", 1, "protection:4", "unbreaking:3", "mending:1");
        b.inv[37] = item("NETHERITE_LEGGINGS", 1, "protection:4", "unbreaking:3", "mending:1");
        b.inv[36] = item("NETHERITE_BOOTS", 1, "protection:4", "unbreaking:3", "mending:1");
    }

    /** @return false jika kit tidak tersedia di versi server ini. */
    public static boolean apply(BotManager mgr, Bot b, String kit) {
        kit = kit.toLowerCase();
        if (kit.equals("mace") && Material.matchMaterial("MACE") == null) return false;
        if (kit.equals("clear")) {
            mgr.resetInv(b);
            b.pvpStyle = "auto";
            mgr.save();
            return true;
        }
        b.inv = new ItemStack[41];
        b.heldSlot = 0;
        switch (kit) {
            case "axe":
                armor(b);
                b.inv[0] = item("NETHERITE_AXE", 1, "sharpness:5", "unbreaking:3", "mending:1");
                b.inv[1] = item("ENCHANTED_GOLDEN_APPLE", 16);
                b.inv[2] = item("ENDER_PEARL", 16);
                b.inv[40] = item("SHIELD", 1, "unbreaking:3");
                b.customInv = true;
                b.pvpStyle = "sword";
                break;
            case "crystal":
                armor(b);
                b.inv[0] = item("NETHERITE_SWORD", 1, "sharpness:5", "unbreaking:3", "mending:1");
                b.inv[1] = item("END_CRYSTAL", 64);
                b.inv[2] = item("OBSIDIAN", 64);
                b.inv[3] = item("ENCHANTED_GOLDEN_APPLE", 16);
                b.inv[4] = item("ENDER_PEARL", 16);
                b.inv[5] = item("TOTEM_OF_UNDYING", 4);
                b.inv[40] = item("TOTEM_OF_UNDYING", 1);
                b.customInv = true;
                b.pvpStyle = "crystal";
                break;
            case "mace":
                armor(b);
                b.inv[0] = item("MACE", 1, "density:5", "unbreaking:3", "mending:1");
                b.inv[1] = item("NETHERITE_SWORD", 1, "sharpness:5", "unbreaking:3");
                b.inv[2] = item("WIND_CHARGE", 64);
                b.inv[3] = item("ENCHANTED_GOLDEN_APPLE", 16);
                b.inv[4] = item("ENDER_PEARL", 16);
                b.inv[40] = item("TOTEM_OF_UNDYING", 1);
                b.customInv = true;
                b.pvpStyle = "mace";
                break;
            default: // sword
                armor(b);
                b.inv[0] = item("NETHERITE_SWORD", 1, "sharpness:5", "fire_aspect:2", "unbreaking:3", "mending:1");
                b.inv[1] = item("ENCHANTED_GOLDEN_APPLE", 16);
                b.inv[2] = item("ENDER_PEARL", 16);
                b.inv[3] = item("SHIELD", 1, "unbreaking:3");
                b.inv[40] = item("TOTEM_OF_UNDYING", 1);
                b.customInv = true;
                b.pvpStyle = "sword";
        }
        mgr.applyInv(b);
        mgr.save();
        return true;
    }
}
