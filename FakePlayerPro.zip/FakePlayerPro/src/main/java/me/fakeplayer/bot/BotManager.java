package me.fakeplayer.bot;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.util.Msg;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.MemoryNPCDataStore;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.api.npc.NPCRegistry;
import net.citizensnpcs.api.trait.trait.Equipment;
import net.citizensnpcs.trait.SkinTrait;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class BotManager {
    private final FakePlayerPlugin plugin;
    private final BotBrain brain;
    private final Map<String, Bot> bots = new LinkedHashMap<>();
    private final Random rnd = new Random();
    private volatile List<String> nameCache = Collections.emptyList();
    private NPCRegistry registry;
    private BukkitTask loop, saver;
    private boolean ready;

    public BotManager(FakePlayerPlugin plugin) {
        this.plugin = plugin;
        this.brain = new BotBrain(plugin);
    }

    private FileConfiguration cfg() { return plugin.getConfig(); }

    // ---------- lifecycle ----------
    public void start() {
        registry = CitizensAPI.createAnonymousNPCRegistry(new MemoryNPCDataStore());
        ready = true;
        if (cfg().getBoolean("bots.persist", true)) load();
        int iv = Math.max(1, cfg().getInt("bots.tick-interval", 5));
        loop = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, iv);
        saver = Bukkit.getScheduler().runTaskTimer(plugin, this::save, 6000L, 6000L);
        plugin.getLogger().info("FakePlayerPro aktif, " + bots.size() + " bot dimuat.");
    }

    public void shutdown() {
        if (!ready) return;
        if (loop != null) loop.cancel();
        if (saver != null) saver.cancel();
        save();
        try { registry.deregisterAll(); } catch (Throwable ignored) {}
        ready = false;
    }

    public boolean isReady() { return ready; }

    private void tick() {
        for (Bot b : new ArrayList<>(bots.values())) {
            try {
                brain.tick(b);
            } catch (Throwable t) {
                plugin.getLogger().warning("Error AI bot " + b.name + ": " + t);
            }
        }
    }

    // ---------- query ----------
    public Collection<Bot> all() { return bots.values(); }
    public Bot get(String name) { return name == null ? null : bots.get(name.toLowerCase()); }
    public int count() { return nameCache.size(); }
    public List<String> names() { return nameCache; }

    public Bot byEntity(Entity e) {
        if (e == null || !e.hasMetadata("NPC")) return null;
        for (Bot b : bots.values()) {
            if (b.npc != null && b.npc.isSpawned() && b.npc.getEntity().getUniqueId().equals(e.getUniqueId())) return b;
        }
        return null;
    }

    private void refreshNames() {
        List<String> l = new ArrayList<>();
        for (Bot b : bots.values()) l.add(b.name);
        nameCache = Collections.unmodifiableList(l);
    }

    public String randomName() {
        List<String> pool = cfg().getStringList("bots.name-pool");
        List<String> free = new ArrayList<>();
        for (String n : pool) if (!bots.containsKey(n.toLowerCase()) && Bukkit.getPlayerExact(n) == null) free.add(n);
        if (!free.isEmpty()) return free.get(rnd.nextInt(free.size()));
        String base = pool.isEmpty() ? "Player" : pool.get(rnd.nextInt(pool.size()));
        if (base.length() > 12) base = base.substring(0, 12);
        for (int i = 0; i < 50; i++) {
            String n = base + (10 + rnd.nextInt(990));
            if (!bots.containsKey(n.toLowerCase()) && Bukkit.getPlayerExact(n) == null) return n;
        }
        return "Bot" + (1000 + rnd.nextInt(8999));
    }

    public static boolean validName(String n) {
        return n != null && n.matches("[A-Za-z0-9_]{3,16}");
    }

    // ---------- spawn / remove ----------
    public Bot spawn(String name, Location loc, Player by, boolean silent) {
        Bot b = new Bot(name);
        b.spawnLoc = loc.clone();
        b.lastLoc = loc.clone();
        b.aggressive = cfg().getBoolean("combat.aggressive-default", false);
        b.commander = by == null ? null : by.getUniqueId();
        create(b, loc);
        bots.put(name.toLowerCase(), b);
        refreshNames();
        if (!silent && cfg().getBoolean("bots.join-leave-messages", true)) {
            Bukkit.broadcastMessage(Msg.c("&e" + name + " joined the game"));
        }
        save();
        return b;
    }

    public List<Bot> spawnRandom(Location base, int n, Player by) {
        List<Bot> out = new ArrayList<>();
        int max = cfg().getInt("bots.max-bots", 100);
        for (int i = 0; i < n && bots.size() < max; i++) {
            Location l = base.clone().add(rnd.nextInt(7) - 3, 0, rnd.nextInt(7) - 3);
            if (l.getBlock().getType().isSolid() || l.clone().add(0, 1, 0).getBlock().getType().isSolid()) l = base.clone();
            out.add(spawn(randomName(), l, by, false));
        }
        return out;
    }

    private void create(Bot b, Location loc) {
        NPC npc = registry.createNPC(EntityType.PLAYER, b.name);
        npc.setProtected(cfg().getBoolean("bots.invulnerable", false));
        npc.data().set("removefromtablist", !cfg().getBoolean("bots.show-in-tablist", true));
        npc.getNavigator().getDefaultParameters().range(60f);
        b.npc = npc;
        if (b.skinValue != null && !b.skinValue.isEmpty()) {
            try { npc.getOrAddTrait(SkinTrait.class).setSkinPersistent(b.name, b.skinSignature, b.skinValue); } catch (Throwable ignored) {}
        } else if (b.skin != null && !b.skin.isEmpty()) {
            try { npc.getOrAddTrait(SkinTrait.class).setSkinName(b.skin); } catch (Throwable ignored) {}
        }
        if (loc != null && loc.getWorld() != null) {
            if (!npc.spawn(loc)) plugin.getLogger().warning("Gagal spawn bot " + b.name);
        }
        gear(b);
    }

    public void respawn(Bot b) {
        if (b.npc == null) return;
        Location l = b.home != null ? b.home : (b.spawnLoc != null ? b.spawnLoc : b.lastLoc);
        if (l == null || l.getWorld() == null) return;
        b.npc.spawn(l);
        b.mineTarget = null;
        gear(b);
    }

    public void remove(Bot b, boolean silent) {
        bots.remove(b.name.toLowerCase());
        if (b.npc != null) {
            try { b.npc.destroy(); } catch (Throwable ignored) {}
        }
        refreshNames();
        if (!silent && cfg().getBoolean("bots.join-leave-messages", true)) {
            Bukkit.broadcastMessage(Msg.c("&e" + b.name + " left the game"));
        }
        save();
    }

    public void removeAll() {
        for (Bot b : new ArrayList<>(bots.values())) remove(b, false);
    }

    public void applyProtection() {
        boolean inv = cfg().getBoolean("bots.invulnerable", false);
        for (Bot b : bots.values()) if (b.npc != null) b.npc.setProtected(inv);
    }

    // ---------- commands for bots ----------
    public void setMode(Bot b, BotMode m, Player by) {
        b.mode = m;
        if (by != null) b.commander = by.getUniqueId();
        b.mineTarget = null;
        b.breakProgress = 0;
        b.nextAction = 0;
        if (b.isAlive()) b.npc.getNavigator().cancelNavigation();
        if (m == BotMode.FOLLOW && by != null) b.followTarget = by.getUniqueId();
        if (m == BotMode.GUARD && b.home == null) b.home = b.lastLoc != null ? b.lastLoc.clone() : null;
        gear(b);
        save();
    }

    public void setMine(Bot b, String preset, Player by) {
        Set<Material> set = MinePresets.resolve(preset);
        if (set == null) return;
        b.minePreset = preset.toLowerCase();
        b.mineCache = set;
        b.fallbackCache = null;
        b.skip.clear();
        setMode(b, BotMode.MINE, by);
    }

    public void setGuard(Bot b, Location home, int radius, Player by) {
        b.home = home.clone();
        b.radius = Math.max(2, Math.min(64, radius));
        setMode(b, BotMode.GUARD, by);
    }

    public void startBuild(Bot b, String type, Location origin, Player by) {
        b.buildType = type;
        b.buildOrigin = origin.getBlock().getLocation();
        b.queue = Structures.generate(type, b.buildOrigin, cfg());
        b.buildIndex = 0;
        setMode(b, BotMode.BUILD, by);
    }

    /** Ganti skin lewat URL gambar PNG (via MineSkin API, perlu API key di config: skin.mineskin-api-key). */
    public void setSkinUrl(Bot b, String url, java.util.function.Consumer<String> done) {
        final String key = cfg().getString("skin.mineskin-api-key", "").trim();
        if (key.isEmpty()) { done.accept("&cIsi dulu &fskin.mineskin-api-key&c di config.yml (gratis di account.mineskin.org)."); return; }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            String err = null, value = null, sig = null;
            try {
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("https://api.mineskin.org/v2/generate").openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(15000);
                c.setReadTimeout(60000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Authorization", "Bearer " + key);
                c.setRequestProperty("User-Agent", "FakePlayerPro/1.0");
                String body = "{\"url\":\"" + url.replace("\\", "").replace("\"", "") + "\",\"visibility\":\"unlisted\"}";
                c.getOutputStream().write(body.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                int code = c.getResponseCode();
                java.io.InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                StringBuilder sb = new StringBuilder();
                if (in != null) {
                    java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                }
                String resp = sb.toString();
                java.util.regex.Matcher mv = java.util.regex.Pattern.compile("\"value\"\\s*:\\s*\"([^\"]+)\"").matcher(resp);
                java.util.regex.Matcher ms = java.util.regex.Pattern.compile("\"signature\"\\s*:\\s*\"([^\"]+)\"").matcher(resp);
                if (code < 400 && mv.find() && ms.find()) { value = mv.group(1); sig = ms.group(1); }
                else err = "&cMineSkin gagal (HTTP " + code + "). Pastikan URL adalah gambar skin PNG 64x64 langsung & API key benar.";
            } catch (Throwable t) {
                err = "&cGagal menghubungi MineSkin: " + t.getMessage();
            }
            final String fv = value, fs = sig, fe = err;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (fe != null || !bots.containsValue(b)) { done.accept(fe != null ? fe : "&cBot sudah dihapus."); return; }
                b.skinValue = fv;
                b.skinSignature = fs;
                b.skin = "";
                if (b.npc != null) {
                    Location l = b.isAlive() ? b.player().getLocation() : null;
                    try { b.npc.getOrAddTrait(SkinTrait.class).setSkinPersistent(b.name, fs, fv); } catch (Throwable ignored) {}
                    if (l != null) { b.npc.despawn(); b.npc.spawn(l); gear(b); }
                }
                save();
                done.accept("&aSkin dari URL dipasang ke &f" + b.name + "&a.");
            });
        });
    }

    public void setSkin(Bot b, String skin) {
        b.skinValue = "";
        b.skinSignature = "";
        b.skin = skin;
        if (b.npc != null) {
            try { b.npc.getOrAddTrait(SkinTrait.class).setSkinName(skin); } catch (Throwable ignored) {}
        }
        save();
    }

    public void say(Bot b, String message) {
        String fmt = cfg().getString("chat.format", "<%name%> %message%");
        Bukkit.broadcastMessage(Msg.c(fmt.replace("%name%", b.name)).replace("%message%", message));
    }

    public void equipItem(Bot b, ItemStack item) {
        if (b.npc == null) return;
        b.npc.getOrAddTrait(Equipment.class).set(Equipment.EquipmentSlot.HAND, item == null ? new ItemStack(Material.AIR) : item.clone());
    }

    public void gear(Bot b) {
        if (b.npc == null) return;
        Equipment eq = b.npc.getOrAddTrait(Equipment.class);
        if (cfg().getBoolean("bots.random-armor", true)) {
            Random r = new Random(b.name.hashCode());
            String[] tiers = {"LEATHER", "CHAINMAIL", "IRON", "IRON", "DIAMOND"};
            String tier = tiers[r.nextInt(tiers.length)];
            if (r.nextInt(100) < 65) {
                setSlot(eq, Equipment.EquipmentSlot.HELMET, tier + "_HELMET");
                setSlot(eq, Equipment.EquipmentSlot.CHESTPLATE, tier + "_CHESTPLATE");
                if (r.nextBoolean()) setSlot(eq, Equipment.EquipmentSlot.LEGGINGS, tier + "_LEGGINGS");
                if (r.nextBoolean()) setSlot(eq, Equipment.EquipmentSlot.BOOTS, tier + "_BOOTS");
            }
        }
        String hand = null;
        switch (b.mode) {
            case MINE: hand = MinePresets.tool(b.minePreset); break;
            case GUARD: hand = "IRON_SWORD"; break;
            case BUILD: hand = cfg().getString("build.palette.wall", "STONE_BRICKS"); break;
            default: if (b.aggressive) hand = "IRON_SWORD";
        }
        setSlot(eq, Equipment.EquipmentSlot.HAND, hand);
    }

    private void setSlot(Equipment eq, Equipment.EquipmentSlot slot, String mat) {
        Material m = mat == null ? null : Material.matchMaterial(mat);
        eq.set(slot, new ItemStack(m == null ? Material.AIR : m));
    }

    // ---------- persistence ----------
    public void save() {
        if (!ready || !cfg().getBoolean("bots.persist", true)) return;
        YamlConfiguration y = new YamlConfiguration();
        for (Bot b : bots.values()) {
            ConfigurationSection s = y.createSection("bots." + b.name);
            s.set("mode", b.mode.name());
            s.set("aggressive", b.aggressive);
            s.set("chat", b.chat);
            s.set("skin", b.skin);
            s.set("skinValue", b.skinValue);
            s.set("skinSignature", b.skinSignature);
            s.set("loc", b.lastLoc);
            s.set("spawn", b.spawnLoc);
            s.set("home", b.home);
            s.set("radius", b.radius);
            s.set("minePreset", b.minePreset);
            s.set("follow", b.followTarget == null ? null : b.followTarget.toString());
            s.set("buildType", b.buildType);
            s.set("buildOrigin", b.buildOrigin);
            s.set("buildIndex", b.buildIndex);
            s.set("guardAfterBuild", b.guardAfterBuild);
            s.set("mined", b.mined);
            s.set("built", b.built);
            s.set("kills", b.kills);
            for (Map.Entry<Material, Integer> e : b.storage.entrySet()) s.set("storage." + e.getKey().name(), e.getValue());
        }
        try {
            y.save(new File(plugin.getDataFolder(), "bots.yml"));
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal menyimpan bots.yml: " + e.getMessage());
        }
    }

    private void load() {
        File f = new File(plugin.getDataFolder(), "bots.yml");
        if (!f.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection root = y.getConfigurationSection("bots");
        if (root == null) return;
        for (String name : root.getKeys(false)) {
            try {
                ConfigurationSection s = root.getConfigurationSection(name);
                if (s == null) continue;
                Bot b = new Bot(name);
                BotMode m = BotMode.parse(s.getString("mode"));
                b.mode = m == null ? BotMode.IDLE : m;
                b.aggressive = s.getBoolean("aggressive");
                b.chat = s.getBoolean("chat", true);
                b.skin = s.getString("skin", "");
                b.skinValue = s.getString("skinValue", "");
                b.skinSignature = s.getString("skinSignature", "");
                b.lastLoc = s.getLocation("loc");
                b.spawnLoc = s.getLocation("spawn");
                b.home = s.getLocation("home");
                b.radius = s.getInt("radius", 10);
                b.minePreset = s.getString("minePreset", "ores");
                String fo = s.getString("follow");
                if (fo != null) { try { b.followTarget = UUID.fromString(fo); } catch (Exception ignored) {} }
                b.buildType = s.getString("buildType", "house");
                b.buildOrigin = s.getLocation("buildOrigin");
                b.buildIndex = s.getInt("buildIndex");
                b.guardAfterBuild = s.getBoolean("guardAfterBuild", true);
                b.mined = s.getInt("mined");
                b.built = s.getInt("built");
                b.kills = s.getInt("kills");
                ConfigurationSection st = s.getConfigurationSection("storage");
                if (st != null) for (String k : st.getKeys(false)) {
                    Material mat = Material.matchMaterial(k);
                    if (mat != null) b.storage.put(mat, st.getInt(k));
                }
                Location at = b.lastLoc != null ? b.lastLoc : b.spawnLoc;
                if (at == null || at.getWorld() == null) {
                    plugin.getLogger().warning("Bot " + name + " dilewati (world tidak ditemukan).");
                    continue;
                }
                if (b.spawnLoc == null) b.spawnLoc = at.clone();
                if (b.lastLoc == null) b.lastLoc = at.clone();
                create(b, at);
                bots.put(name.toLowerCase(), b);
            } catch (Throwable t) {
                plugin.getLogger().warning("Gagal memuat bot " + name + ": " + t);
            }
        }
        refreshNames();
    }
}
