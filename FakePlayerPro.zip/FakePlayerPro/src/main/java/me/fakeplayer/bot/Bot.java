package me.fakeplayer.bot;

import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.*;

public class Bot {
    public static class Step {
        public final int x, y, z;
        public final Material mat;
        public final boolean force;

        public Step(int x, int y, int z, Material mat, boolean force) {
            this.x = x; this.y = y; this.z = z; this.mat = mat; this.force = force;
        }
    }

    public final String name;
    public NPC npc;
    public BotMode mode = BotMode.IDLE;
    public boolean aggressive;
    public boolean chat = true;
    public String skin = "";
    public String skinValue = "", skinSignature = "";
    public UUID followTarget, commander, revenge, combatTarget;
    public long revengeUntil;
    public Location spawnLoc, lastLoc, home;
    public int radius = 10;

    // mining
    public String minePreset = "ores";
    public Set<Material> mineCache, fallbackCache;
    public Block mineTarget;
    public int breakProgress;
    public long targetSince;
    public final Set<String> skip = new HashSet<>();

    // building
    public String buildType = "house";
    public Location buildOrigin;
    public List<Step> queue = new ArrayList<>();
    public int buildIndex;
    public boolean guardAfterBuild = true;

    public final Map<Material, Integer> storage = new LinkedHashMap<>();
    public long nextAction, nextAmbient, nextChat, lastHit, respawnAt, lastHeal, lastNotify;
    public int mined, built, kills, deaths;

    public Bot(String name) {
        this.name = name;
    }

    public boolean isAlive() {
        return npc != null && npc.isSpawned() && npc.getEntity() instanceof Player && !npc.getEntity().isDead();
    }

    public Player player() {
        return isAlive() ? (Player) npc.getEntity() : null;
    }

    public void store(Material m, int n) {
        storage.merge(m, n, Integer::sum);
    }

    public int storedTotal() {
        int t = 0;
        for (int v : storage.values()) t += v;
        return t;
    }
}
