package me.fakeplayer.bot;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.util.Msg;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

import java.util.*;

/** /tp, /tpa, /tpahere, /tphere dan terima/tolak (otomatis / manual) untuk bot. */
public class Teleports {
    private final FakePlayerPlugin plugin;
    private final Random rnd = new Random();
    private final Map<UUID, String> outgoing = new HashMap<>();   // pemain -> nama bot tujuan request

    public Teleports(FakePlayerPlugin plugin) { this.plugin = plugin; }

    private BotManager m() { return plugin.bots(); }

    private long expireMs() { return plugin.getConfig().getInt("tpa.expire-seconds", 60) * 1000L; }

    // ---------- teleport langsung ----------
    public void tp(Player p, Bot b) {
        if (!b.isAlive()) { Msg.send(p, "&c" + b.name + " sedang mati / belum muncul."); return; }
        p.teleport(b.player().getLocation());
        Msg.send(p, "&7Teleport ke &f" + b.name + "&7.");
    }

    public void tphere(Player p, Bot b) {
        if (!b.isAlive()) { Msg.send(p, "&c" + b.name + " sedang mati / belum muncul."); return; }
        m().teleportBot(b, p.getLocation());
        Msg.send(p, "&7Teleport &f" + b.name + "&7 ke posisimu.");
    }

    // ---------- request ----------
    public void request(Player p, Bot b, boolean here) {
        if (!b.isAlive()) { Msg.send(p, "&c" + b.name + " sedang mati / belum muncul."); return; }
        purge(b);
        for (Iterator<Bot.TpRequest> it = b.requests.iterator(); it.hasNext(); ) {
            if (it.next().from.equals(p.getUniqueId())) it.remove();
        }
        Bot.TpRequest r = new Bot.TpRequest(p.getUniqueId(), p.getName(), here, System.currentTimeMillis());
        b.requests.add(r);
        outgoing.put(p.getUniqueId(), b.name);
        Msg.send(p, "&6Permintaan teleport dikirim ke &c" + b.name + "&6. Berlaku " + (expireMs() / 1000) + " detik. Batal: &f/tpcancel");

        String mode = b.tpaMode == null ? "auto" : b.tpaMode;
        if (mode.equals("manual")) {
            notifyManagers(b, r);
            return;
        }
        int min = plugin.getConfig().getInt("tpa.auto-delay-min-seconds", 1);
        int max = Math.max(min, plugin.getConfig().getInt("tpa.auto-delay-max-seconds", 5));
        long delay = (min + rnd.nextInt(max - min + 1)) * 20L + rnd.nextInt(20);
        final boolean deny = mode.equals("off") || rnd.nextInt(100) < plugin.getConfig().getInt("tpa.auto-decline-chance", 0);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!b.requests.contains(r)) return;
            if (deny) deny(b, r, null); else doAccept(b, r);
        }, delay);
    }

    private void purge(Bot b) {
        long now = System.currentTimeMillis();
        b.requests.removeIf(r -> now - r.time > expireMs());
    }

    private void notifyManagers(Bot b, Bot.TpRequest r) {
        Set<Player> targets = new LinkedHashSet<>();
        for (Player o : Bukkit.getOnlinePlayers()) if (o.hasPermission("fakeplayer.tpa.manage")) targets.add(o);
        if (b.possessedBy != null) {
            Player poss = Bukkit.getPlayer(b.possessedBy);
            if (poss != null) targets.add(poss);
        }
        String what = r.here ? " meminta " + b.name + " teleport ke dia" : " ingin teleport ke " + b.name;
        for (Player o : targets) {
            TextComponent base = new TextComponent(Msg.c("&8[&bBot&8] &e" + r.fromName + "&7" + what + " "));
            TextComponent ok = new TextComponent(Msg.c("&a[Terima]"));
            ok.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/bot tpaccept " + b.name + " " + r.fromName));
            TextComponent no = new TextComponent(Msg.c("&c[Tolak]"));
            no.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/bot tpdeny " + b.name + " " + r.fromName));
            base.addExtra(ok);
            base.addExtra(new TextComponent(" "));
            base.addExtra(no);
            o.spigot().sendMessage(base);
        }
    }

    private Bot.TpRequest find(Bot b, String fromName) {
        purge(b);
        Bot.TpRequest found = null;
        for (Bot.TpRequest r : b.requests) {
            if (fromName == null || r.fromName.equalsIgnoreCase(fromName)) found = r;   // ambil yang terbaru
        }
        return found;
    }

    // ---------- terima / tolak ----------
    public void accept(Bot b, String fromName, CommandSender by) {
        Bot.TpRequest r = find(b, fromName);
        if (r == null) { Msg.send(by, "&cTidak ada permintaan teleport untuk &f" + b.name + "&c."); return; }
        doAccept(b, r);
        Msg.send(by, "&a" + b.name + " menerima permintaan dari &f" + r.fromName + "&a.");
    }

    public void deny(Bot b, String fromName, CommandSender by) {
        Bot.TpRequest r = find(b, fromName);
        if (r == null) { Msg.send(by, "&cTidak ada permintaan teleport untuk &f" + b.name + "&c."); return; }
        deny(b, r, by);
    }

    private void deny(Bot b, Bot.TpRequest r, CommandSender by) {
        b.requests.remove(r);
        outgoing.remove(r.from);
        Player req = Bukkit.getPlayer(r.from);
        if (req != null) Msg.send(req, "&c" + b.name + " menolak permintaan teleportmu.");
        if (by != null) Msg.send(by, "&7Permintaan dari &f" + r.fromName + "&7 ditolak.");
    }

    private void doAccept(Bot b, Bot.TpRequest r) {
        b.requests.remove(r);
        outgoing.remove(r.from);
        Player req = Bukkit.getPlayer(r.from);
        if (req == null || !req.isOnline()) return;
        if (!b.isAlive()) { Msg.send(req, "&c" + b.name + " sedang tidak bisa menerima teleport."); return; }
        if (r.here) m().teleportBot(b, req.getLocation());
        else req.teleport(b.player().getLocation());
        Msg.send(req, "&a" + b.name + " menerima permintaan teleportmu.");
        List<String> chat = plugin.getConfig().getStringList("tpa.accept-chat");
        if (!chat.isEmpty() && b.chat && rnd.nextInt(100) < plugin.getConfig().getInt("tpa.accept-chat-chance", 30) && m().tryAutoChat(b)) {
            final String text = chat.get(rnd.nextInt(chat.size()));
            Bukkit.getScheduler().runTaskLater(plugin, () -> { if (b.isAlive()) m().say(b, text); }, 30L + rnd.nextInt(40));
        }
    }

    // ---------- /tpcancel ----------
    public boolean cancel(Player p) {
        String bn = outgoing.remove(p.getUniqueId());
        if (bn == null) return false;
        Bot b = m().get(bn);
        if (b != null) b.requests.removeIf(r -> r.from.equals(p.getUniqueId()));
        Msg.send(p, "&7Permintaan teleport dibatalkan.");
        return true;
    }

    public boolean hasOutgoing(Player p) { return outgoing.containsKey(p.getUniqueId()); }

    public List<Bot.TpRequest> pending(Bot b) {
        purge(b);
        return b.requests;
    }
}
