package me.fakeplayer.bot;

import me.fakeplayer.FakePlayerPlugin;
import net.citizensnpcs.api.ai.Navigator;
import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

/** Mesin PvP (tick tiap 2 tick): sword/axe crit + strafe, crystal, mace smash, makan gapple. */
public class Pvp {
    private final FakePlayerPlugin plugin;
    private final Random rnd = new Random();

    public Pvp(FakePlayerPlugin plugin) { this.plugin = plugin; }

    private FileConfiguration cfg() { return plugin.getConfig(); }

    public void tickAll(Collection<Bot> all) {
        long now = System.currentTimeMillis();
        for (Bot b : new ArrayList<>(all)) {
            if (!b.online || !b.inFight || b.pvpTarget == null || b.possessedBy != null || !b.isAlive()) continue;
            try {
                tick(b, now);
            } catch (Throwable t) {
                plugin.getLogger().warning("Error PvP " + b.name + ": " + t);
            }
        }
    }

    // ---------- util ----------
    private ItemStack held(Bot b) {
        return b.inv == null ? null : b.inv[Math.max(0, Math.min(8, b.heldSlot))];
    }

    /** Ganti slot hotbar yang dipegang (tanpa menyimpan ke disk). */
    private void setHeld(Bot b, int slot) {
        b.heldSlot = Math.max(0, Math.min(8, slot));
        if (b.isAlive()) b.player().getInventory().setHeldItemSlot(b.heldSlot);
    }

    private int findSlot(Bot b, String name) {
        if (b.inv == null) return -1;
        for (int i = 0; i < 9; i++) {
            ItemStack it = b.inv[i];
            if (it == null) continue;
            String n = it.getType().name();
            if (name.startsWith("_") ? n.endsWith(name) : n.equals(name)) return i;
        }
        return -1;
    }

    private boolean grounded(Player p) {
        return p.getLocation().subtract(0, 0.1, 0).getBlock().getType().isSolid();
    }

    private String style(Bot b) {
        if (!"auto".equals(b.pvpStyle)) return b.pvpStyle;
        if (findSlot(b, "MACE") >= 0) return "mace";
        if (findSlot(b, "END_CRYSTAL") >= 0) return "crystal";
        return "sword";
    }

    private void hold(Bot b, String name) {
        int s = findSlot(b, name);
        if (s >= 0 && b.heldSlot != s) setHeld(b, s);
    }

    private double tier(String n, double wood, double stone, double iron, double diamond, double neth) {
        if (n.startsWith("NETHERITE")) return neth;
        if (n.startsWith("DIAMOND")) return diamond;
        if (n.startsWith("IRON")) return iron;
        if (n.startsWith("STONE")) return stone;
        return wood;
    }

    private double weaponDamage(ItemStack it) {
        if (it == null || it.getType() == Material.AIR) return cfg().getDouble("combat.damage", 3.0);
        String n = it.getType().name();
        double d;
        if (n.equals("MACE")) d = 6;
        else if (n.endsWith("_SWORD")) d = tier(n, 4, 5, 6, 7, 8);
        else if (n.endsWith("_AXE")) d = tier(n, 7, 9, 9, 9, 10);
        else d = 2;
        Enchantment sh = Enchantment.getByKey(NamespacedKey.minecraft("sharpness"));
        if (sh != null) {
            int lv = it.getEnchantmentLevel(sh);
            if (lv > 0) d += 0.5 * lv + 0.5;
        }
        return d;
    }

    private long cooldownMs(ItemStack it) {
        if (it == null) return 500;
        String n = it.getType().name();
        if (n.equals("MACE")) return 1700;
        if (n.endsWith("_AXE")) return 1000;
        if (n.endsWith("_SWORD")) return 625;
        return 500;
    }

    private boolean consume(Bot b, String name) {
        if (b.inv == null) return false;
        for (int i = 0; i < 36; i++) {
            ItemStack it = b.inv[i];
            if (it != null && it.getType().name().equals(name)) {
                if (it.getAmount() <= 1) b.inv[i] = null; else it.setAmount(it.getAmount() - 1);
                plugin.bots().applyInv(b);
                return true;
            }
        }
        return false;
    }

    // ---------- main ----------
    private void tick(Bot b, long now) {
        Player p = b.player();
        Entity te = Bukkit.getEntity(b.pvpTarget);
        if (!(te instanceof LivingEntity) || te.isDead() || te.getWorld() != p.getWorld()) { b.inFight = false; return; }
        LivingEntity t = (LivingEntity) te;
        double d = p.getLocation().distance(t.getLocation());
        if (d > 32) { b.inFight = false; return; }
        b.npc.faceLocation(t.getEyeLocation());
        p.setSprinting(true);
        eat(b, p, now);
        switch (style(b)) {
            case "mace": mace(b, p, t, d, now); break;
            case "crystal": crystal(b, p, t, d, now); break;
            default: melee(b, p, t, d, now);
        }
    }

    private void eat(Bot b, Player p, long now) {
        if (p.getHealth() >= 9 || now - b.lastEat < 4000) return;
        String g = findSlot(b, "ENCHANTED_GOLDEN_APPLE") >= 0 ? "ENCHANTED_GOLDEN_APPLE" : (findSlot(b, "GOLDEN_APPLE") >= 0 ? "GOLDEN_APPLE" : null);
        if (g == null) return;
        b.lastEat = now;
        PotionEffectType ab = PotionEffectType.getByName("ABSORPTION");
        PotionEffectType rg = PotionEffectType.getByName("REGENERATION");
        if (ab != null) p.addPotionEffect(new PotionEffect(ab, 2400, g.startsWith("ENCH") ? 3 : 0));
        if (rg != null) p.addPotionEffect(new PotionEffect(rg, 400, 1));
        p.getWorld().playSound(p.getLocation(), "entity.generic.eat", 1f, 1f);
        if (cfg().getBoolean("pvp.consume-items", false)) consume(b, g);
    }

    /** true jika sudah di jarak tempur. */
    private boolean position(Bot b, Player p, LivingEntity t, double d, double keep, long now) {
        Navigator nav = b.npc.getNavigator();
        if (d > keep + 1.0) {
            if (!nav.isNavigating() || !t.getUniqueId().equals(b.combatTarget)) {
                nav.setTarget(t, false);
                b.combatTarget = t.getUniqueId();
            }
            return false;
        }
        nav.cancelNavigation();
        Vector dir = t.getLocation().toVector().subtract(p.getLocation().toVector());
        dir.setY(0);
        if (dir.lengthSquared() < 0.01) return true;
        dir.normalize();
        Vector v = p.getVelocity();
        if (d < keep - 1.2) {
            p.setVelocity(new Vector(-dir.getX() * 0.15, v.getY(), -dir.getZ() * 0.15));
        } else {
            if (now > b.strafeUntil) { b.strafeDir = -b.strafeDir; b.strafeUntil = now + 500 + rnd.nextInt(1200); }
            Vector perp = new Vector(-dir.getZ(), 0, dir.getX()).multiply(0.16 * b.strafeDir);
            p.setVelocity(new Vector(perp.getX() + dir.getX() * 0.03, v.getY(), perp.getZ() + dir.getZ() * 0.03));
        }
        return true;
    }

    private void jump(Player p) {
        if (grounded(p)) {
            Vector v = p.getVelocity();
            v.setY(0.42);
            p.setVelocity(v);
        }
    }

    private void hit(Bot b, Player p, LivingEntity t, double dmg, long cd, long now) {
        p.swingMainHand();
        t.damage(dmg, p);
        b.nextAttack = now + cd + rnd.nextInt(80);
        b.critWait = 0;
        if (t.isDead()) b.kills++;
    }

    // ---------- sword / axe ----------
    private void melee(Bot b, Player p, LivingEntity t, double d, long now) {
        if (b.customInv) {
            hold(b, "_SWORD");
            if (held(b) == null || !held(b).getType().name().endsWith("_SWORD")) hold(b, "_AXE");
        }
        if (!position(b, p, t, d, 2.6, now)) return;
        if (d > 3.1 || now < b.nextAttack) return;
        ItemStack h = held(b);
        double dmg = weaponDamage(h);
        long cd = cooldownMs(h);
        boolean ground = grounded(p);
        boolean critJump = cfg().getBoolean("pvp.crit-jump", true);
        if (critJump && ground) {
            if (b.critWait == 0) { b.critWait = now + 450; jump(p); return; }
            if (now < b.critWait) return;
            hit(b, p, t, dmg, cd, now);
        } else if (!ground && p.getVelocity().getY() < 0) {
            hit(b, p, t, dmg * 1.5, cd, now);
        } else if (!critJump) {
            hit(b, p, t, dmg, cd, now);
        }
    }

    // ---------- mace ----------
    private double smashBonus(double fall) {
        if (fall <= 3) return 4 * fall;
        if (fall <= 8) return 12 + 2 * (fall - 3);
        return 22 + (fall - 8);
    }

    private void mace(Bot b, Player p, LivingEntity t, double d, long now) {
        int ms = findSlot(b, "MACE");
        if (ms < 0) { melee(b, p, t, d, now); return; }
        if (b.heldSlot != ms) setHeld(b, ms);
        Navigator nav = b.npc.getNavigator();
        Location pl = p.getLocation(), tl = t.getLocation();
        if (grounded(p) && p.getVelocity().getY() <= 0.05) {
            b.airborne = false;
            if (d > 8) { position(b, p, t, d, 7, now); return; }
            if (now >= b.maceReady) {
                nav.cancelNavigation();
                Vector dir = tl.toVector().subtract(pl.toVector());
                dir.setY(0);
                if (dir.lengthSquared() > 0.01) dir.normalize().multiply(0.35); else dir = new Vector();
                p.setVelocity(new Vector(dir.getX(), 1.45, dir.getZ()));
                b.airborne = true;
                b.peakY = pl.getY();
                b.maceReady = now + 3500;
                p.getWorld().playSound(pl, "entity.wind_charge.wind_burst", 1f, 1f);
            } else {
                position(b, p, t, d, 3.5, now);
            }
            return;
        }
        if (!b.airborne) return;
        b.peakY = Math.max(b.peakY, pl.getY());
        p.setFallDistance(0);
        Vector dir = tl.toVector().subtract(pl.toVector());
        dir.setY(0);
        if (dir.lengthSquared() > 0.25) {
            dir.normalize().multiply(0.28);
            Vector v = p.getVelocity();
            p.setVelocity(new Vector(dir.getX(), v.getY(), dir.getZ()));
        }
        if (p.getVelocity().getY() < -0.2 && d <= 3.6) {
            double fall = Math.max(0, b.peakY - pl.getY());
            p.swingMainHand();
            t.damage(6 + smashBonus(fall), p);
            p.getWorld().playSound(tl, "item.mace.smash_ground", 1f, 1f);
            p.setFallDistance(0);
            b.airborne = false;
            b.peakY = 0;
            if (t.isDead()) b.kills++;
        }
    }

    // ---------- crystal ----------
    private EntityType crystalType() {
        for (EntityType e : EntityType.values()) {
            if (e.name().equals("END_CRYSTAL") || e.name().equals("ENDER_CRYSTAL")) return e;
        }
        return null;
    }

    private void crystal(Bot b, Player p, LivingEntity t, double d, long now) {
        int cs = findSlot(b, "END_CRYSTAL");
        if (cs < 0) { melee(b, p, t, d, now); return; }
        if (d <= 3.1) { melee(b, p, t, d, now); return; }
        if (!position(b, p, t, d, 5.0, now)) return;
        if (now - b.lastCrystal < 650) return;
        if (cfg().getBoolean("pvp.consume-items", false) && !consume(b, "END_CRYSTAL")) return;
        EntityType ct = crystalType();
        if (ct == null) return;
        b.lastCrystal = now;
        final int prev = b.heldSlot;
        setHeld(b, cs);
        final World w = t.getWorld();
        Location cl = t.getLocation().getBlock().getLocation().add(0.5, 0, 0.5);
        final Entity c = w.spawnEntity(cl, ct);
        c.setMetadata("fp_crystal", new FixedMetadataValue(plugin, true));
        p.swingMainHand();
        final boolean grief = cfg().getBoolean("pvp.crystal-break-blocks", false);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!c.isDead()) {
                Location l = c.getLocation();
                c.remove();
                if (p.isOnline() && !p.isDead() && p.getWorld() == l.getWorld() && p.getLocation().distance(l) >= 2.5) {
                    w.createExplosion(l, 6f, false, grief, p);
                }
            }
            if (b.isAlive()) setHeld(b, prev);
        }, 4L);
    }
}
