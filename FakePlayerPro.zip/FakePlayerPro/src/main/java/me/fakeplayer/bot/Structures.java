package me.fakeplayer.bot;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.*;

public final class Structures {
    private Structures() {}

    public static final List<String> TYPES = Arrays.asList("house", "tower", "wall", "fort", "portal");

    private static Material mat(FileConfiguration cfg, String key, String def) {
        Material m = Material.matchMaterial(cfg.getString("build.palette." + key, def));
        if (m == null) m = Material.matchMaterial(def);
        return m == null ? Material.STONE : m;
    }

    private static class Out {
        final Map<String, Bot.Step> map = new LinkedHashMap<>();
        final int ox, oy, oz;

        Out(Location o) { ox = o.getBlockX(); oy = o.getBlockY(); oz = o.getBlockZ(); }

        void add(int x, int y, int z, Material m, boolean force) {
            int ax = ox + x, ay = oy + y, az = oz + z;
            String k = ax + "," + ay + "," + az;
            if (!map.containsKey(k)) map.put(k, new Bot.Step(ax, ay, az, m, force));
        }
    }

    public static List<Bot.Step> generate(String type, Location origin, FileConfiguration cfg) {
        Material floor = mat(cfg, "floor", "OAK_PLANKS");
        Material wall = mat(cfg, "wall", "STONE_BRICKS");
        Material roof = mat(cfg, "roof", "SPRUCE_PLANKS");
        Material window = mat(cfg, "window", "GLASS_PANE");
        Material light = mat(cfg, "light", "TORCH");
        Out o = new Out(origin);
        switch (type == null ? "house" : type) {
            case "tower": tower(o, floor, wall, window, light); break;
            case "wall": wallLine(o, wall); break;
            case "fort": fort(o, floor, wall, light); break;
            case "portal": portal(o); break;
            default: house(o, floor, wall, roof, window, light);
        }
        return new ArrayList<>(o.map.values());
    }

    private static void house(Out o, Material floor, Material wall, Material roof, Material window, Material light) {
        for (int x = -3; x <= 3; x++) for (int z = -3; z <= 3; z++) o.add(x, -1, z, floor, true);
        for (int y = 0; y <= 3; y++) {
            for (int x = -3; x <= 3; x++) {
                for (int z = -3; z <= 3; z++) {
                    if (Math.abs(x) != 3 && Math.abs(z) != 3) continue;
                    if (z == 3 && x == 0 && y <= 1) continue; // pintu
                    boolean win = y == 1 && ((Math.abs(x) == 3 && z == 0) || (z == -3 && x == 0));
                    o.add(x, y, z, win ? window : wall, false);
                }
            }
        }
        for (int x = -3; x <= 3; x++) for (int z = -3; z <= 3; z++) o.add(x, 4, z, roof, false);
        o.add(-2, 0, -2, light, false); o.add(2, 0, -2, light, false);
        o.add(-2, 0, 2, light, false); o.add(2, 0, 2, light, false);
    }

    private static void tower(Out o, Material floor, Material wall, Material window, Material light) {
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) o.add(x, -1, z, floor, true);
        for (int y = 0; y <= 9; y++) {
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    if (Math.abs(x) != 2 && Math.abs(z) != 2) continue;
                    if (z == 2 && x == 0 && y <= 1) continue;
                    boolean slit = y == 5 && ((x == 0 && Math.abs(z) == 2) || (z == 0 && Math.abs(x) == 2));
                    o.add(x, y, z, slit ? window : wall, false);
                }
            }
        }
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) {
            if ((Math.abs(x) == 2 || Math.abs(z) == 2) && ((Math.abs(x) + Math.abs(z)) % 2 == 0)) o.add(x, 10, z, wall, false);
        }
        o.add(-1, 0, -1, light, false); o.add(1, 0, -1, light, false);
    }

    /** Portal Nether 4x5 (bingkai obsidian + blok portal), berdiri 3 blok di depan titik asal. */
    private static void portal(Out o) {
        Material ob = Material.OBSIDIAN;
        Material port = Material.matchMaterial("NETHER_PORTAL");
        for (int x = -1; x <= 0; x++) { o.add(x, -1, 3, ob, true); o.add(x, 3, 3, ob, true); }
        for (int y = 0; y <= 2; y++) { o.add(-2, y, 3, ob, true); o.add(1, y, 3, ob, true); }
        if (port != null) for (int x = -1; x <= 0; x++) for (int y = 0; y <= 2; y++) o.add(x, y, 3, port, true);
    }

    private static void wallLine(Out o, Material wall) {
        for (int y = 0; y <= 2; y++) for (int x = -7; x <= 7; x++) o.add(x, y, 3, wall, false);
        for (int x = -7; x <= 7; x += 2) o.add(x, 3, 3, wall, false);
    }

    private static void fort(Out o, Material floor, Material wall, Material light) {
        for (int x = -7; x <= 7; x++) for (int z = -7; z <= 7; z++) o.add(x, -1, z, floor, true);
        for (int y = 0; y <= 4; y++) {
            for (int x = -7; x <= 7; x++) {
                for (int z = -7; z <= 7; z++) {
                    if (Math.abs(x) != 7 && Math.abs(z) != 7) continue;
                    if (z == 7 && Math.abs(x) <= 1 && y <= 2) continue; // gerbang
                    o.add(x, y, z, wall, false);
                }
            }
        }
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                int cx = sx * 6, cz = sz * 6;
                for (int y = 0; y <= 7; y++) {
                    for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dz == 0) continue;
                        o.add(cx + dx, y, cz + dz, wall, false);
                    }
                }
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                    if ((Math.abs(dx) + Math.abs(dz)) % 2 == 0) o.add(cx + dx, 8, cz + dz, wall, false);
                }
            }
        }
        int[][] torches = {{-5, -5}, {5, -5}, {-5, 5}, {5, 5}, {0, -5}, {-5, 0}, {5, 0}, {0, 0}};
        for (int[] t : torches) o.add(t[0], 0, t[1], light, false);
    }
}
