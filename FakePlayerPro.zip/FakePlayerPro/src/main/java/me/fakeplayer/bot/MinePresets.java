package me.fakeplayer.bot;

import org.bukkit.Material;

import java.util.*;

public final class MinePresets {
    private MinePresets() {}

    public static final List<String> KEYS = Arrays.asList("ores", "wood", "stone", "dirt", "all");
    public static final List<String> ORE_NAMES = Arrays.asList("coal", "iron", "copper", "gold", "redstone", "lapis", "diamond", "emerald", "quartz");

    private static boolean legacy(Material m) { return m.name().startsWith("LEGACY_"); }
    private static boolean ore(Material m) { return !legacy(m) && m.isBlock() && m.name().endsWith("_ORE"); }
    private static boolean log(Material m) { return !legacy(m) && m.isBlock() && m.name().endsWith("_LOG"); }

    private static void names(Set<Material> set, String... names) {
        for (String n : names) {
            Material m = Material.matchMaterial(n);
            if (m != null) set.add(m);
        }
    }

    public static Set<Material> resolve(String key) {
        if (key == null) return null;
        String k = key.toLowerCase(Locale.ROOT);
        Set<Material> set = new LinkedHashSet<>();
        switch (k) {
            case "ores":
                for (Material m : Material.values()) if (ore(m)) set.add(m);
                break;
            case "wood":
                for (Material m : Material.values()) if (log(m)) set.add(m);
                break;
            case "stone":
                names(set, "STONE", "COBBLESTONE", "ANDESITE", "DIORITE", "GRANITE", "DEEPSLATE", "COBBLED_DEEPSLATE", "TUFF", "SANDSTONE");
                break;
            case "dirt":
                names(set, "DIRT", "GRASS_BLOCK", "COARSE_DIRT", "SAND", "RED_SAND", "GRAVEL", "CLAY");
                break;
            case "all":
                for (Material m : Material.values()) if (ore(m)) set.add(m);
                names(set, "STONE", "COBBLESTONE", "ANDESITE", "DIORITE", "GRANITE", "DEEPSLATE", "COBBLED_DEEPSLATE", "TUFF", "SANDSTONE",
                        "DIRT", "GRASS_BLOCK", "COARSE_DIRT", "SAND", "RED_SAND", "GRAVEL", "CLAY");
                break;
            default:
                if (k.startsWith("ore:")) {
                    String n = k.substring(4).toUpperCase(Locale.ROOT) + "_ORE";
                    for (Material m : Material.values()) if (ore(m) && m.name().endsWith(n)) set.add(m);
                } else {
                    Material m = Material.matchMaterial(key);
                    if (m != null && m.isBlock() && !legacy(m)) set.add(m);
                }
        }
        return set.isEmpty() ? null : set;
    }

    public static boolean usesFallback(String key) {
        return key != null && key.toLowerCase(Locale.ROOT).startsWith("ore");
    }

    public static String tool(String key) {
        String k = key == null ? "" : key.toLowerCase(Locale.ROOT);
        if (k.equals("wood")) return "IRON_AXE";
        if (k.equals("dirt")) return "IRON_SHOVEL";
        return "IRON_PICKAXE";
    }
}
