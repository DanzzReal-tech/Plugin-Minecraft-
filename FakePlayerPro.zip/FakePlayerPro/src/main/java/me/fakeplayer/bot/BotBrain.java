package me.fakeplayer.bot;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.util.Msg;
import net.citizensnpcs.api.ai.Navigator;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.*;

/** Semua perilaku AI bot: idle, jalan, ikut, mining, bangun, jaga, serang, chat. */
public class BotBrain {
    private final FakePlayerPlugin plugin;
    private final Random rnd = new Random();

    public BotBrain(FakePlayerPlugin plugin) { this.plugin = plugin; }

    private FileConfiguration cfg() { return plugin.getConfig(); }

    public void tick(Bot b) {
        long now = System.currentTimeMillis();
        if (!b.isAlive()) { dead(b, now); return; }
        Player p = b.player();
        b.lastLoc = p.getLocation().clone();
        heal(b, p, now);
        chatTick(b, now);
        if (combat(b, p, now)) return;
        switch (b.mode) {
            case WANDER: wander(b, p, now, base(b), cfg().getInt("behavior.wander-radius", 12)); break;
            case FOLLOW: follow(b, p, now); break;
            case COLLECT: collect(b, p, now); break;
            case MINE: mine(b, p, now); break;
            case BUILD: build(b, p, now); break;
            case GUARD: guard(b, p, now); break;
            default: ambient(b, p, now);
        }
    }

    private Location base(Bot b) {
        return b.home != null ? b.home : (b.spawnLoc != null ? b.spawnLoc : b.lastLoc);
    }

    // ---------------- hidup / mati ----------------
    private void dead(Bot b, long now) {
        if (b.respawnAt == 0) {
            b.respawnAt = now + cfg().getInt("bots.respawn-delay-seconds", 5) * 1000L;
            b.deaths++;
            b.mineTarget = null;
            return;
        }
        if (!cfg().getBoolean("bots.respawn", true)) return;
        if (now >= b.respawnAt) {
            b.respawnAt = 0;
            plugin.bots().respawn(b);
        }
    }

    @SuppressWarnings("deprecation")
    private void heal(Bot b, Player p, long now) {
        if (!cfg().getBoolean("bots.auto-heal", true) || now - b.lastHeal < 2000) return;
        b.lastHeal = now;
        double max = p.getMaxHealth();
        if (p.getHealth() < max) p.setHealth(Math.min(max, p.getHealth() + 1));
        p.setFoodLevel(20);
    }

    // ---------------- chat ----------------
    private void chatTick(Bot b, long now) {
        if (!b.chat || !cfg().getBoolean("chat.enabled", true)) return;
        if (b.nextChat == 0) { b.nextChat = now + chatInterval(); return; }
        if (now < b.nextChat) return;
        b.nextChat = now + chatInterval();
        if (Bukkit.getOnlinePlayers().isEmpty()) return;
        List<String> msgs = cfg().getStringList("chat.messages");
        if (msgs.isEmpty()) return;
        plugin.bots().say(b, msgs.get(rnd.nextInt(msgs.size())));
    }

    private long chatInterval() {
        int min = cfg().getInt("chat.interval-min-seconds", 90);
        int max = cfg().getInt("chat.interval-max-seconds", 400);
        return (min + rnd.nextInt(Math.max(1, max - min))) * 1000L;
    }

    // ---------------- tindakan natural ----------------
    private Player nearestPlayer(Player p, double r) {
        Player best = null;
        double bd = r * r;
        for (Player o : p.getWorld().getPlayers()) {
            if (o == p || o.hasMetadata("NPC")) continue;
            double d = o.getLocation().distanceSquared(p.getLocation());
            if (d < bd) { bd = d; best = o; }
        }
        return best;
    }

    private void ambient(Bot b, Player p, long now) {
        if (now < b.nextAmbient) return;
        b.nextAmbient = now + 1500 + rnd.nextInt(4000);
        if (p.isSneaking() && rnd.nextInt(100) < 55) p.setSneaking(false);
        Navigator nav = b.npc.getNavigator();
        if (nav.isNavigating()) return;
        if (cfg().getBoolean("behavior.look-at-players", true)) {
            Player n = nearestPlayer(p, cfg().getDouble("behavior.look-range", 8));
            if (n != null && rnd.nextInt(100) < 70) {
                b.npc.faceLocation(n.getEyeLocation());
                return;
            }
        }
        int r = rnd.nextInt(100);
        if (r < 25) {
            b.npc.faceLocation(p.getLocation().add(rnd.nextInt(11) - 5, rnd.nextInt(3), rnd.nextInt(11) - 5));
        } else if (r < 37 && cfg().getBoolean("behavior.random-jump", true)) {
            jump(p);
        } else if (r < 47 && cfg().getBoolean("behavior.random-sneak", true)) {
            p.setSneaking(!p.isSneaking());
        } else if (r < 57 && cfg().getBoolean("behavior.random-swing", true)) {
            p.swingMainHand();
        }
    }

    private void jump(Player p) {
        if (p.getLocation().subtract(0, 0.2, 0).getBlock().getType().isSolid()) {
            Vector v = p.getVelocity();
            v.setY(0.42);
            p.setVelocity(v);
        }
    }

    private Location randomNear(Location c, int r, double refY) {
        if (c == null || c.getWorld() == null) return null;
        World w = c.getWorld();
        int x = c.getBlockX() + rnd.nextInt(r * 2 + 1) - r;
        int z = c.getBlockZ() + rnd.nextInt(r * 2 + 1) - r;
        if (!w.isChunkLoaded(x >> 4, z >> 4)) return null;
        Block hb = w.getHighestBlockAt(x, z);
        if (hb.isLiquid()) return null;
        Location l = hb.getLocation().add(0.5, 1, 0.5);
        if (Math.abs(l.getY() - refY) > 5) return null;
        return l;
    }

    private void wander(Bot b, Player p, long now, Location center, int radius) {
        Navigator nav = b.npc.getNavigator();
        if (nav.isNavigating() || now < b.nextAction) { ambient(b, p, now); return; }
        b.nextAction = now + 3000 + rnd.nextInt(7000);
        Location t = randomNear(center, Math.max(2, radius), p.getLocation().getY());
        if (t != null) nav.setTarget(t);
    }

    // ---------------- follow / collect ----------------
    private void follow(Bot b, Player p, long now) {
        Player t = b.followTarget == null ? null : Bukkit.getPlayer(b.followTarget);
        if (t == null || !t.isOnline()) { ambient(b, p, now); return; }
        Location tl = t.getLocation(), bl = p.getLocation();
        if (tl.getWorld() != bl.getWorld() || tl.distance(bl) > 40) {
            b.npc.teleport(tl, TeleportCause.PLUGIN);
            return;
        }
        double d = tl.distance(bl);
        Navigator nav = b.npc.getNavigator();
        p.setSprinting(d > 8);
        if (d > 4) {
            if (now >= b.nextAction) { nav.setTarget(tl); b.nextAction = now + 800; }
        } else if (d < 3) {
            nav.cancelNavigation();
            b.npc.faceLocation(t.getEyeLocation());
            ambient(b, p, now);
        }
    }

    private void collect(Bot b, Player p, long now) {
        Item best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : p.getNearbyEntities(16, 8, 16)) {
            if (!(e instanceof Item) || e.isDead()) continue;
            double d = e.getLocation().distanceSquared(p.getLocation());
            if (d < bd) { bd = d; best = (Item) e; }
        }
        if (best == null) { wander(b, p, now, base(b), 10); return; }
        if (bd < 3.0) {
            ItemStack st = best.getItemStack();
            b.store(st.getType(), st.getAmount());
            best.remove();
            return;
        }
        b.npc.getNavigator().setTarget(best.getLocation());
    }

    // ---------------- combat ----------------
    private boolean validPlayer(Player t, Player p) {
        if (t == null || !t.isOnline() || t.isDead() || t.hasMetadata("NPC")) return false;
        if (t.getWorld() != p.getWorld()) return false;
        GameMode gm = t.getGameMode();
        if (gm == GameMode.SPECTATOR && cfg().getBoolean("combat.ignore-spectator", true)) return false;
        if (gm == GameMode.CREATIVE && cfg().getBoolean("combat.ignore-creative", true)) return false;
        return !t.hasPermission("fakeplayer.bypass");
    }

    private LivingEntity findTarget(Bot b, Player p, boolean guard, boolean revenge, long now) {
        Location pl = p.getLocation();
        World w = pl.getWorld();
        if (revenge) {
            Player r = Bukkit.getPlayer(b.revenge);
            if (validPlayer(r, p) && r.getLocation().distanceSquared(pl) < 24 * 24) return r;
        }
        Location center = (guard && b.home != null && b.home.getWorld() == w) ? b.home : pl;
        double r = guard ? b.radius : cfg().getDouble("combat.aggressive-range", 12);
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        if (b.aggressive || (guard && cfg().getBoolean("guard.attack-players", false))) {
            for (Player t : w.getPlayers()) {
                if (!validPlayer(t, p)) continue;
                double d = t.getLocation().distanceSquared(center);
                if (d <= r * r && d < bd) { bd = d; best = t; }
            }
        }
        if (guard && cfg().getBoolean("guard.attack-hostile", true)) {
            for (Entity e : w.getNearbyEntities(center, r, r, r)) {
                if (!(e instanceof Monster) || e.isDead()) continue;
                double d = e.getLocation().distanceSquared(pl);
                if (d < bd) { bd = d; best = (LivingEntity) e; }
            }
        }
        return best;
    }

    private boolean combat(Bot b, Player p, long now) {
        boolean guard = b.mode == BotMode.GUARD;
        boolean revenge = b.revenge != null && now < b.revengeUntil;
        if (!b.aggressive && !guard && !revenge) return false;
        LivingEntity t = findTarget(b, p, guard, revenge, now);
        if (t == null) { b.combatTarget = null; return false; }
        Navigator nav = b.npc.getNavigator();
        Location tl = t.getLocation();
        double d = p.getLocation().distance(tl);
        b.npc.faceLocation(t.getEyeLocation());
        if (d <= cfg().getDouble("combat.attack-range", 3.2)) {
            nav.cancelNavigation();
            long cd = cfg().getInt("combat.cooldown-ticks", 12) * 50L;
            if (now - b.lastHit >= cd) {
                b.lastHit = now;
                p.swingMainHand();
                t.damage(cfg().getDouble("combat.damage", 3.0), p);
                if (t.isDead()) b.kills++;
            }
        } else if (!nav.isNavigating() || !t.getUniqueId().equals(b.combatTarget)) {
            nav.setTarget(t, false);
        }
        b.combatTarget = t.getUniqueId();
        p.setSprinting(d > 5);
        return true;
    }

    // ---------------- guard ----------------
    private void guard(Bot b, Player p, long now) {
        if (b.home == null) b.home = p.getLocation().clone();
        Location h = b.home;
        Location pl = p.getLocation();
        if (h.getWorld() != pl.getWorld()) { b.npc.teleport(h, TeleportCause.PLUGIN); return; }
        if (pl.distance(h) > b.radius + 2) { b.npc.getNavigator().setTarget(h); return; }
        wander(b, p, now, h, Math.max(2, b.radius / 2));
    }

    // ---------------- mining ----------------
    private String key(Block t) { return t.getX() + "," + t.getY() + "," + t.getZ(); }

    private boolean clear(Block b) { return !b.getType().isSolid() && !b.isLiquid(); }

    private Location standSpot(Block t) {
        BlockFace[] faces = {BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST, BlockFace.UP};
        for (BlockFace f : faces) {
            Block nb = t.getRelative(f);
            if (clear(nb) && clear(nb.getRelative(BlockFace.UP)) && nb.getRelative(BlockFace.DOWN).getType().isSolid()) {
                return nb.getLocation().add(0.5, 0, 0.5);
            }
        }
        return null;
    }

    private boolean nearLiquid(Block t) {
        BlockFace[] faces = {BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST, BlockFace.UP, BlockFace.DOWN};
        for (BlockFace f : faces) if (t.getRelative(f).isLiquid()) return true;
        return false;
    }

    private void ensureMineSets(Bot b) {
        if (b.mineCache == null) {
            b.mineCache = MinePresets.resolve(b.minePreset);
            if (b.mineCache == null) b.mineCache = MinePresets.resolve("ores");
        }
        if (b.fallbackCache == null) {
            Set<Material> fb = new HashSet<>();
            if (MinePresets.usesFallback(b.minePreset)) {
                for (String n : cfg().getStringList("mining.fallback")) {
                    Material m = Material.matchMaterial(n);
                    if (m != null) fb.add(m);
                }
            }
            b.fallbackCache = fb;
        }
    }

    private boolean minable(Bot b, Block t) {
        Material m = t.getType();
        return b.mineCache.contains(m) || b.fallbackCache.contains(m);
    }

    private Block findMine(Bot b, Player p) {
        Location l = p.getLocation();
        World w = l.getWorld();
        int r = cfg().getInt("mining.radius", 8);
        boolean avoid = cfg().getBoolean("mining.avoid-liquid", true);
        if (b.skip.size() > 300) b.skip.clear();
        Block best = null, fb = null;
        double bd = Double.MAX_VALUE, fd = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int x = l.getBlockX() + dx, z = l.getBlockZ() + dz;
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int dy = -r / 2; dy <= r / 2; dy++) {
                    Block blk = w.getBlockAt(x, l.getBlockY() + dy, z);
                    Material m = blk.getType();
                    boolean main = b.mineCache.contains(m);
                    boolean fall = !main && b.fallbackCache.contains(m);
                    if (!main && !fall) continue;
                    double d = dx * dx + dy * dy + dz * dz;
                    if ((main && d >= bd) || (fall && d >= fd)) continue;
                    if (b.skip.contains(key(blk))) continue;
                    if (standSpot(blk) == null) continue;
                    if (avoid && nearLiquid(blk)) continue;
                    if (main) { best = blk; bd = d; } else { fb = blk; fd = d; }
                }
            }
        }
        return best != null ? best : fb;
    }

    private void mine(Bot b, Player p, long now) {
        ensureMineSets(b);
        Navigator nav = b.npc.getNavigator();
        if (b.mineTarget != null) {
            Block t = b.mineTarget;
            if (!minable(b, t) || now - b.targetSince > 25000) {
                b.skip.add(key(t));
                b.mineTarget = null;
                b.breakProgress = 0;
                return;
            }
            Location tc = t.getLocation().add(0.5, 0.5, 0.5);
            if (p.getEyeLocation().distance(tc) > 4.2) {
                if (!nav.isNavigating()) {
                    Location s = standSpot(t);
                    nav.setTarget(s != null ? s : tc);
                }
                return;
            }
            nav.cancelNavigation();
            b.npc.faceLocation(tc);
            p.swingMainHand();
            b.breakProgress += Math.max(1, cfg().getInt("bots.tick-interval", 5));
            double speed = Math.max(0.1, cfg().getDouble("mining.speed", 1.0));
            int need = (int) Math.max(8, Math.min(140, t.getType().getHardness() * 15 / speed));
            if (b.breakProgress >= need) breakBlock(b, p, t);
            return;
        }
        if (now < b.nextAction) { ambient(b, p, now); return; }
        Block t = findMine(b, p);
        if (t == null) {
            b.nextAction = now + 4000;
            Location around = randomNear(base(b), 14, p.getLocation().getY());
            if (around != null) nav.setTarget(around);
            return;
        }
        b.mineTarget = t;
        b.targetSince = now;
        b.breakProgress = 0;
    }

    private void breakBlock(Bot b, Player p, Block t) {
        b.mineTarget = null;
        b.breakProgress = 0;
        BlockBreakEvent ev = new BlockBreakEvent(t, p);
        Bukkit.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) { b.skip.add(key(t)); return; }
        Material toolMat = Material.matchMaterial(MinePresets.tool(b.minePreset));
        ItemStack tool = new ItemStack(toolMat == null ? Material.IRON_PICKAXE : toolMat);
        Collection<ItemStack> drops = ev.isDropItems() ? t.getDrops(tool) : Collections.<ItemStack>emptyList();
        t.getWorld().playSound(t.getLocation(), "block.stone.break", 0.8f, 1f);
        t.setType(Material.AIR);
        boolean store = cfg().getBoolean("mining.drop-to-storage", true);
        for (ItemStack it : drops) {
            if (store) b.store(it.getType(), it.getAmount());
            else t.getWorld().dropItemNaturally(t.getLocation().add(0.5, 0.5, 0.5), it);
        }
        b.mined++;
    }

    // ---------------- building ----------------
    private void notifyCommander(Bot b, String msg) {
        Player c = b.commander == null ? null : Bukkit.getPlayer(b.commander);
        if (c != null) Msg.send(c, msg);
    }

    private Location stand(Bot b, Location sl) {
        Vector v = b.buildOrigin.toVector().subtract(sl.toVector());
        v.setY(0);
        if (v.lengthSquared() < 1) v = new Vector(0, 0, 1);
        v.normalize().multiply(3);
        Location st = sl.clone().add(v);
        st.setY(b.buildOrigin.getY());
        return st;
    }

    private void build(Bot b, Player p, long now) {
        if (b.buildOrigin == null || b.buildOrigin.getWorld() == null) {
            plugin.bots().setMode(b, BotMode.IDLE, null);
            return;
        }
        if (b.queue.isEmpty()) b.queue = Structures.generate(b.buildType, b.buildOrigin, cfg());
        if (b.buildIndex >= b.queue.size()) { finishBuild(b); return; }
        Navigator nav = b.npc.getNavigator();
        World w = b.buildOrigin.getWorld();
        int per = Math.max(1, cfg().getInt("build.blocks-per-cycle", 2));
        for (int i = 0; i < per && b.buildIndex < b.queue.size(); i++) {
            Bot.Step s = b.queue.get(b.buildIndex);
            Location sl = new Location(w, s.x + 0.5, s.y, s.z + 0.5);
            Location pl = p.getLocation();
            if (pl.getWorld() != w) { b.npc.teleport(stand(b, sl), TeleportCause.PLUGIN); return; }
            if (pl.distance(sl) > 6) {
                Location st = stand(b, sl);
                if (!nav.isNavigating()) nav.setTarget(st);
                if (b.targetSince == 0) b.targetSince = now;
                if (now - b.targetSince > 10000) { b.npc.teleport(st, TeleportCause.PLUGIN); b.targetSince = 0; }
                return;
            }
            b.targetSince = 0;
            nav.cancelNavigation();
            b.npc.faceLocation(sl);
            if (!placeStep(b, p, w, s, now)) return;
            b.buildIndex++;
        }
        if (b.buildIndex >= b.queue.size()) finishBuild(b);
    }

    private boolean take(Bot b, Material m) {
        Integer c = b.storage.get(m);
        if (c == null || c <= 0) return false;
        if (c == 1) b.storage.remove(m); else b.storage.put(m, c - 1);
        return true;
    }

    private boolean placeStep(Bot b, Player p, World w, Bot.Step s, long now) {
        Block blk = w.getBlockAt(s.x, s.y, s.z);
        Material cur = blk.getType();
        if (cur == s.mat || cur == Material.BEDROCK) return true;
        if (!s.force && cur.isSolid()) return true;
        if (blk.equals(p.getLocation().getBlock()) || blk.equals(p.getEyeLocation().getBlock())) {
            b.npc.getNavigator().setTarget(stand(b, blk.getLocation().add(0.5, 0, 0.5)));
            return false;
        }
        if (cfg().getBoolean("build.require-materials", false) && !take(b, s.mat)) {
            if (now - b.lastNotify > 30000) {
                b.lastNotify = now;
                notifyCommander(b, "&e" + b.name + " kehabisan &f" + s.mat.name() + "&e di gudang, menunggu material.");
            }
            return false;
        }
        BlockState old = blk.getState();
        blk.setType(s.mat);
        BlockPlaceEvent ev = new BlockPlaceEvent(blk, old, blk.getRelative(BlockFace.DOWN), new ItemStack(s.mat), p, true);
        Bukkit.getPluginManager().callEvent(ev);
        if (ev.isCancelled() || !ev.canBuild()) {
            old.update(true, false);
            return true;
        }
        p.swingMainHand();
        w.playSound(blk.getLocation(), "block.stone.place", 0.8f, 1f);
        b.built++;
        return true;
    }

    private void finishBuild(Bot b) {
        b.queue = new ArrayList<>();
        b.buildIndex = 0;
        notifyCommander(b, "&a" + b.name + " selesai membangun &f" + b.buildType + "&a!");
        if (b.guardAfterBuild) {
            b.home = b.buildOrigin.clone();
            plugin.bots().setMode(b, BotMode.GUARD, null);
        } else {
            plugin.bots().setMode(b, BotMode.IDLE, null);
        }
    }
}
