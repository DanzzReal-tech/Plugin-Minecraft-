package me.fakeplayer.bot;

public enum BotMode {
    IDLE("Diam", "ARMOR_STAND"),
    WANDER("Jalan-jalan", "LEATHER_BOOTS"),
    FOLLOW("Ikuti", "LEAD"),
    COLLECT("Kumpulkan Item", "HOPPER"),
    MINE("Mining", "IRON_PICKAXE"),
    BUILD("Membangun", "BRICKS"),
    GUARD("Jaga Base", "SHIELD"),
    EXPLORE("Jelajah Dunia", "COMPASS"),
    AUTO("Mandiri", "NETHER_STAR");

    public final String label;
    public final String icon;

    BotMode(String label, String icon) {
        this.label = label;
        this.icon = icon;
    }

    public static BotMode parse(String s) {
        if (s == null) return null;
        try {
            return valueOf(s.toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
