package me.fakeplayer.bot;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.util.Msg;
import net.citizensnpcs.api.trait.trait.Equipment;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.EntityEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Admin "merasuki" bot: admin disembunyikan dari pemain lain, dan bot meniru posisi, arah pandang,
 * sneak/sprint/renang, item, armor, ayunan tangan, dan chat admin. HP & lapar admin mengikuti bot,
 * serangan & panah admin dihitung atas nama bot (pesan kematian memakai nama bot).
 */
public class Possession implements Listener {
    private static class State {
        Bot bot;
        Location origin;
        int ticks;
        int sig;
        boolean wasInvulnerable;
    }

    private final FakePlayerPlugin plugin;
    private final Map<UUID, State> active = new HashMap<>();

    public Possession(FakePlayerPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public boolean isPossessing(Player p) { return active.containsKey(p.getUniqueId()); }

    public Bot botOf(Player p) {
        State s = active.get(p.getUniqueId());
        return s == null ? null : s.bot;
    }

    public boolean start(Player admin, Bot b) {
        if (!b.isAlive()) { Msg.send(admin, "&cBot sedang offline / mati."); return false; }
        if (b.possessedBy != null) { Msg.send(admin, "&cBot ini sedang dirasuki orang lain."); return false; }
        if (active.containsKey(admin.getUniqueId())) stop(admin);
        State s = new State();
        s.bot = b;
        s.origin = admin.getLocation().clone();
        s.wasInvulnerable = admin.isInvulnerable();
        active.put(admin.getUniqueId(), s);
        b.possessedBy = admin.getUniqueId();
        b.npc.getNavigator().cancelNavigation();
        admin.teleport(b.player().getLocation());
        admin.setInvulnerable(true);
        for (Player o : Bukkit.getOnlinePlayers()) if (!o.equals(admin)) o.hidePlayer(plugin, admin);
        Msg.send(admin, "&aKamu merasuki &f" + b.name + "&a. Bergerak, bicara, dan menyerang sebagai bot. Keluar: &f/bot release");
        return true;
    }

    public void stop(Player admin) {
        State s = active.remove(admin.getUniqueId());
        if (s == null) return;
        s.bot.possessedBy = null;
        admin.setInvulnerable(s.wasInvulnerable);
        for (Player o : Bukkit.getOnlinePlayers()) o.showPlayer(plugin, admin);
        if (plugin.getConfig().getBoolean("possess.return-on-release", true) && s.origin.getWorld() != null) admin.teleport(s.origin);
        plugin.bots().gear(s.bot);
        Msg.send(admin, "&7Kamu keluar dari &f" + s.bot.name + "&7.");
    }

    public void releaseBot(Bot b) {
        if (b.possessedBy == null) return;
        Player a = Bukkit.getPlayer(b.possessedBy);
        if (a != null) stop(a); else b.possessedBy = null;
    }

    public void stopAll() {
        for (UUID id : new ArrayList<>(active.keySet())) {
            Player a = Bukkit.getPlayer(id);
            if (a != null) stop(a);
        }
        active.clear();
    }

    private ItemStack nn(ItemStack i) { return i == null ? new ItemStack(Material.AIR) : i; }

    @SuppressWarnings("deprecation")
    private void tick() {
        if (active.isEmpty()) return;
        boolean mirror = plugin.getConfig().getBoolean("possess.mirror-health", true);
        for (Map.Entry<UUID, State> e : new ArrayList<>(active.entrySet())) {
            Player a = Bukkit.getPlayer(e.getKey());
            State s = e.getValue();
            if (a == null || !a.isOnline()) { s.bot.possessedBy = null; active.remove(e.getKey()); continue; }
            if (!s.bot.isAlive()) { stop(a); continue; }
            Location l = a.getLocation();
            s.bot.npc.teleport(l, TeleportCause.PLUGIN);
            s.bot.npc.faceLocation(l.clone().add(l.getDirection().multiply(20)));
            Player bp = s.bot.player();
            if (bp == null) continue;
            bp.setSneaking(a.isSneaking());
            bp.setSprinting(a.isSprinting());
            try {
                bp.setSwimming(a.isSwimming());
                bp.setGliding(a.isGliding());
            } catch (Throwable ignored) {}
            s.bot.lastLoc = l.clone();

            // HP & lapar admin mengikuti bot
            if (mirror) {
                double hp = Math.max(0.5, Math.min(bp.getHealth(), a.getMaxHealth()));
                if (Math.abs(a.getHealth() - hp) > 0.01) a.setHealth(hp);
                if (a.getFoodLevel() != bp.getFoodLevel()) a.setFoodLevel(bp.getFoodLevel());
            }

            // equipment hanya dikirim jika berubah (supaya tidak berkedip)
            if (s.ticks % 4 == 0) {
                PlayerInventory inv = a.getInventory();
                int sig = Arrays.hashCode(new Object[]{inv.getItemInMainHand(), inv.getItemInOffHand(), inv.getHelmet(),
                        inv.getChestplate(), inv.getLeggings(), inv.getBoots()});
                if (sig != s.sig) {
                    s.sig = sig;
                    Equipment eq = s.bot.npc.getOrAddTrait(Equipment.class);
                    eq.set(Equipment.EquipmentSlot.HAND, nn(inv.getItemInMainHand()));
                    eq.set(Equipment.EquipmentSlot.OFF_HAND, nn(inv.getItemInOffHand()));
                    eq.set(Equipment.EquipmentSlot.HELMET, nn(inv.getHelmet()));
                    eq.set(Equipment.EquipmentSlot.CHESTPLATE, nn(inv.getChestplate()));
                    eq.set(Equipment.EquipmentSlot.LEGGINGS, nn(inv.getLeggings()));
                    eq.set(Equipment.EquipmentSlot.BOOTS, nn(inv.getBoots()));
                }
            }

            // HUD action bar
            if (s.ticks % 20 == 0) {
                try {
                    a.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(Msg.c(
                            "&5Merasuki &f" + s.bot.name + " &8| &c" + (int) Math.ceil(bp.getHealth()) + " HP &8| &7/bot release untuk keluar")));
                } catch (Throwable ignored) {}
            }
            s.ticks++;
        }
    }

    // ---------- serangan admin dihitung atas nama bot ----------
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onAdminHit(EntityDamageByEntityEvent e) {
        if (active.isEmpty() || !(e.getDamager() instanceof Player) || !(e.getEntity() instanceof LivingEntity)) return;
        Player admin = (Player) e.getDamager();
        State s = active.get(admin.getUniqueId());
        if (s == null || !plugin.getConfig().getBoolean("possess.credit-bot-for-kills", true) || !s.bot.isAlive()) return;
        LivingEntity t = (LivingEntity) e.getEntity();
        Player bp = s.bot.player();
        e.setCancelled(true);
        if (t.getUniqueId().equals(bp.getUniqueId()) || t.getUniqueId().equals(admin.getUniqueId())) return;
        t.damage(e.getDamage(), bp);
        ItemStack hand = admin.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR) return;
        Enchantment fire = Enchantment.getByKey(NamespacedKey.minecraft("fire_aspect"));
        if (fire != null && hand.getEnchantmentLevel(fire) > 0) t.setFireTicks(hand.getEnchantmentLevel(fire) * 80);
        Enchantment kb = Enchantment.getByKey(NamespacedKey.minecraft("knockback"));
        if (kb != null && hand.getEnchantmentLevel(kb) > 0) {
            Vector dir = admin.getLocation().getDirection().setY(0);
            if (dir.lengthSquared() > 0.01) {
                dir.normalize().multiply(0.5 * hand.getEnchantmentLevel(kb)).setY(0.1);
                t.setVelocity(t.getVelocity().add(dir));
            }
        }
    }

    /** Panah / trident / ender pearl admin dianggap ditembakkan oleh bot. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent e) {
        if (active.isEmpty()) return;
        ProjectileSource src = e.getEntity().getShooter();
        if (!(src instanceof Player)) return;
        State s = active.get(((Player) src).getUniqueId());
        if (s == null || !s.bot.isAlive() || !plugin.getConfig().getBoolean("possess.credit-bot-for-kills", true)) return;
        e.getEntity().setShooter(s.bot.player());
    }

    /** Admin melihat kilatan merah saat bot terkena damage. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBotHurt(EntityDamageEvent e) {
        if (active.isEmpty() || !(e.getEntity() instanceof Player)) return;
        for (Map.Entry<UUID, State> en : active.entrySet()) {
            Player bp = en.getValue().bot.player();
            if (bp != null && bp.getUniqueId().equals(e.getEntity().getUniqueId())) {
                Player a = Bukkit.getPlayer(en.getKey());
                if (a != null) a.playEffect(EntityEffect.HURT);
                return;
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        for (UUID id : active.keySet()) {
            Player a = Bukkit.getPlayer(id);
            if (a != null) e.getPlayer().hidePlayer(plugin, a);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        State s = active.remove(e.getPlayer().getUniqueId());
        if (s == null) return;
        s.bot.possessedBy = null;
        e.getPlayer().setInvulnerable(s.wasInvulnerable);
        for (Player o : Bukkit.getOnlinePlayers()) o.showPlayer(plugin, e.getPlayer());
        if (plugin.getConfig().getBoolean("possess.return-on-release", true) && s.origin.getWorld() != null) e.getPlayer().teleport(s.origin);
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        State s = active.get(e.getPlayer().getUniqueId());
        if (s != null && s.bot.isAlive()) s.bot.player().swingMainHand();
    }
}
