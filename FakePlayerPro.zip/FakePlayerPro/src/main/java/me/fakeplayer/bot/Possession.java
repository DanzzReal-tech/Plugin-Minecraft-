package me.fakeplayer.bot;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.util.Msg;
import net.citizensnpcs.api.trait.trait.Equipment;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.*;

/**
 * Admin "merasuki" bot: admin disembunyikan dari pemain lain, dan bot meniru posisi,
 * arah pandang, sneak/sprint, item, armor, ayunan tangan, dan chat admin.
 */
public class Possession implements Listener {
    private static class State {
        Bot bot;
        Location origin;
        int ticks;
    }

    private final FakePlayerPlugin plugin;
    private final Map<UUID, State> active = new HashMap<>();

    public Possession(FakePlayerPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public boolean isPossessing(Player p) { return active.containsKey(p.getUniqueId()); }

    public Bot botOf(Player p) {
        State s = active.get(p.getUniqueId());
        return s == null ? null : s.bot;
    }

    public boolean start(Player admin, Bot b) {
        if (!b.isAlive()) { Msg.send(admin, "&cBot sedang offline / mati."); return false; }
        if (b.possessedBy != null) { Msg.send(admin, "&cBot ini sedang dirasuki orang lain."); return false; }
        if (active.containsKey(admin.getUniqueId())) stop(admin);
        State s = new State();
        s.bot = b;
        s.origin = admin.getLocation().clone();
        active.put(admin.getUniqueId(), s);
        b.possessedBy = admin.getUniqueId();
        b.npc.getNavigator().cancelNavigation();
        admin.teleport(b.player().getLocation());
        for (Player o : Bukkit.getOnlinePlayers()) if (!o.equals(admin)) o.hidePlayer(plugin, admin);
        Msg.send(admin, "&aKamu merasuki &f" + b.name + "&a. Bergerak, bicara, dan memukul sebagai bot. Keluar: &f/bot release");
        return true;
    }

    public void stop(Player admin) {
        State s = active.remove(admin.getUniqueId());
        if (s == null) return;
        s.bot.possessedBy = null;
        for (Player o : Bukkit.getOnlinePlayers()) o.showPlayer(plugin, admin);
        if (plugin.getConfig().getBoolean("possess.return-on-release", true) && s.origin.getWorld() != null) admin.teleport(s.origin);
        plugin.bots().gear(s.bot);
        Msg.send(admin, "&7Kamu keluar dari &f" + s.bot.name + "&7.");
    }

    public void releaseBot(Bot b) {
        if (b.possessedBy == null) return;
        Player a = Bukkit.getPlayer(b.possessedBy);
        if (a != null) stop(a); else b.possessedBy = null;
    }

    public void stopAll() {
        for (UUID id : new ArrayList<>(active.keySet())) {
            Player a = Bukkit.getPlayer(id);
            if (a != null) stop(a);
        }
        active.clear();
    }

    private ItemStack nn(ItemStack i) { return i == null ? new ItemStack(Material.AIR) : i; }

    private void tick() {
        if (active.isEmpty()) return;
        for (Map.Entry<UUID, State> e : new ArrayList<>(active.entrySet())) {
            Player a = Bukkit.getPlayer(e.getKey());
            State s = e.getValue();
            if (a == null || !a.isOnline()) { s.bot.possessedBy = null; active.remove(e.getKey()); continue; }
            if (!s.bot.isAlive()) { stop(a); continue; }
            Location l = a.getLocation();
            s.bot.npc.teleport(l, TeleportCause.PLUGIN);
            s.bot.npc.faceLocation(l.clone().add(l.getDirection().multiply(20)));
            Player bp = s.bot.player();
            if (bp == null) continue;
            bp.setSneaking(a.isSneaking());
            bp.setSprinting(a.isSprinting());
            s.bot.lastLoc = l.clone();
            if (s.ticks++ % 10 == 0) {
                PlayerInventory inv = a.getInventory();
                Equipment eq = s.bot.npc.getOrAddTrait(Equipment.class);
                eq.set(Equipment.EquipmentSlot.HAND, nn(inv.getItemInMainHand()));
                eq.set(Equipment.EquipmentSlot.OFF_HAND, nn(inv.getItemInOffHand()));
                eq.set(Equipment.EquipmentSlot.HELMET, nn(inv.getHelmet()));
                eq.set(Equipment.EquipmentSlot.CHESTPLATE, nn(inv.getChestplate()));
                eq.set(Equipment.EquipmentSlot.LEGGINGS, nn(inv.getLeggings()));
                eq.set(Equipment.EquipmentSlot.BOOTS, nn(inv.getBoots()));
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        for (UUID id : active.keySet()) {
            Player a = Bukkit.getPlayer(id);
            if (a != null) e.getPlayer().hidePlayer(plugin, a);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        State s = active.remove(e.getPlayer().getUniqueId());
        if (s == null) return;
        s.bot.possessedBy = null;
        for (Player o : Bukkit.getOnlinePlayers()) o.showPlayer(plugin, e.getPlayer());
        if (plugin.getConfig().getBoolean("possess.return-on-release", true) && s.origin.getWorld() != null) e.getPlayer().teleport(s.origin);
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        State s = active.get(e.getPlayer().getUniqueId());
        if (s != null && s.bot.isAlive()) s.bot.player().swingMainHand();
    }
}
