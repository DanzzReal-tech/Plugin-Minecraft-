package me.fakeplayer.listener;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.Bot;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.List;
import java.util.Random;
import java.util.function.Consumer;

@SuppressWarnings("deprecation")
public class ChatListener implements Listener {
    private final FakePlayerPlugin plugin;
    private final Random rnd = new Random();

    public ChatListener(FakePlayerPlugin plugin) { this.plugin = plugin; }

    /** Input teks dari GUI (nama bot, skin). */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onPrompt(AsyncPlayerChatEvent e) {
        final Bot possessed = plugin.possession().botOf(e.getPlayer());
        if (possessed != null) {
            e.setCancelled(true);
            final String text = e.getMessage();
            Bukkit.getScheduler().runTask(plugin, () -> plugin.bots().say(possessed, text));
            return;
        }
        Consumer<String> cb = plugin.menus().takePrompt(e.getPlayer().getUniqueId());
        if (cb == null) return;
        e.setCancelled(true);
        String msg = e.getMessage().trim();
        if (msg.equalsIgnoreCase("batal") || msg.equalsIgnoreCase("cancel")) return;
        Bukkit.getScheduler().runTask(plugin, () -> cb.accept(msg));
    }

    /** Bot membalas jika namanya disebut di chat. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        final String msg = e.getMessage().toLowerCase();
        final Player who = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!plugin.getConfig().getBoolean("chat.enabled", true)) return;
            List<String> replies = plugin.getConfig().getStringList("chat.replies");
            if (replies.isEmpty()) return;
            int chance = plugin.getConfig().getInt("chat.reply-chance", 60);
            for (Bot b : plugin.bots().all()) {
                if (!b.chat || !b.isAlive() || !msg.contains(b.name.toLowerCase())) continue;
                if (rnd.nextInt(100) >= chance) continue;
                final String text = replies.get(rnd.nextInt(replies.size())).replace("%player%", who.getName());
                Bukkit.getScheduler().runTaskLater(plugin, () -> { if (b.isAlive()) plugin.bots().say(b, text); }, 40 + rnd.nextInt(60));
            }
        });
    }
}
