package me.fakeplayer.listener;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.Bot;
import me.fakeplayer.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.TabCompleteEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Membuat bot bisa jadi target /tp /tpa /tpahere /tphere seperti pemain biasa. */
public class TpListener implements Listener {
    private final FakePlayerPlugin plugin;

    private static final List<String> TP_CMDS = Arrays.asList("tp", "tele", "teleport", "tpa", "call", "tpask", "tpahere", "tphere");

    public TpListener(FakePlayerPlugin plugin) { this.plugin = plugin; }

    private Bot botNamed(String n) {
        Bot b = plugin.bots() == null ? null : plugin.bots().get(n);
        return b != null && b.online ? b : null;
    }

    private boolean perm(Player p, String perm) {
        if (p.hasPermission(perm)) return true;
        Msg.send(p, "&cKamu tidak punya izin &f" + perm);
        return false;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (plugin.bots() == null || !plugin.bots().isReady()) return;
        String msg = e.getMessage();
        if (msg.length() < 2) return;
        String[] a = msg.substring(1).trim().split("\\s+");
        String cmd = a[0].toLowerCase();
        int colon = cmd.indexOf(':');
        if (colon >= 0) cmd = cmd.substring(colon + 1);
        Player p = e.getPlayer();
        switch (cmd) {
            case "tp": case "tele": case "teleport": {
                if (a.length == 2) {
                    Bot b = botNamed(a[1]);
                    if (b == null) return;
                    e.setCancelled(true);
                    if (perm(p, "fakeplayer.tp")) plugin.teleports().tp(p, b);
                } else if (a.length == 3) {
                    Bot dest = botNamed(a[2]);
                    Player who = Bukkit.getPlayerExact(a[1]);
                    Bot botWho = botNamed(a[1]);
                    if (dest != null && who != null && dest.isAlive()) {
                        e.setCancelled(true);
                        if (perm(p, "fakeplayer.tp")) who.teleport(dest.player().getLocation());
                    } else if (botWho != null && who == null) {
                        Player to = Bukkit.getPlayerExact(a[2]);
                        if (to == null) return;
                        e.setCancelled(true);
                        if (perm(p, "fakeplayer.tphere")) plugin.bots().teleportBot(botWho, to.getLocation());
                    }
                }
                return;
            }
            case "tphere": {
                if (a.length != 2) return;
                Bot b = botNamed(a[1]);
                if (b == null) return;
                e.setCancelled(true);
                if (perm(p, "fakeplayer.tphere")) plugin.teleports().tphere(p, b);
                return;
            }
            case "tpa": case "call": case "tpask": case "tpahere": {
                if (a.length < 2) return;
                Bot b = botNamed(a[1]);
                if (b == null) return;
                e.setCancelled(true);
                if (perm(p, "fakeplayer.tpa")) plugin.teleports().request(p, b, cmd.equals("tpahere"));
                return;
            }
            case "tpaccept": case "tpyes": case "tpdeny": case "tpno": {
                Bot b = plugin.possession() == null ? null : plugin.possession().botOf(p);
                if (b == null || plugin.teleports().pending(b).isEmpty()) return;
                e.setCancelled(true);
                String from = a.length > 1 ? a[1] : null;
                if (cmd.equals("tpaccept") || cmd.equals("tpyes")) plugin.teleports().accept(b, from, p);
                else plugin.teleports().deny(b, from, p);
                return;
            }
            case "tpcancel": {
                if (plugin.teleports().hasOutgoing(p)) {
                    e.setCancelled(true);
                    plugin.teleports().cancel(p);
                }
                return;
            }
            default:
        }
    }

    /** Nama bot ikut muncul di tab-complete /tp /tpa /tpahere /tphere. */
    @EventHandler
    public void onTab(TabCompleteEvent e) {
        try {
            String buf = e.getBuffer();
            if (!buf.startsWith("/") || plugin.bots() == null || !plugin.bots().isReady()) return;
            String[] parts = buf.substring(1).split(" ", -1);
            if (parts.length < 2) return;
            String cmd = parts[0].toLowerCase();
            int colon = cmd.indexOf(':');
            if (colon >= 0) cmd = cmd.substring(colon + 1);
            if (!TP_CMDS.contains(cmd)) return;
            boolean ok = parts.length == 2 || (cmd.equals("tp") || cmd.equals("tele") || cmd.equals("teleport")) && parts.length == 3;
            if (!ok) return;
            String typed = parts[parts.length - 1].toLowerCase();
            List<String> list = new ArrayList<>(e.getCompletions());
            for (String n : plugin.bots().names()) {
                if (n.toLowerCase().startsWith(typed) && !list.contains(n)) list.add(n);
            }
            e.setCompletions(list);
        } catch (Throwable ignored) {}
    }
}
