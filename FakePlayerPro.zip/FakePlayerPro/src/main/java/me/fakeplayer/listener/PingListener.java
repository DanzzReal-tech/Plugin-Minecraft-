package me.fakeplayer.listener;

import com.destroystokyo.paper.event.server.PaperServerListPingEvent;
import me.fakeplayer.FakePlayerPlugin;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

/** Menambah jumlah online dan daftar nama (hover) di server list Minecraft. */
@SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
public class PingListener implements Listener {
    private final FakePlayerPlugin plugin;
    private boolean warned;

    public PingListener(FakePlayerPlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPing(PaperServerListPingEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("server-list.enabled", true) || plugin.bots() == null || !plugin.bots().isReady()) return;
        List<String> names = plugin.bots().names();
        if (names.isEmpty()) return;
        if (c.getBoolean("server-list.count-bots", true)) {
            e.setNumPlayers(e.getNumPlayers() + names.size());
            if (c.getBoolean("server-list.raise-max-players", true) && e.getMaxPlayers() < e.getNumPlayers()) {
                e.setMaxPlayers(e.getNumPlayers());
            }
        }
        if (c.getBoolean("server-list.show-names", true)) addSample(e, names, c.getInt("server-list.sample-limit", 12));
    }

    private UUID uuid(String name) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
    }

    private void addSample(PaperServerListPingEvent e, List<String> names, int limit) {
        // Paper baru: getListedPlayers()
        try {
            Method get = e.getClass().getMethod("getListedPlayers");
            List list = (List) get.invoke(e);
            Type g = get.getGenericReturnType();
            Class<?> infoClass = (Class<?>) ((ParameterizedType) g).getActualTypeArguments()[0];
            Constructor<?> ctor = infoClass.getConstructor(String.class, UUID.class);
            for (String n : names) {
                if (list.size() >= limit) break;
                list.add(ctor.newInstance(n, uuid(n)));
            }
            return;
        } catch (NoSuchMethodException ignored) {
        } catch (Throwable t) {
            if (!warned) { warned = true; plugin.getLogger().warning("getListedPlayers gagal, pakai cara lama: " + t); }
        }
        // Paper lama: getPlayerSample()
        try {
            List list = e.getPlayerSample();
            for (String n : names) {
                if (list.size() >= limit) break;
                list.add(Bukkit.createProfile(uuid(n), n));
            }
        } catch (Throwable t) {
            if (!warned) { warned = true; plugin.getLogger().warning("Gagal menambah nama di server list: " + t); }
        }
    }
}
