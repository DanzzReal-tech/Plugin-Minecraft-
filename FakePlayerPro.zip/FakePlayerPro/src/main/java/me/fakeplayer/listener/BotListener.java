package me.fakeplayer.listener;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.Bot;
import me.fakeplayer.gui.Menus;
import me.fakeplayer.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;

public class BotListener implements Listener {
    private final FakePlayerPlugin plugin;

    public BotListener(FakePlayerPlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        InventoryHolder h = e.getInventory().getHolder();
        if (!(h instanceof Menus.Menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getInventory())) return;
        ClickType type = e.getClick();
        ((Menus.Menu) h).click((Player) e.getWhoClicked(), e.getSlot(), type);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Menus.Menu) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.menus().takePrompt(e.getPlayer().getUniqueId());
    }

    /** Bot membalas pemain yang memukulnya. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Bot b = plugin.bots().byEntity(e.getEntity());
        if (b == null || !plugin.getConfig().getBoolean("combat.retaliate", true)) return;
        Entity d = e.getDamager();
        if (d instanceof Projectile && ((Projectile) d).getShooter() instanceof Entity) d = (Entity) ((Projectile) d).getShooter();
        if (d instanceof Player && !d.hasMetadata("NPC")) {
            b.revenge = d.getUniqueId();
            b.revengeUntil = System.currentTimeMillis() + 15000;
        }
    }

    /** Pesan kematian palsu untuk bot. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player)) return;
        Bot b = plugin.bots().byEntity(e.getEntity());
        if (b == null || !plugin.getConfig().getBoolean("bots.death-messages", true)) return;
        Player p = (Player) e.getEntity();
        if (p.getHealth() - e.getFinalDamage() > 0) return;
        String msg;
        if (e instanceof EntityDamageByEntityEvent) {
            Entity d = ((EntityDamageByEntityEvent) e).getDamager();
            msg = b.name + " was slain by " + d.getName();
        } else {
            switch (e.getCause()) {
                case FALL: msg = b.name + " hit the ground too hard"; break;
                case LAVA: msg = b.name + " tried to swim in lava"; break;
                case DROWNING: msg = b.name + " drowned"; break;
                case FIRE: case FIRE_TICK: msg = b.name + " burned to death"; break;
                case SUFFOCATION: msg = b.name + " suffocated in a wall"; break;
                case VOID: msg = b.name + " fell out of the world"; break;
                default: msg = b.name + " died";
            }
        }
        Bukkit.broadcastMessage(Msg.c("&f" + msg));
    }
}
