package me.fakeplayer.listener;

import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.Bot;
import me.fakeplayer.gui.Menus;
import me.fakeplayer.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;

public class BotListener implements Listener {
    private final FakePlayerPlugin plugin;

    public BotListener(FakePlayerPlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        InventoryHolder h = e.getInventory().getHolder();
        if (!(h instanceof Menus.Menu)) return;
        if (((Menus.Menu) h).handlesRaw()) { ((Menus.Menu) h).onRawClick(e); return; }
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getInventory())) return;
        ClickType type = e.getClick();
        ((Menus.Menu) h).click((Player) e.getWhoClicked(), e.getSlot(), type);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        InventoryHolder h = e.getInventory().getHolder();
        if (!(h instanceof Menus.Menu)) return;
        if (((Menus.Menu) h).handlesRaw()) ((Menus.Menu) h).onRawDrag(e); else e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        InventoryHolder h = e.getInventory().getHolder();
        if (h instanceof Menus.Menu && e.getPlayer() instanceof Player) ((Menus.Menu) h).onClose((Player) e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.menus().takePrompt(e.getPlayer().getUniqueId());
    }

    /** Bot membalas pemain yang memukulnya. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Bot b = plugin.bots().byEntity(e.getEntity());
        if (b == null || !plugin.getConfig().getBoolean("combat.retaliate", true)) return;
        Entity d = e.getDamager();
        if (d instanceof Projectile && ((Projectile) d).getShooter() instanceof Entity) d = (Entity) ((Projectile) d).getShooter();
        if (d instanceof Player && !d.hasMetadata("NPC")) {
            b.revenge = d.getUniqueId();
            b.revengeUntil = System.currentTimeMillis() + 15000;
        }
    }

    /**
     * Pesan kematian bot = pesan bawaan Minecraft (sama seperti pemain biasa).
     * Plugin hanya mematikannya jika bots.death-messages: false, dan mencegah item kit
     * jatuh (bot respawn dengan kit dari datanya, jadi kalau jatuh akan menggandakan item).
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBotDeath(org.bukkit.event.entity.PlayerDeathEvent e) {
        // pemain terbunuh oleh bot -> tambah kill bot
        Player killer = e.getEntity().getKiller();
        Bot kb = killer == null ? null : plugin.bots().byEntity(killer);
        if (kb != null) kb.kills++;
        Bot b = plugin.bots().byEntity(e.getEntity());
        if (b == null) return;
        if (killer != null && !killer.hasMetadata("NPC")) creditKill(killer, b);
        if (!plugin.getConfig().getBoolean("bots.death-messages", true)) e.setDeathMessage(null);
        if (!plugin.getConfig().getBoolean("bots.drop-items-on-death", false)) {
            e.getDrops().clear();
            e.setDroppedExp(0);
        }
    }

    /** Pembunuh bot mendapat kill: statistik vanilla, objective scoreboard, perintah console, dan pesan. */
    private void creditKill(final Player killer, Bot b) {
        org.bukkit.configuration.file.FileConfiguration c = plugin.getConfig();
        if (c.getBoolean("kill-credit.statistic", true)) {
            try {
                final int before = killer.getStatistic(org.bukkit.Statistic.PLAYER_KILLS);
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    // hanya ditambah jika Minecraft belum menambahnya (mencegah hitungan ganda)
                    if (killer.isOnline() && killer.getStatistic(org.bukkit.Statistic.PLAYER_KILLS) == before) {
                        killer.incrementStatistic(org.bukkit.Statistic.PLAYER_KILLS);
                    }
                }, 3L);
            } catch (Throwable ignored) {}
        }
        String obj = c.getString("kill-credit.objective", "");
        if (obj != null && !obj.isEmpty() && Bukkit.getScoreboardManager() != null) {
            try {
                final org.bukkit.scoreboard.Objective o = Bukkit.getScoreboardManager().getMainScoreboard().getObjective(obj);
                if (o != null) {
                    final int before = o.getScore(killer.getName()).getScore();
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        org.bukkit.scoreboard.Score sc = o.getScore(killer.getName());
                        if (sc.getScore() == before) sc.setScore(before + 1);
                    }, 3L);
                }
            } catch (Throwable ignored) {}
        }
        for (String cmd : c.getStringList("kill-credit.commands")) {
            String x = cmd.startsWith("/") ? cmd.substring(1) : cmd;
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), x.replace("%killer%", killer.getName()).replace("%bot%", b.name));
        }
        String msg = c.getString("kill-credit.message", "");
        if (msg != null && !msg.isEmpty()) Msg.send(killer, msg.replace("%bot%", b.name));
    }

    /** Bot di region WorldGuard (pvp deny / invincibility / mob-damage deny) tidak terkena damage, seperti pemain biasa. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBotProtect(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player) || !plugin.getConfig().getBoolean("bots.respect-worldguard", true)) return;
        Bot b = plugin.bots().byEntity(e.getEntity());
        if (b == null || !me.fakeplayer.hook.WorldGuardHook.available()) return;
        org.bukkit.Location l = e.getEntity().getLocation();
        if (me.fakeplayer.hook.WorldGuardHook.invincible(l)) { e.setCancelled(true); return; }
        if (e instanceof EntityDamageByEntityEvent) {
            Entity d = ((EntityDamageByEntityEvent) e).getDamager();
            if (d instanceof Projectile && ((Projectile) d).getShooter() instanceof Entity) d = (Entity) ((Projectile) d).getShooter();
            if (d instanceof Player) {
                if (!me.fakeplayer.hook.WorldGuardHook.pvpAllowed(l)) e.setCancelled(true);
            } else if (d instanceof org.bukkit.entity.Monster) {
                if (!me.fakeplayer.hook.WorldGuardHook.mobDamageAllowed(l)) e.setCancelled(true);
            }
        }
    }
}
