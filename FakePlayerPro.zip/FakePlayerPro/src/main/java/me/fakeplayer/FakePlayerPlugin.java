package me.fakeplayer;

import me.fakeplayer.bot.BotManager;
import me.fakeplayer.bot.Possession;
import me.fakeplayer.bot.Teleports;
import me.fakeplayer.command.OnlineCommand;
import me.fakeplayer.listener.TpListener;
import me.fakeplayer.command.BotCommand;
import me.fakeplayer.gui.Menus;
import me.fakeplayer.hook.LuckHook;
import me.fakeplayer.listener.BotListener;
import me.fakeplayer.listener.ChatListener;
import me.fakeplayer.listener.PingListener;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class FakePlayerPlugin extends JavaPlugin {
    private static FakePlayerPlugin instance;
    private BotManager bots;
    private Menus menus;
    private Possession possession;
    private Teleports teleports;
    private LuckHook luck;

    public static FakePlayerPlugin get() { return instance; }
    public BotManager bots() { return bots; }
    public Menus menus() { return menus; }
    public Possession possession() { return possession; }
    public Teleports teleports() { return teleports; }
    public LuckHook luck() { return luck; }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        if (getServer().getPluginManager().getPlugin("Citizens") == null) {
            getLogger().severe("Citizens 2 tidak ditemukan! Install Citizens dulu. Plugin dimatikan.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        if (getServer().getPluginManager().getPlugin("LuckPerms") != null) {
            try {
                luck = new LuckHook();
                getLogger().info("LuckPerms terdeteksi: rank bot aktif (/bot rank).");
            } catch (Throwable t) {
                getLogger().warning("LuckPerms gagal dihubungkan: " + t);
            }
        }
        teleports = new Teleports(this);
        possession = new Possession(this);
        getServer().getPluginManager().registerEvents(possession, this);
        bots = new BotManager(this);
        menus = new Menus(this);
        getServer().getPluginManager().registerEvents(new BotListener(this), this);
        try {
            getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        } catch (Throwable t) {
            getLogger().warning("Event chat tidak tersedia: balasan chat & input GUI dinonaktifkan.");
        }
        try {
            getServer().getPluginManager().registerEvents(new PingListener(this), this);
        } catch (Throwable t) {
            getLogger().warning("Server bukan Paper/fork Paper: server list tidak bisa dimodifikasi. Pakai Paper/Purpur/Pufferfish.");
        }
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new me.fakeplayer.hook.PapiExpansion(this).register();
                getLogger().info("PlaceholderAPI terdeteksi: %fakeplayer_online%, _real, _bots, _alive, _max aktif.");
            } catch (Throwable t) {
                getLogger().warning("Gagal mendaftarkan placeholder: " + t);
            }
        }
        try {
            getServer().getPluginManager().registerEvents(new TpListener(this), this);
        } catch (Throwable t) {
            getLogger().warning("Gagal mendaftarkan /tp /tpa untuk bot: " + t);
        }
        PluginCommand oc = getCommand("online");
        if (oc != null) oc.setExecutor(new OnlineCommand(this));
        BotCommand cmd = new BotCommand(this);
        PluginCommand pc = getCommand("fakeplayer");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        Bukkit.getScheduler().runTaskLater(this, () -> bots.start(), 40L);
    }

    @Override
    public void onDisable() {
        if (possession != null) possession.stopAll();
        if (bots != null) bots.shutdown();
    }
}
