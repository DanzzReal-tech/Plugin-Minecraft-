package me.fakeplayer;

import me.fakeplayer.bot.BotManager;
import me.fakeplayer.command.BotCommand;
import me.fakeplayer.gui.Menus;
import me.fakeplayer.listener.BotListener;
import me.fakeplayer.listener.ChatListener;
import me.fakeplayer.listener.PingListener;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class FakePlayerPlugin extends JavaPlugin {
    private static FakePlayerPlugin instance;
    private BotManager bots;
    private Menus menus;

    public static FakePlayerPlugin get() { return instance; }
    public BotManager bots() { return bots; }
    public Menus menus() { return menus; }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        if (getServer().getPluginManager().getPlugin("Citizens") == null) {
            getLogger().severe("Citizens 2 tidak ditemukan! Install Citizens dulu. Plugin dimatikan.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        bots = new BotManager(this);
        menus = new Menus(this);
        getServer().getPluginManager().registerEvents(new BotListener(this), this);
        try {
            getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        } catch (Throwable t) {
            getLogger().warning("Event chat tidak tersedia: balasan chat & input GUI dinonaktifkan.");
        }
        try {
            getServer().getPluginManager().registerEvents(new PingListener(this), this);
        } catch (Throwable t) {
            getLogger().warning("Server bukan Paper/fork Paper: server list tidak bisa dimodifikasi. Pakai Paper/Purpur/Pufferfish.");
        }
        BotCommand cmd = new BotCommand(this);
        PluginCommand pc = getCommand("fakeplayer");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        Bukkit.getScheduler().runTaskLater(this, () -> bots.start(), 40L);
    }

    @Override
    public void onDisable() {
        if (bots != null) bots.shutdown();
    }
}
