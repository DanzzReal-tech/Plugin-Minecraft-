package me.fakeplayer.hook;

import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.lang.reflect.Array;
import java.lang.reflect.Method;

/**
 * Membaca flag WorldGuard (pvp, invincibility, mob-damage) lewat reflection, tanpa dependency saat build.
 * Dipakai agar bot di region yang diproteksi diperlakukan seperti pemain biasa.
 */
public final class WorldGuardHook {
    private WorldGuardHook() {}

    private static boolean tried, ok;
    private static Object container;
    private static Method createQuery, adapt, queryState;
    private static Class<?> stateFlagClass;
    private static Object PVP, INVINCIBILITY, MOB_DAMAGE;

    private static synchronized void init() {
        if (tried) return;
        tried = true;
        try {
            org.bukkit.plugin.Plugin wgp = Bukkit.getPluginManager().getPlugin("WorldGuard");
            if (wgp == null) return;
            ClassLoader wgl = wgp.getClass().getClassLoader();
            org.bukkit.plugin.Plugin wep = Bukkit.getPluginManager().getPlugin("WorldEdit");
            if (wep == null) wep = Bukkit.getPluginManager().getPlugin("FastAsyncWorldEdit");
            ClassLoader wel = wep != null ? wep.getClass().getClassLoader() : wgl;
            Class<?> wgClass = Class.forName("com.sk89q.worldguard.WorldGuard", true, wgl);
            Object wg = wgClass.getMethod("getInstance").invoke(null);
            Object platform = wg.getClass().getMethod("getPlatform").invoke(wg);
            container = platform.getClass().getMethod("getRegionContainer").invoke(platform);
            createQuery = container.getClass().getMethod("createQuery");
            Class<?> adapter = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter", true, wel);
            adapt = adapter.getMethod("adapt", Location.class);
            Class<?> flags = Class.forName("com.sk89q.worldguard.protection.flags.Flags", true, wgl);
            PVP = flags.getField("PVP").get(null);
            INVINCIBILITY = flags.getField("INVINCIBILITY").get(null);
            MOB_DAMAGE = flags.getField("MOB_DAMAGE").get(null);
            stateFlagClass = Class.forName("com.sk89q.worldguard.protection.flags.StateFlag", true, wgl);
            Object q = createQuery.invoke(container);
            for (Method m : q.getClass().getMethods()) {
                // WorldGuard 7.0.15: queryState(Location, RegionAssociable, StateFlag...) -> StateFlag.State
                if (m.getName().equals("queryState") && m.getParameterTypes().length == 3) { queryState = m; break; }
            }
            ok = queryState != null;
        } catch (Throwable t) {
            ok = false;
        }
    }

    public static boolean available() {
        init();
        return ok;
    }

    /** "ALLOW", "DENY", atau null (tidak diatur). */
    private static String state(Location l, Object flag) {
        if (!available() || l == null || l.getWorld() == null) return null;
        try {
            Object q = createQuery.invoke(container);
            Object weLoc = adapt.invoke(null, l);
            Object arr = Array.newInstance(stateFlagClass, 1);
            Array.set(arr, 0, flag);
            Object r = queryState.invoke(q, weLoc, null, arr);
            return r == null ? null : String.valueOf(r);
        } catch (Throwable t) {
            return null;
        }
    }

    /** false jika region di lokasi itu melarang PvP. */
    public static boolean pvpAllowed(Location l) {
        return !"DENY".equals(state(l, PVP));
    }

    /** true jika region membuat pemain kebal (flag invincibility allow). */
    public static boolean invincible(Location l) {
        return "ALLOW".equals(state(l, INVINCIBILITY));
    }

    public static boolean mobDamageAllowed(Location l) {
        return !"DENY".equals(state(l, MOB_DAMAGE));
    }
}
