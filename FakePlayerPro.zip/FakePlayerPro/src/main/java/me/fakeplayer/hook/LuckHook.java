package me.fakeplayer.hook;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.cacheddata.CachedMetaData;
import net.luckperms.api.model.group.Group;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.ArrayList;
import java.util.List;

/** Membaca grup, prefix, dan suffix dari LuckPerms untuk rank tampilan bot. */
public class LuckHook {
    private final LuckPerms lp;

    public LuckHook() {
        RegisteredServiceProvider<LuckPerms> rsp = Bukkit.getServicesManager().getRegistration(LuckPerms.class);
        if (rsp == null) throw new IllegalStateException("LuckPerms belum siap");
        lp = rsp.getProvider();
    }

    public List<String> groups() {
        List<String> l = new ArrayList<>();
        for (Group g : lp.getGroupManager().getLoadedGroups()) l.add(g.getName());
        return l;
    }

    /** Nama grup yang tepat, atau null jika tidak ada. */
    public String find(String name) {
        Group g = lp.getGroupManager().getGroup(name.toLowerCase());
        return g == null ? null : g.getName();
    }

    private CachedMetaData meta(String group) {
        Group g = lp.getGroupManager().getGroup(group);
        if (g == null) return null;
        return g.getCachedData().getMetaData(lp.getContextManager().getStaticQueryOptions());
    }

    public String prefix(String group) {
        CachedMetaData m = meta(group);
        return m == null || m.getPrefix() == null ? "" : m.getPrefix();
    }

    public String suffix(String group) {
        CachedMetaData m = meta(group);
        return m == null || m.getSuffix() == null ? "" : m.getSuffix();
    }
}
