package me.fakeplayer.hook;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.Bot;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class PapiExpansion extends PlaceholderExpansion {
    private final FakePlayerPlugin plugin;

    public PapiExpansion(FakePlayerPlugin plugin) { this.plugin = plugin; }

    @Override public String getIdentifier() { return "fakeplayer"; }
    @Override public String getAuthor() { return "FakePlayerPro"; }
    @Override public String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }
    @Override public boolean canRegister() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (plugin.bots() == null || !plugin.bots().isReady()) return "0";
        String low = params.toLowerCase();
        if (low.startsWith("rank_") || low.startsWith("prefix_") || low.startsWith("suffix_")) {
            Bot rb = plugin.bots().get(params.substring(params.indexOf('_') + 1));
            if (rb == null) return "";
            if (low.startsWith("rank_")) return rb.rank == null ? "" : rb.rank;
            return low.startsWith("prefix_") ? plugin.bots().rankPrefix(rb) : plugin.bots().rankSuffix(rb);
        }
        int real = Bukkit.getOnlinePlayers().size();
        int bots = plugin.bots().count();
        switch (params.toLowerCase()) {
            case "online": case "total": return String.valueOf(real + bots);
            case "real": return String.valueOf(real);
            case "bots": return String.valueOf(bots);
            case "alive": {
                int a = 0;
                for (Bot b : plugin.bots().all()) if (b.isAlive()) a++;
                return String.valueOf(a);
            }
            case "max": return String.valueOf(Math.max(Bukkit.getMaxPlayers(), real + bots));
            default: return null;
        }
    }
}
