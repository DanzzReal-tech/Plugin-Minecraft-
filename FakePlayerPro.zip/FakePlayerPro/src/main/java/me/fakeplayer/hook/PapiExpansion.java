package me.fakeplayer.hook;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.fakeplayer.FakePlayerPlugin;
import me.fakeplayer.bot.Bot;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class PapiExpansion extends PlaceholderExpansion {
    private final FakePlayerPlugin plugin;

    public PapiExpansion(FakePlayerPlugin plugin) { this.plugin = plugin; }

    @Override public String getIdentifier() { return "fakeplayer"; }
    @Override public String getAuthor() { return "FakePlayerPro"; }
    @Override public String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }
    @Override public boolean canRegister() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (plugin.bots() == null || !plugin.bots().isReady()) return "0";
        String low = params.toLowerCase();
        if (low.startsWith("rank_") || low.startsWith("prefix_") || low.startsWith("suffix_")) {
            Bot rb = plugin.bots().get(params.substring(params.indexOf('_') + 1));
            if (rb == null) return "";
            if (low.startsWith("rank_")) return rb.rank == null ? "" : rb.rank;
            return low.startsWith("prefix_") ? plugin.bots().rankPrefix(rb) : plugin.bots().rankSuffix(rb);
        }
        if (low.startsWith("online_") || low.startsWith("real_") || low.startsWith("bots_")) {
            String kind = low.substring(0, low.indexOf('_'));
            String wn = params.substring(kind.length() + 1);
            int[] c = null;
            if (wn.equalsIgnoreCase("here") || wn.equalsIgnoreCase("current")) {
                // world tempat pemain yang melihat placeholder ini berada
                if (player == null || player.getPlayer() == null) return "0";
                wn = player.getPlayer().getWorld().getName();
            }
            for (java.util.Map.Entry<String, int[]> e : plugin.bots().worldCounts().entrySet()) {
                if (e.getKey().equalsIgnoreCase(wn)) { c = e.getValue(); break; }
            }
            if (c == null) return "?";   // nama world salah; cek nama persis lewat /online
            return String.valueOf(kind.equals("online") ? c[0] + c[1] : kind.equals("real") ? c[0] : c[1]);
        }
        if (low.startsWith("ping_")) {
            try {
                int n = Integer.parseInt(low.substring(5));
                java.util.List<Bot> l = plugin.bots().onlineBots();
                return n < 1 || n > l.size() ? "" : String.valueOf(plugin.bots().pingOf(l.get(n - 1)));
            } catch (NumberFormatException e) {
                return "";
            }
        }
        if (low.equals("names") || low.equals("fullnames")) {
            StringBuilder sb = new StringBuilder();
            for (Bot b : plugin.bots().onlineBots()) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(low.equals("names") ? b.name : plugin.bots().tabName(b));
            }
            return sb.toString();
        }
        if (low.startsWith("name_") || low.startsWith("fullname_")) {
            boolean full = low.startsWith("fullname_");
            try {
                int n = Integer.parseInt(low.substring(low.indexOf('_') + 1));
                java.util.List<Bot> l = plugin.bots().onlineBots();
                if (n < 1 || n > l.size()) return "";
                return full ? plugin.bots().tabName(l.get(n - 1)) : l.get(n - 1).name;
            } catch (NumberFormatException e) {
                return "";
            }
        }
        int real = Bukkit.getOnlinePlayers().size();
        int bots = plugin.bots().count();
        switch (params.toLowerCase()) {
            case "online": case "total": return String.valueOf(real + bots);
            case "real": return String.valueOf(real);
            case "bots": return String.valueOf(bots);
            case "alive": {
                int a = 0;
                for (Bot b : plugin.bots().all()) if (b.isAlive()) a++;
                return String.valueOf(a);
            }
            case "max": return String.valueOf(Math.max(Bukkit.getMaxPlayers(), real + bots));
            default: return null;
        }
    }
}
