package me.fakeplayer.util;

import me.fakeplayer.FakePlayerPlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pewarnaan teks. Mendukung:
 *  - kode lama:            &a &l &r ...
 *  - hex:                  &#RRGGBB   <#RRGGBB>   &x&R&R&G&G&B&B
 *  - gradient:             <gradient:#FF0000:#0000FF>teks</gradient>  (boleh 2+ warna)
 *  - pelangi:              <rainbow>teks</rainbow>
 * Hex/gradient butuh klien dan server 1.16+.
 */
public final class Msg {
    private Msg() {}

    private static final Pattern GRADIENT = Pattern.compile("<gradient:([^>]+)>(.*?)</gradient>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern RAINBOW = Pattern.compile("<rainbow>(.*?)</rainbow>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern TAG_HEX = Pattern.compile("<#([A-Fa-f0-9]{6})>");
    private static final Pattern AMP_HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final Pattern SECTION_HEX = Pattern.compile("\u00A7x(\u00A7[0-9a-fA-F]){6}");

    public static String c(String s) {
        if (s == null) return "";
        if (s.indexOf('<') >= 0) {
            s = replaceGradients(s);
            s = replaceRainbow(s);
            s = TAG_HEX.matcher(s).replaceAll("&#$1");
        }
        if (s.indexOf("&#") >= 0) {
            Matcher m = AMP_HEX.matcher(s);
            StringBuffer sb = new StringBuffer();
            while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(hex(m.group(1))));
            m.appendTail(sb);
            s = sb.toString();
        }
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public static void send(CommandSender to, String s) {
        String prefix = FakePlayerPlugin.get().getConfig().getString("prefix", "&8[&bBot&8] &7");
        to.sendMessage(c(prefix + s));
    }

    // ---------- hex ----------
    private static String hex(String h) {
        StringBuilder sb = new StringBuilder("\u00A7x");
        for (char ch : h.toCharArray()) sb.append('\u00A7').append(ch);
        return sb.toString();
    }

    private static String hex(int r, int g, int b) {
        return hex(String.format("%02X%02X%02X", r, g, b));
    }

    // ---------- gradient & rainbow ----------
    private static String replaceGradients(String s) {
        Matcher m = GRADIENT.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            List<int[]> cols = new ArrayList<>();
            for (String part : m.group(1).split(":")) {
                String h = part.trim().replace("#", "");
                if (h.length() == 6) {
                    try {
                        cols.add(new int[]{Integer.parseInt(h.substring(0, 2), 16), Integer.parseInt(h.substring(2, 4), 16), Integer.parseInt(h.substring(4, 6), 16)});
                    } catch (NumberFormatException ignored) {}
                }
            }
            String out = cols.size() >= 2 ? paint(m.group(2), cols, false) : m.group(2);
            m.appendReplacement(sb, Matcher.quoteReplacement(out));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String replaceRainbow(String s) {
        Matcher m = RAINBOW.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(paint(m.group(1), null, true)));
        m.appendTail(sb);
        return sb.toString();
    }

    /** Warnai tiap huruf; kode format (&l &o &n &m &k) dipertahankan, kode warna di dalam diabaikan. */
    private static String paint(String text, List<int[]> cols, boolean rainbow) {
        int visible = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&' && i + 1 < text.length() && "0123456789abcdefklmnorABCDEFKLMNOR".indexOf(text.charAt(i + 1)) >= 0) { i++; continue; }
            visible++;
        }
        StringBuilder out = new StringBuilder();
        StringBuilder fmt = new StringBuilder();
        int idx = 0;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch == '&' && i + 1 < text.length() && "0123456789abcdefklmnorABCDEFKLMNOR".indexOf(text.charAt(i + 1)) >= 0) {
                char code = Character.toLowerCase(text.charAt(i + 1));
                if (code == 'r') fmt.setLength(0);
                else if ("klmno".indexOf(code) >= 0) fmt.append('\u00A7').append(code);
                i++;
                continue;
            }
            double t = visible <= 1 ? 0 : (double) idx / (visible - 1);
            int[] rgb;
            if (rainbow) {
                rgb = hsv(t * 0.85, 0.9, 1.0);
            } else {
                int segs = cols.size() - 1;
                double pos = t * segs;
                int seg = Math.min((int) Math.floor(pos), segs - 1);
                double lt = pos - seg;
                int[] a = cols.get(seg), b = cols.get(seg + 1);
                rgb = new int[]{(int) Math.round(a[0] + (b[0] - a[0]) * lt), (int) Math.round(a[1] + (b[1] - a[1]) * lt), (int) Math.round(a[2] + (b[2] - a[2]) * lt)};
            }
            out.append(hex(rgb[0], rgb[1], rgb[2])).append(fmt).append(ch);
            idx++;
        }
        return out.toString();
    }

    private static int[] hsv(double h, double sat, double v) {
        double hh = (h - Math.floor(h)) * 6;
        int i = (int) Math.floor(hh);
        double f = hh - i, p = v * (1 - sat), q = v * (1 - sat * f), t = v * (1 - sat * (1 - f));
        double r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q;
        }
        return new int[]{(int) Math.round(r * 255), (int) Math.round(g * 255), (int) Math.round(b * 255)};
    }

    // ---------- untuk batas panjang (team prefix/suffix maks 64 karakter) ----------
    private static final int[][] LEGACY = {
            {0, 0, 0}, {0, 0, 170}, {0, 170, 0}, {0, 170, 170}, {170, 0, 0}, {170, 0, 170}, {255, 170, 0}, {170, 170, 170},
            {85, 85, 85}, {85, 85, 255}, {85, 255, 85}, {85, 255, 255}, {255, 85, 85}, {255, 85, 255}, {255, 255, 85}, {255, 255, 255}};

    /** Jika teks berwarna terlalu panjang, ubah warna hex jadi warna lama terdekat, lalu potong aman. */
    public static String shorten(String colored, int max) {
        if (colored.length() <= max) return colored;
        Matcher m = SECTION_HEX.matcher(colored);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String g = m.group().replace("\u00A7", "").substring(1);
            int r = Integer.parseInt(g.substring(0, 2), 16), gg = Integer.parseInt(g.substring(2, 4), 16), b = Integer.parseInt(g.substring(4, 6), 16);
            int best = 0;
            long bd = Long.MAX_VALUE;
            for (int i = 0; i < LEGACY.length; i++) {
                long d = (long) (r - LEGACY[i][0]) * (r - LEGACY[i][0]) + (long) (gg - LEGACY[i][1]) * (gg - LEGACY[i][1]) + (long) (b - LEGACY[i][2]) * (b - LEGACY[i][2]);
                if (d < bd) { bd = d; best = i; }
            }
            m.appendReplacement(sb, Matcher.quoteReplacement("\u00A7" + Integer.toHexString(best)));
        }
        m.appendTail(sb);
        String out = sb.toString();
        // gabungkan warna lama yang berulang berurutan supaya lebih pendek
        out = out.replaceAll("(\u00A7[0-9a-f])(?=[^\u00A7]\\1)", "$1");
        if (out.length() > max) {
            out = out.substring(0, max);
            if (out.endsWith("\u00A7")) out = out.substring(0, out.length() - 1);
        }
        return out;
    }
}
