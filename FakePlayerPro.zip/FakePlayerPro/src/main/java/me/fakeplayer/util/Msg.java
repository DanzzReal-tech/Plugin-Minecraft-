package me.fakeplayer.util;

import me.fakeplayer.FakePlayerPlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public final class Msg {
    private Msg() {}

    public static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public static void send(CommandSender to, String s) {
        String prefix = FakePlayerPlugin.get().getConfig().getString("prefix", "&8[&bBot&8] &7");
        to.sendMessage(c(prefix + s));
    }
}
